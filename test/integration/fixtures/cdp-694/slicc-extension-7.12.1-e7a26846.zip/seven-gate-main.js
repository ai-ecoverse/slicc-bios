globalThis.__sliccSeven = {"domain":"sliccy.ai","excludedLabels":["vault","vault-preview","get","mcpcat","echo"],"excludedLabelPrefixes":["vault-"],"version":"7.12.1"};
