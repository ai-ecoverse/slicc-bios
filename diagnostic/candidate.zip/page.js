(() => {
  const _six = ['www.sliccy.ai'];
  const _seven = globalThis.__sliccSeven;
  delete globalThis.__sliccSeven;
  const _exL = _seven.excludedLabels;
  const _exP = _seven.excludedLabelPrefixes;
  const _d = `.${_seven.domain}`;
  const h = location.hostname;
  if (!h.endsWith(_d)) return;
  const l = h.slice(0, -_d.length);
  if (!l || (!_six.includes(h) && (_exL.includes(l) || _exP.some((p) => l.startsWith(p))))) return;

  const { port1, port2 } = new MessageChannel();
  const open = new Map();
  const pending = new Map();
  const listeners = new Set();
  const bodiless = new Set([101, 103, 204, 205, 304]);
  const modes = ['follow', 'error', 'manual'];
  let next = 0;

  function deliver(message) {
    if (typeof message.id === 'number' && pending.has(message.id)) {
      const { resolve, reject } = pending.get(message.id);
      pending.delete(message.id);
      if (message.error) reject(new Error(message.error));
      else resolve(message.result ?? {});
      return;
    }
    if (typeof message.id !== 'number' && message.error) {
      for (const { reject } of pending.values()) reject(new Error(message.error));
      pending.clear();
      return;
    }
    for (const listener of listeners) listener(message);
  }

  port1.onmessage = ({ data }) => {
    if (data.cdp) {
      deliver(data.cdp);
      return;
    }
    open.get(data.id)?.(data);
  };
  postMessage({ type: 'slicc-extension:port' }, location.origin, [port2]);

  function receive(id, signal, resolve, reject) {
    let controller;
    let pulled = () => {};
    const stop = () => {
      if (open.delete(id)) port1.postMessage({ id, abort: true });
    };
    const body = new ReadableStream({
      start: (c) => {
        controller = c;
      },
      pull: () =>
        new Promise((resolve) => {
          pulled = resolve;
          if (open.has(id)) port1.postMessage({ id, read: true });
          else resolve();
        }),
      cancel: stop,
    });
    const abort = () => {
      stop();
      reject(signal.reason);
      controller.error(signal.reason);
    };
    signal?.addEventListener('abort', abort, { once: true });
    open.set(id, (message) => {
      if (message.status !== undefined) {
        const { status, statusText, headers, url, redirected } = message;
        try {
          const response = new Response(bodiless.has(status) ? null : body, {
            status,
            statusText,
            headers,
          });
          resolve(
            Object.defineProperties(response, {
              url: { value: url },
              redirected: { value: redirected },
            })
          );
        } catch (error) {
          stop();
          signal?.removeEventListener('abort', abort);
          reject(new TypeError(error.message));
        }
        return;
      }
      pulled();
      if (message.chunk) {
        controller.enqueue(new Uint8Array(message.chunk));
        return;
      }
      open.delete(id);
      signal?.removeEventListener('abort', abort);
      if (message.end) {
        controller.close();
        return;
      }
      const error = new TypeError(message.error);
      reject(error);
      controller.error(error);
    });
  }

  async function relayFetch(input, init = {}) {
    const { redirect = 'follow' } = init;
    if (!modes.includes(redirect)) {
      throw new TypeError('slicc-extension: unknown redirect mode');
    }
    init.signal?.throwIfAborted();
    const url = new URL(input, location.href).href;
    const method = init.method ?? 'GET';
    const headers = new Headers(init.headers);
    let body;
    if (init.body != null) {
      const serialized = new Response(init.body);
      const type = serialized.headers.get('content-type');
      if (type && !headers.has('content-type')) headers.set('content-type', type);
      body = await serialized.arrayBuffer();
    }
    init.signal?.throwIfAborted();
    const id = ++next;
    return new Promise((resolve, reject) => {
      receive(id, init.signal, resolve, reject);
      port1.postMessage(
        { id, url, method, headers: [...headers], body, redirect },
        body ? [body] : []
      );
    });
  }

  function send(method, params, sessionId) {
    const id = ++next;
    const command = { id, method };
    if (params !== undefined) command.params = params;
    if (sessionId !== undefined) command.sessionId = sessionId;
    return new Promise((resolve, reject) => {
      pending.set(id, { resolve, reject });
      port1.postMessage({ cdp: command });
    });
  }

  function signIn({ clientId, scopes, imsEnvironment } = {}) {
    const id = ++next;
    return new Promise((resolve, reject) => {
      open.set(id, ({ token, error }) => {
        open.delete(id);
        if (token) resolve(token);
        else reject(new Error(error ?? 'slicc-extension: the sign-in failed'));
      });
      port1.postMessage({ id, signIn: { clientId, scopes, imsEnvironment } });
    });
  }

  Object.defineProperty(globalThis, 'sliccExtension', {
    value: Object.freeze({
      version: _seven.version,
      fetch: relayFetch,
      signIn,
      cdp: Object.freeze({
        send,
        on(listener) {
          listeners.add(listener);
          return () => listeners.delete(listener);
        },
      }),
    }),
  });
})();
