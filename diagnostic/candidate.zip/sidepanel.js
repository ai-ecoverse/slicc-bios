var CherryUnsupportedError = class extends Error {
  code = -32601;
  constructor(method) {
    super(`Cherry: unsupported CDP method '${method}'`);
    this.name = "CherryUnsupportedError";
  }
};
var CHERRY_PROTOCOL_VERSION = 2;
var KINDS = /* @__PURE__ */ new Set(["handshake.hello", "handshake.welcome", "handshake.version-mismatch", "cdp.request", "cdp.response", "cdp.event", "permission.request", "permission.response", "host.event", "slicc.event", "session.export.request", "session.export.cancel", "session.export.progress", "session.export.response", "session.export.error"]);
function isCherryEnvelope(value, versions = [CHERRY_PROTOCOL_VERSION]) {
  if (typeof value !== "object" || value === null) return false;
  const v = value;
  if (typeof v.cherry !== "number" || !versions.includes(v.cherry) || typeof v.channelId !== "string" || typeof v.kind !== "string" || !KINDS.has(v.kind)) return false;
  const k = v.kind;
  if (k === "handshake.version-mismatch" && typeof v.peerVersion !== "number") return false;
  if (k === "session.export.request" || k === "session.export.cancel" || k === "session.export.progress" || k === "session.export.response" || k === "session.export.error") {
    if (typeof v.requestId !== "string" || v.requestId === "") return false;
    if (k === "session.export.progress" && typeof v.phase !== "string") return false;
    if (k === "session.export.response" && !(v.blob instanceof Blob)) return false;
    if (k === "session.export.error" && typeof v.code !== "string") return false;
  }
  return true;
}
function acceptEnvelope(event, ctx) {
  if (!ctx.allowOrigins.includes(event.origin)) return false;
  if (ctx.expectedSource !== null && event.source !== ctx.expectedSource) return false;
  if (!isCherryEnvelope(event.data, ctx.versions)) return false;
  if (ctx.channelId !== null && event.data.channelId !== ctx.channelId) return false;
  return true;
}
function isCherryVersionMismatch(value, supported = [CHERRY_PROTOCOL_VERSION]) {
  if (typeof value !== "object" || value === null) return false;
  const v = value;
  return typeof v.cherry === "number" && !supported.includes(v.cherry) && typeof v.channelId === "string" && typeof v.kind === "string";
}
var TranscriptExportError = class extends Error {
  code;
  constructor(code) {
    super(code);
    this.code = code;
    this.name = "TranscriptExportError";
  }
};
var MISMATCH_HOOK_GRACE_MS = 250;
function buildWelcomeEnvelope(newChannelId, options) {
  const resolvedFeatures = { terminal: true, files: true, memory: true, browser: true, modelPicker: true, history: true, nav: true, monitor: true, showTimestamps: true, ...options.features };
  let themeJson;
  if (options.theme) {
    try {
      themeJson = JSON.stringify(options.theme);
    } catch (err) {
      console.warn("[cherry] options.theme is not JSON-serializable \u2014 sending no theme", err);
    }
  }
  let layoutJson;
  if (options.layout) {
    try {
      layoutJson = JSON.stringify(options.layout);
    } catch (err) {
      console.warn("[cherry] options.layout is not JSON-serializable \u2014 sending no layout", err);
    }
  }
  let flagsJson;
  if (options.flags) {
    try {
      flagsJson = JSON.stringify(options.flags);
    } catch (err) {
      console.warn("[cherry] options.flags is not JSON-serializable \u2014 sending no flags", err);
    }
  }
  return { cherry: CHERRY_PROTOCOL_VERSION, channelId: newChannelId, kind: "handshake.welcome", joinUrl: options.joinToken, features: resolvedFeatures, ...themeJson ? { theme: themeJson } : {}, ...layoutJson ? { layout: layoutJson } : {}, ...options.effortLevel ? { effortLevel: options.effortLevel } : {}, ...flagsJson ? { flags: flagsJson } : {} };
}
function settlePending(pending, requestId, outcome) {
  const entry = pending.get(requestId);
  if (!entry) return;
  entry.signal?.removeEventListener("abort", entry.onAbort);
  pending.delete(requestId);
  if ("resolve" in outcome) entry.resolve(outcome.resolve);
  else entry.reject(outcome.reject);
}
function rejectAllPending(pending, code) {
  for (const [id, entry] of pending) {
    entry.signal?.removeEventListener("abort", entry.onAbort);
    entry.reject(new TranscriptExportError(code));
    pending.delete(id);
  }
}
function handleExportProgress(pending, env) {
  pending.get(env.requestId)?.onProgress?.({ phase: env.phase, processedBytes: env.processedBytes, estimatedBytes: env.estimatedBytes });
}
function handleExportResponse(pending, env) {
  if (!(env.blob instanceof Blob) || env.blob.type !== "application/zip") {
    settlePending(pending, env.requestId, { reject: new TranscriptExportError("transfer-corrupt") });
    return;
  }
  settlePending(pending, env.requestId, { resolve: env.blob });
}
var VALID_EXPORT_CODES = /* @__PURE__ */ new Set(["permission-denied", "redaction-unavailable", "session-not-found", "transfer-aborted", "transfer-corrupt", "schema-invalid", "attachment-unreadable"]);
function handleExportError(pending, env) {
  const code = VALID_EXPORT_CODES.has(env.code) ? env.code : "transfer-corrupt";
  settlePending(pending, env.requestId, { reject: new TranscriptExportError(code) });
}
function unsupportedHostHandler() {
  return async (method) => {
    throw new CherryUnsupportedError(method);
  };
}
async function dispatchCdp(env, hostHandler, onPermissionRequest) {
  const domain = env.method.split(".")[0] ?? env.method;
  try {
    const granted = onPermissionRequest ? await onPermissionRequest(domain) : true;
    if (!granted) {
      return { error: { code: -32601, message: `Cherry: permission denied for ${domain}` } };
    }
    return { result: await hostHandler(env.method, env.params ?? {}) };
  } catch (err) {
    if (err instanceof CherryUnsupportedError) return { error: { code: err.code, message: err.message } };
    return { error: { code: -32e3, message: err instanceof Error ? err.message : String(err) } };
  }
}
function buildExportSession(pending, post, getChannelId) {
  return function exportSession(opts) {
    const channelId = getChannelId();
    if (channelId === null) return Promise.reject(new TranscriptExportError("transfer-aborted"));
    const signal = opts?.signal;
    if (signal?.aborted) return Promise.reject(new TranscriptExportError("transfer-aborted"));
    const requestId = crypto.randomUUID();
    return new Promise((resolve, reject) => {
      const onAbort = () => {
        if (!pending.has(requestId)) return;
        pending.delete(requestId);
        post({ cherry: CHERRY_PROTOCOL_VERSION, channelId, kind: "session.export.cancel", requestId });
        reject(new TranscriptExportError("transfer-aborted"));
      };
      pending.set(requestId, { resolve, reject, onProgress: opts?.onProgress, onAbort, signal });
      signal?.addEventListener("abort", onAbort, { once: true });
      const env = { cherry: CHERRY_PROTOCOL_VERSION, channelId, kind: "session.export.request", requestId };
      if (opts?.sessionId !== void 0) env.sessionId = opts.sessionId;
      post(env);
    });
  };
}
function buildSkewedHelloHandler(pendingMismatchHooks, post, hooks) {
  return (data) => {
    if (pendingMismatchHooks.has(data.channelId)) return;
    post({ cherry: CHERRY_PROTOCOL_VERSION, channelId: data.channelId, kind: "handshake.version-mismatch", peerVersion: data.cherry });
    pendingMismatchHooks.set(data.channelId, setTimeout(() => {
      pendingMismatchHooks.delete(data.channelId);
      hooks?.onProtocolMismatch?.(data.cherry, CHERRY_PROTOCOL_VERSION);
    }, MISMATCH_HOOK_GRACE_MS));
  };
}
function mountSliccImpl(options) {
  const sdkCreatedIframe = !options.iframe;
  const iframe = options.iframe ?? document.createElement("iframe");
  const src = new URL(options.sliccOrigin);
  const sliccOrigin = src.origin;
  src.searchParams.set("cherry", "1");
  if (options.uiOnly) src.searchParams.set("ui-only", "1");
  iframe.src = src.toString();
  if (sdkCreatedIframe) {
    iframe.style.border = "0";
    iframe.style.width = "100%";
    iframe.style.height = "100%";
    options.container?.appendChild(iframe);
  }
  let channelId = null;
  const pending = /* @__PURE__ */ new Map();
  const hostHandler = options.__hostHandler ?? unsupportedHostHandler();
  const post = (env) => {
    if (options.__test_post) {
      options.__test_post(env);
      return;
    }
    iframe.contentWindow?.postMessage(env, sliccOrigin);
  };
  const exportSession = buildExportSession(pending, post, () => channelId);
  const pendingMismatchHooks = /* @__PURE__ */ new Map();
  const handleVersionSkewedHello = buildSkewedHelloHandler(pendingMismatchHooks, post, options.hooks);
  const handleEnvelope = async (env) => {
    switch (env.kind) {
      case "handshake.hello": {
        const mismatchTimer = pendingMismatchHooks.get(env.channelId);
        if (mismatchTimer !== void 0) {
          clearTimeout(mismatchTimer);
          pendingMismatchHooks.delete(env.channelId);
        }
        rejectAllPending(pending, "transfer-aborted");
        channelId = env.channelId;
        post(buildWelcomeEnvelope(channelId, options));
        options.hooks?.onHandshakeComplete?.();
        return void 0;
      }
      case "cdp.request": {
        const resp = await dispatchCdp(env, hostHandler, options.hooks?.onPermissionRequest);
        post({ cherry: CHERRY_PROTOCOL_VERSION, channelId, kind: "cdp.response", id: env.id, ...resp });
        return resp;
      }
      case "slicc.event": {
        options.hooks?.onSliccEvent?.(env.name, env.detail);
        if (env.name === "open-url" && options.capabilities.openUrl) {
          const url = env.detail?.url;
          if (url) options.hooks?.onOpenUrl?.(url);
        }
        return void 0;
      }
      case "session.export.progress":
        handleExportProgress(pending, env);
        return void 0;
      case "session.export.response":
        handleExportResponse(pending, env);
        return void 0;
      case "session.export.error":
        handleExportError(pending, env);
        return void 0;
      default:
        return void 0;
    }
  };
  const passesTrust = (ev) => ev.origin === sliccOrigin && ev.source === iframe.contentWindow;
  const isReHello = (ev) => channelId !== null && passesTrust(ev) && isCherryEnvelope(ev.data) && ev.data.kind === "handshake.hello" && ev.data.channelId !== channelId;
  const onEnvelopeError = (err) => console.error("[cherry] envelope handling failed", err);
  const onMessage = (event) => {
    if (isReHello(event)) {
      console.info("[cherry] re-hello from reloaded iframe \u2014 re-handshaking", { oldChannelId: channelId, newChannelId: event.data.channelId });
      void handleEnvelope(event.data).catch(onEnvelopeError);
      return;
    }
    if (!acceptEnvelope(event, { allowOrigins: [sliccOrigin], expectedSource: iframe.contentWindow, channelId })) {
      if (isCherryVersionMismatch(event.data)) {
        console.warn("[cherry] protocol version mismatch \u2014 update the older side", { peerVersion: event.data.cherry, ourVersion: CHERRY_PROTOCOL_VERSION });
        if (passesTrust(event) && event.data.kind === "handshake.hello" && event.data.channelId !== channelId) {
          handleVersionSkewedHello(event.data);
        }
      } else if (isCherryEnvelope(event.data)) {
        console.warn("[cherry] rejected a cherry envelope (origin/source/channel mismatch)", { origin: event.origin, expectedOrigin: sliccOrigin });
      }
      return;
    }
    void handleEnvelope(event.data).catch(onEnvelopeError);
  };
  window.addEventListener("message", onMessage);
  return { iframe, emitHostEvent(name, detail) {
    if (channelId === null) {
      console.warn("[cherry] emitHostEvent dropped before handshake completed", { name });
      return;
    }
    post({ cherry: CHERRY_PROTOCOL_VERSION, channelId, kind: "host.event", name, detail });
  }, exportSession, destroy() {
    window.removeEventListener("message", onMessage);
    rejectAllPending(pending, "transfer-aborted");
    for (const [, timer] of pendingMismatchHooks) clearTimeout(timer);
    pendingMismatchHooks.clear();
    if (sdkCreatedIframe) iframe.remove();
  }, testReceive: (env) => handleEnvelope(env) };
}
function mountSlicc(options) {
  if (!options?.container && !options?.iframe) {
    throw new Error("mountSlicc: either options.container or options.iframe is required");
  }
  return mountSliccImpl(options);
}
function nextBackoffDelayMs({ attempt, baseMs, capMs, jitter = 0, maxShift, random = Math.random }) {
  let shift = Math.max(0, attempt);
  if (maxShift !== void 0) shift = Math.min(shift, maxShift);
  const exp = baseMs * 2 ** shift;
  const capped = capMs === void 0 ? exp : Math.min(capMs, exp);
  if (jitter <= 0) return capped;
  const withJitter = capped + Math.round(capped * jitter * random());
  return capMs === void 0 ? withJitter : Math.min(capMs, withJitter);
}
var SLICC_HOSTED_ORIGIN = "https://www.sliccy.ai";
var nudgeInFlight = /* @__PURE__ */ new WeakSet();
function nudgeIframeRepaint(iframe, onDone) {
  if (nudgeInFlight.has(iframe)) {
    onDone?.();
    return;
  }
  let rafRestored = false;
  performNudge(iframe, onDone, () => {
    rafRestored = true;
  });
  setTimeout(() => {
    if (rafRestored) return;
    if (!iframe.isConnected) return;
    performNudge(iframe);
  }, 500);
}
function performNudge(iframe, onDone, onRafRestore) {
  if (nudgeInFlight.has(iframe)) {
    onDone?.();
    return;
  }
  nudgeInFlight.add(iframe);
  const previousDisplay = iframe.style.display;
  iframe.style.display = "none";
  let restored = false;
  const restore = (viaRaf) => {
    if (restored) return;
    restored = true;
    iframe.style.display = previousDisplay;
    nudgeInFlight.delete(iframe);
    if (viaRaf) onRafRestore?.();
    onDone?.();
  };
  const raf = globalThis.requestAnimationFrame;
  if (typeof raf === "function") {
    raf(() => {
      raf(() => restore(true));
    });
  }
  setTimeout(() => restore(false), 100);
}
var CHERRY_PANEL_PORT_NAME = "cherry-panel";
var SIDE_PANEL_FEATURES = { terminal: false, files: false, memory: false, browser: false, monitor: false, modelPicker: false, history: true, nav: true };
var sliccOriginDefault = false ? "http://localhost:8787" : SLICC_HOSTED_ORIGIN;
var BOOT_TIMEOUT_MS = 2e4;
var IFRAME_LOAD_TIMEOUT_MS = 15e3;
var PANEL_STATUS_TEXT = { starting: "Starting SLICC\u2026", slow: "SLICC is still starting in its tab. Chrome slows down background tabs, so bringing it to the front usually lets it finish.", live: "", disconnected: "Disconnected from SLICC." };
var PANEL_ACTION_LABEL = { slow: "Show SLICC tab", disconnected: "Retry" };
function oneShotTimer() {
  let id = null;
  const clear = () => {
    if (id) clearTimeout(id);
    id = null;
  };
  return { clear, start(ms, fn) {
    clear();
    id = setTimeout(() => {
      id = null;
      fn();
    }, ms);
  } };
}
function disconnectQuietly(port) {
  try {
    port?.disconnect();
  } catch {
  }
}
function createSidePanelController(deps) {
  let handle = null;
  let currentJoinUrl = null;
  let disposed = false;
  let port = null;
  let reconnectAttempt = 0;
  const bootTimer = oneShotTimer();
  const iframeLoadTimer = oneShotTimer();
  let bootSlow = false;
  const blankIframe = () => {
    deps.iframe.setAttribute("src", "about:blank");
  };
  const teardown = () => {
    bootTimer.clear();
    bootSlow = false;
    iframeLoadTimer.clear();
    handle?.destroy();
    handle = null;
    currentJoinUrl = null;
    blankIframe();
  };
  const goDisconnected = () => {
    teardown();
    deps.setStatus("disconnected");
  };
  const onIframeLoad = () => {
    if (deps.iframe.getAttribute("src") === "about:blank") return;
    iframeLoadTimer.clear();
    nudgeIframeRepaint(deps.iframe);
  };
  deps.iframe.addEventListener("load", onIframeLoad);
  deps.iframe.addEventListener("error", () => {
    if (!disposed && handle) goDisconnected();
  });
  const requestLeaderFocus = (openSettings) => {
    try {
      port?.postMessage({ kind: "focus-leader", openSettings });
    } catch {
    }
  };
  const onMessage = (raw) => {
    const msg = raw;
    if (msg?.kind !== "join-url") return;
    if (msg.state === "booting") {
      if (handle) {
        deps.setStatus("live");
        return;
      }
      if (bootSlow) {
        deps.setStatus("slow");
        return;
      }
      deps.setStatus("starting");
      bootTimer.start(BOOT_TIMEOUT_MS, () => {
        if (disposed) return;
        bootSlow = true;
        deps.setStatus("slow");
      });
      return;
    }
    if (msg.state === "disconnected") {
      goDisconnected();
      return;
    }
    reconnectAttempt = 0;
    bootTimer.clear();
    bootSlow = false;
    if (msg.joinUrl === currentJoinUrl && handle) {
      deps.setStatus("live");
      return;
    }
    handle?.destroy();
    handle = null;
    blankIframe();
    currentJoinUrl = msg.joinUrl;
    iframeLoadTimer.start(IFRAME_LOAD_TIMEOUT_MS, () => {
      if (!disposed && handle) goDisconnected();
    });
    handle = deps.mountSlicc({ iframe: deps.iframe, joinToken: msg.joinUrl, uiOnly: true, sliccOrigin: deps.sliccOrigin, capabilities: { navigate: false, screenshot: "none", openUrl: false }, features: SIDE_PANEL_FEATURES, hooks: { onSliccEvent: (name) => {
      if (name === "slicc.open-leader-tab") requestLeaderFocus(true);
      if (name === "slicc.focus-leader-tab") requestLeaderFocus(false);
    } } });
    deps.setStatus("live");
  };
  const wire = () => {
    try {
      port = deps.connect();
    } catch {
      port = null;
      return;
    }
    port.onMessage.addListener(onMessage);
    port.onDisconnect.addListener(() => {
      port = null;
      if (disposed) return;
      setTimeout(() => {
        if (!disposed) wire();
      }, nextBackoffDelayMs({ attempt: reconnectAttempt, baseMs: 250, capMs: 5e3 }));
      reconnectAttempt += 1;
    });
    try {
      port.postMessage({ kind: "hello" });
    } catch {
    }
  };
  wire();
  return { focusLeader: () => requestLeaderFocus(false), retry() {
    if (disposed) return;
    disconnectQuietly(port);
    port = null;
    reconnectAttempt = 0;
    wire();
  }, dispose() {
    disposed = true;
    teardown();
    deps.iframe.removeEventListener("load", onIframeLoad);
    disconnectQuietly(port);
  } };
}
if (typeof chrome !== "undefined" && chrome?.runtime?.id) {
  const iframe = document.getElementById("cherry-follower");
  const statusEl = document.getElementById("cherry-status");
  const statusText = document.getElementById("cherry-status-text");
  const actionButton = document.getElementById("cherry-status-action");
  let current = "starting";
  const setStatus = (s) => {
    current = s;
    if (!statusEl) return;
    if (statusText) statusText.textContent = PANEL_STATUS_TEXT[s];
    if (actionButton) {
      const label = PANEL_ACTION_LABEL[s];
      actionButton.hidden = !label;
      actionButton.textContent = label ?? "";
    }
    statusEl.dataset.state = s;
  };
  const controller = createSidePanelController({ connect: () => chrome.runtime.connect({ name: CHERRY_PANEL_PORT_NAME }), mountSlicc, iframe, setStatus, sliccOrigin: sliccOriginDefault });
  actionButton?.addEventListener("click", () => {
    if (current === "disconnected") controller.retry();
    else controller.focusLeader();
  });
}
export { createSidePanelController };
