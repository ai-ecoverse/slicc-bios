"use strict";
(() => {
  var OAUTH_EXTRA_DOMAINS_KEY = "slicc_oauth_extra_domains";
  function readOAuthExtras(storage2) {
    try {
      const raw = storage2.getItem(OAUTH_EXTRA_DOMAINS_KEY);
      if (!raw) return {};
      const parsed = JSON.parse(raw);
      if (parsed == null || typeof parsed !== "object" || Array.isArray(parsed)) return {};
      const out = {};
      for (const [k, v] of Object.entries(parsed)) {
        if (typeof k !== "string" || !Array.isArray(v)) continue;
        const cleaned = v.filter((d) => typeof d === "string" && d.length > 0);
        if (cleaned.length > 0) out[k] = cleaned;
      }
      return out;
    } catch {
      return {};
    }
  }
  function writeOAuthExtras(storage2, store) {
    try {
      storage2.setItem(OAUTH_EXTRA_DOMAINS_KEY, JSON.stringify(store));
    } catch (err) {
      throw new Error(`Failed to persist OAuth extras (localStorage quota exceeded?): ${err instanceof Error ? err.message : String(err)}`);
    }
  }
  function addOAuthExtraDomain(storage2, providerId, domain) {
    if (!providerId || !domain) return { added: false, reason: "provider and domain required" };
    const store = readOAuthExtras(storage2);
    const current = store[providerId] ?? [];
    const lower = domain.toLowerCase();
    if (current.some((d) => d.toLowerCase() === lower)) {
      return { added: false, reason: "duplicate" };
    }
    store[providerId] = [...current, domain];
    try {
      writeOAuthExtras(storage2, store);
    } catch (err) {
      return { added: false, reason: err instanceof Error ? err.message : String(err) };
    }
    return { added: true };
  }
  function removeOAuthExtraDomain(storage2, providerId, domain) {
    const store = readOAuthExtras(storage2);
    const current = store[providerId] ?? [];
    const lower = domain.toLowerCase();
    const next = current.filter((d) => d.toLowerCase() !== lower);
    if (next.length === current.length) return { removed: false };
    if (next.length === 0) delete store[providerId];
    else store[providerId] = next;
    writeOAuthExtras(storage2, store);
    return { removed: true };
  }
  function clearOAuthExtras(storage2, providerId) {
    const store = readOAuthExtras(storage2);
    delete store[providerId];
    writeOAuthExtras(storage2, store);
  }
  var DOMAINS_SUFFIX = "_DOMAINS";
  var PROFILE_RE = /^[a-zA-Z0-9._-]+$/;
  function deriveS3Domains(endpoint) {
    if (!endpoint) return ["*.amazonaws.com"];
    try {
      const url = new URL(endpoint);
      const parts = url.host.split(".");
      return parts.length >= 3 ? [`*.${parts.slice(1).join(".")}`] : [url.host];
    } catch {
      return ["*.amazonaws.com"];
    }
  }
  function validateS3ProfileInput(input) {
    if (!input.profile || !PROFILE_RE.test(input.profile)) {
      return { ok: false, error: "Profile name must be alphanumeric / dot / underscore / hyphen" };
    }
    if (!input.accessKey) return { ok: false, error: "Access Key ID is required" };
    if (!input.secretKey) return { ok: false, error: "Secret Access Key is required" };
    const resolvedDomains = input.domains && input.domains.length > 0 ? input.domains : deriveS3Domains(input.endpoint);
    return { ok: true, resolvedDomains };
  }
  var DB_NAME = "slicc-secrets";
  var DB_VERSION = 2;
  var RECORD_STORE = "records";
  var STORE_NAME = "keys";
  var KEY_ID = "aes-gcm-secrets";
  var UNREADABLE_SECRET = /* @__PURE__ */ Symbol.for("slicc:unreadable-secret");
  function openDb() {
    return new Promise((resolve, reject) => {
      if (typeof indexedDB === "undefined") {
        reject(new Error("IndexedDB not available"));
        return;
      }
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME);
        }
        if (!db.objectStoreNames.contains(RECORD_STORE)) db.createObjectStore(RECORD_STORE);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error ?? new Error("IndexedDB open failed"));
    });
  }
  async function getOrCreateKey() {
    const db = await openDb();
    try {
      const existing = await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, "readonly");
        const req = tx.objectStore(STORE_NAME).get(KEY_ID);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
      if (existing) return existing;
      const candidate = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
      return await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, "readwrite");
        const store = tx.objectStore(STORE_NAME);
        const getReq = store.get(KEY_ID);
        getReq.onsuccess = () => {
          if (getReq.result) {
            resolve(getReq.result);
            return;
          }
          const putReq = store.put(candidate, KEY_ID);
          putReq.onsuccess = () => resolve(candidate);
          putReq.onerror = () => reject(putReq.error);
        };
        getReq.onerror = () => reject(getReq.error);
        tx.onerror = () => reject(tx.error);
      });
    } finally {
      db.close();
    }
  }
  var keyPromise = null;
  function cachedKey() {
    if (!keyPromise) keyPromise = getOrCreateKey();
    return keyPromise;
  }
  function isEncryptedValue(v) {
    return typeof v === "object" && v !== null && typeof v.ct === "string" && typeof v.iv === "string";
  }
  function toBase64(buf) {
    return btoa(String.fromCharCode(...new Uint8Array(buf)));
  }
  function fromBase64(b64) {
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return arr.buffer;
  }
  async function encryptValue(plaintext) {
    const key = await cachedKey();
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(plaintext));
    return { ct: toBase64(ct), iv: toBase64(iv.buffer) };
  }
  async function decryptValue(encrypted) {
    try {
      const key = await cachedKey();
      const plainBuf = await crypto.subtle.decrypt({ name: "AES-GCM", iv: fromBase64(encrypted.iv) }, key, fromBase64(encrypted.ct));
      return new TextDecoder().decode(plainBuf);
    } catch {
      return UNREADABLE_SECRET;
    }
  }
  async function recordTx(mode, fn) {
    const db = await openDb();
    try {
      return await new Promise((resolve, reject) => {
        const tx = db.transaction(RECORD_STORE, mode);
        const store = tx.objectStore(RECORD_STORE);
        let out;
        try {
          fn(store, (v) => {
            out = v;
          });
        } catch (e) {
          reject(e);
        }
        tx.oncomplete = () => resolve(out);
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error ?? new Error("IndexedDB transaction aborted"));
      });
    } finally {
      db.close();
    }
  }
  function allRecords() {
    return recordTx("readonly", (s, done) => {
      const r = s.getAll();
      r.onsuccess = () => done(r.result ?? []);
    });
  }
  function getRecord(name) {
    return recordTx("readonly", (s, done) => {
      const r = s.get(name);
      r.onsuccess = () => done(r.result);
    });
  }
  function putRecords(records) {
    return recordTx("readwrite", (s) => {
      for (const rec of records) s.put(rec, rec.name);
    });
  }
  function deleteRecords(names) {
    return recordTx("readwrite", (s) => {
      for (const n of names) s.delete(n);
    });
  }
  function putRecordIfAbsent(rec) {
    return recordTx("readwrite", (s, done) => {
      const g = s.get(rec.name);
      g.onsuccess = () => {
        if (g.result) {
          done(false);
          return;
        }
        s.put(rec, rec.name);
        done(true);
      };
    });
  }
  function sameValue(a, b) {
    if (typeof a === "string" || typeof b === "string") return a === b;
    return isEncryptedValue(a) && isEncryptedValue(b) && a.ct === b.ct && a.iv === b.iv;
  }
  async function decryptRecord(value) {
    const dec = await decryptValue(value);
    return dec === UNREADABLE_SECRET ? void 0 : dec;
  }
  async function migrateSecretsToEncrypted() {
    const all = await chrome.storage.local.get(null);
    const names = Object.keys(all).filter((k) => !k.endsWith(DOMAINS_SUFFIX) && k + DOMAINS_SUFFIX in all && (typeof all[k] === "string" || isEncryptedValue(all[k])));
    for (const name of names) {
      const dk = name + DOMAINS_SUFFIX;
      const fresh = await chrome.storage.local.get([name, dk]);
      const value = fresh[name];
      if (typeof value !== "string" && !isEncryptedValue(value)) continue;
      const enc = typeof value === "string" ? await encryptValue(value) : value;
      const again = await chrome.storage.local.get([name, dk]);
      if (!sameValue(again[name], value) || again[dk] !== fresh[dk]) continue;
      await putRecordIfAbsent({ name, value: enc, domains: typeof fresh[dk] === "string" ? fresh[dk] : "" });
      const last = await chrome.storage.local.get([name, dk]);
      if (sameValue(last[name], value) && last[dk] === fresh[dk]) await chrome.storage.local.remove([name, dk]);
    }
  }
  var migrationPromise = null;
  function ensureMigrated() {
    if (!migrationPromise) {
      migrationPromise = migrateSecretsToEncrypted().catch((err) => {
        migrationPromise = null;
        console.error("[slicc] secrets migration failed", err);
        throw err;
      });
    }
    return migrationPromise;
  }
  var encryptedStorage = { async get(keys) {
    await ensureMigrated();
    const out = {};
    for (const rec of await allRecords()) {
      const dec = await decryptRecord(rec.value);
      if (dec !== void 0) out[rec.name] = dec;
      out[rec.name + DOMAINS_SUFFIX] = rec.domains ?? "";
    }
    if (keys === null || keys === void 0) return out;
    const wanted = typeof keys === "string" ? [keys] : Array.isArray(keys) ? keys : Object.keys(keys);
    const picked = {};
    for (const k of wanted) if (k in out) picked[k] = out[k];
    return picked;
  }, async set(items) {
    await ensureMigrated();
    const changes = /* @__PURE__ */ new Map();
    for (const [k, v] of Object.entries(items)) {
      const isDomains = k.endsWith(DOMAINS_SUFFIX);
      const base = isDomains ? k.slice(0, -DOMAINS_SUFFIX.length) : k;
      const c = changes.get(base) ?? {};
      if (isDomains) c.domains = typeof v === "string" ? v : "";
      else c.value = v;
      changes.set(base, c);
    }
    const records = [];
    for (const [name, c] of changes) {
      const rec = await getRecord(name) ?? { name, value: void 0, domains: "" };
      if ("value" in c) rec.value = typeof c.value === "string" ? await encryptValue(c.value) : c.value;
      if ("domains" in c) rec.domains = c.domains;
      if (rec.value !== void 0) records.push(rec);
    }
    await putRecords(records);
  }, async remove(keys) {
    await ensureMigrated();
    const list = typeof keys === "string" ? [keys] : keys;
    const names = [];
    const cleared = [];
    for (const k of list) {
      if (k.endsWith(DOMAINS_SUFFIX)) cleared.push(k.slice(0, -DOMAINS_SUFFIX.length));
      else names.push(k);
    }
    const records = [];
    for (const n of cleared) {
      if (names.includes(n)) continue;
      const rec = await getRecord(n);
      if (rec) {
        rec.domains = "";
        records.push(rec);
      }
    }
    if (records.length) await putRecords(records);
    if (names.length) await deleteRecords(names);
  } };
  async function listSecretsIncludingUnreadable() {
    await ensureMigrated();
    const result = [];
    for (const rec of await allRecords()) {
      const domains = (rec.domains ?? "").split(",").map((d) => d.trim()).filter(Boolean);
      result.push({ name: rec.name, domains, unreadable: await decryptRecord(rec.value) === void 0 });
    }
    result.sort((a, b) => a.name.localeCompare(b.name));
    return result;
  }
  async function setSecret(storage2, name, value, domains) {
    await storage2.set({ [name]: value, [name + DOMAINS_SUFFIX]: domains.join(",") });
  }
  async function deleteSecret(storage2, name) {
    await storage2.remove([name, name + DOMAINS_SUFFIX]);
  }
  async function saveS3Profile(storage2, input) {
    const v = validateS3ProfileInput(input);
    if (!v.ok) return v;
    const domains = v.resolvedDomains;
    const prefix = `s3.${input.profile}`;
    await setSecret(storage2, `${prefix}.access_key_id`, input.accessKey, domains);
    await setSecret(storage2, `${prefix}.secret_access_key`, input.secretKey, domains);
    if (input.region) await setSecret(storage2, `${prefix}.region`, input.region, domains);
    if (input.endpoint) await setSecret(storage2, `${prefix}.endpoint`, input.endpoint, domains);
    if (input.pathStyle === true) {
      await setSecret(storage2, `${prefix}.path_style`, "true", domains);
    } else {
      await deleteSecret(storage2, `${prefix}.path_style`);
    }
    return v;
  }
  function validateCustomSecretInput(input) {
    if (!input.name) return { ok: false, error: "Name is required" };
    if (!input.value) return { ok: false, error: "Value is required" };
    if (input.domains.length === 0) {
      return { ok: false, error: "At least one domain pattern is required" };
    }
    return { ok: true };
  }
  async function saveCustomSecret(storage2, input) {
    const v = validateCustomSecretInput(input);
    if (!v.ok) return v;
    await setSecret(storage2, input.name, input.value, input.domains);
    return v;
  }
  var $ = (id) => document.getElementById(id);
  function applyElProps(node, props) {
    for (const [k, v] of Object.entries(props)) {
      if (k === "class") node.className = v;
      else if (k === "dataset") Object.assign(node.dataset, v);
      else if (k === "text") node.textContent = v;
      else if (k === "on") {
        for (const [evt, fn] of Object.entries(v)) {
          node.addEventListener(evt, fn);
        }
      } else if (k.startsWith("style:")) {
        node.style.setProperty(k.slice(6), v);
      } else {
        node.setAttribute(k, v);
      }
    }
  }
  function el(tag, props, ...children) {
    const node = document.createElement(tag);
    if (props) applyElProps(node, props);
    for (const child of children) {
      if (child == null) continue;
      node.appendChild(typeof child === "string" ? document.createTextNode(child) : child);
    }
    return node;
  }
  function showToast(msg, isError = false) {
    const t = $("toast");
    t.textContent = msg;
    t.classList.toggle("error", isError);
    t.classList.add("show");
    setTimeout(() => t.classList.remove("show"), 2200);
  }
  function reportAsyncError(err) {
    showToast(`Failed: ${err}`, true);
  }
  function refreshList() {
    renderList().catch(reportAsyncError);
  }
  var storage = encryptedStorage;
  function createCopyNameButton(entry) {
    return el("button", { class: "btn-secondary btn", text: "Copy name", "style:font-size": "11px", "style:padding": "4px 8px", on: { click: async () => {
      try {
        await navigator.clipboard.writeText(entry.name);
        showToast(`Copied "${entry.name}"`);
      } catch {
        showToast("Clipboard failed", true);
      }
    } } });
  }
  function createDeleteSecretButton(entry) {
    return el("button", { class: "btn-danger", text: "Delete", on: { click: async () => {
      if (!confirm(`Delete secret "${entry.name}"?`)) return;
      try {
        await deleteSecret(storage, entry.name);
        showToast(`Deleted ${entry.name}`);
        refreshList();
      } catch (err) {
        showToast(`Failed: ${err}`, true);
      }
    } } });
  }
  var UNREADABLE_SECRET_COPY = "This value can't be read any more. Enter it again.";
  function activatePane(target) {
    document.querySelectorAll(".tab").forEach((t) => {
      t.classList.toggle("active", t.dataset.pane === target);
    });
    document.querySelectorAll(".pane").forEach((p) => {
      p.classList.toggle("active", p.id === `pane-${target}`);
    });
  }
  function prefillCustomSecret(entry) {
    activatePane("custom");
    $("c-name").value = entry.name;
    $("c-domains").value = entry.domains.join(", ");
    const value = $("c-value");
    value.value = "";
    $("pane-custom")?.scrollIntoView?.({ block: "nearest" });
    value.focus();
  }
  function createReenterButton(entry) {
    return el("button", { class: "btn-secondary btn", text: "Re-enter", "style:font-size": "11px", "style:padding": "4px 8px", on: { click: () => prefillCustomSecret(entry) } });
  }
  function createSecretRow(entry) {
    const buttons = entry.unreadable ? [createReenterButton(entry), createCopyNameButton(entry), createDeleteSecretButton(entry)] : [createCopyNameButton(entry), createDeleteSecretButton(entry)];
    return el("div", { class: entry.unreadable ? "secret-row secret-row-unreadable" : "secret-row", dataset: { name: entry.name } }, el("div", { class: "secret-meta" }, el("div", { class: "secret-name", text: entry.name }), el("div", { class: "secret-domains", text: entry.domains.join(", ") }), ...entry.unreadable ? [el("div", { class: "secret-unreadable", text: UNREADABLE_SECRET_COPY })] : []), ...buttons);
  }
  async function renderList() {
    const container = $("list");
    container.replaceChildren();
    let entries;
    try {
      entries = await listSecretsIncludingUnreadable();
    } catch (err) {
      container.appendChild(el("div", { class: "empty", text: `Failed to read storage: ${err}` }));
      return;
    }
    if (entries.length === 0) {
      container.appendChild(el("div", { class: "empty", text: "No secrets stored. Add one below." }));
      return;
    }
    for (const entry of entries) {
      container.appendChild(createSecretRow(entry));
    }
  }
  function setupTabs() {
    document.querySelectorAll(".tab").forEach((tab) => {
      tab.addEventListener("click", () => activatePane(tab.dataset.pane ?? ""));
    });
  }
  function parseCommaDomains(raw) {
    const domains = raw.trim().split(",").map((d) => d.trim()).filter(Boolean);
    return domains.length > 0 ? domains : void 0;
  }
  async function onSaveS3() {
    const result = await saveS3Profile(storage, { profile: $("s3-profile").value.trim(), accessKey: $("s3-key").value.trim(), secretKey: $("s3-secret").value, region: $("s3-region").value.trim() || void 0, endpoint: $("s3-endpoint").value.trim() || void 0, pathStyle: $("s3-pathstyle").value === "true", domains: parseCommaDomains($("s3-domains").value) });
    if (!result.ok) {
      showToast(result.error ?? "Failed", true);
      return;
    }
    const profileName = $("s3-profile").value.trim();
    showToast(`Saved profile "${profileName}"`);
    clearS3Form();
    refreshList();
  }
  function clearS3Form() {
    ["s3-profile", "s3-key", "s3-secret", "s3-region", "s3-endpoint", "s3-domains"].forEach((id) => {
      $(id).value = "";
    });
    $("s3-pathstyle").value = "";
  }
  async function onSaveCustom() {
    const result = await saveCustomSecret(storage, { name: $("c-name").value.trim(), value: $("c-value").value, domains: parseCommaDomains($("c-domains").value) ?? [] });
    if (!result.ok) {
      showToast(result.error ?? "Failed", true);
      return;
    }
    const name = $("c-name").value.trim();
    showToast(`Saved "${name}"`);
    clearCustomForm();
    refreshList();
  }
  function clearCustomForm() {
    ["c-name", "c-value", "c-domains"].forEach((id) => {
      $(id).value = "";
    });
  }
  function createOAuthClearButton(providerId) {
    return el("button", { class: "btn-danger", text: "Clear", on: { click: () => {
      if (!confirm(`Clear all extras for "${providerId}"?`)) return;
      clearOAuthExtras(localStorage, providerId);
      showToast(`Cleared extras for ${providerId}`);
      renderOAuthExtras();
    } } });
  }
  function createOAuthDomainRemoveButton(providerId, domain) {
    return el("button", { class: "btn-secondary btn", text: "Remove", "style:font-size": "11px", "style:padding": "4px 8px", on: { click: () => {
      const r = removeOAuthExtraDomain(localStorage, providerId, domain);
      if (r.removed) showToast(`Removed ${domain} from ${providerId}`);
      renderOAuthExtras();
    } } });
  }
  function appendOAuthProviderSection(container, providerId, domains) {
    container.appendChild(el("div", { class: "secret-row", dataset: { provider: providerId } }, el("div", { class: "secret-meta" }, el("div", { class: "secret-name", text: providerId }), el("div", { class: "secret-domains", text: domains.join(", ") })), createOAuthClearButton(providerId)));
    for (const domain of domains) {
      container.appendChild(el("div", { class: "secret-row", "style:padding-left": "24px" }, el("div", { class: "secret-meta" }, el("div", { class: "secret-domains", text: domain })), createOAuthDomainRemoveButton(providerId, domain)));
    }
  }
  function renderOAuthExtras() {
    const container = $("od-list");
    container.replaceChildren();
    const store = readOAuthExtras(localStorage);
    const providers = Object.keys(store).sort();
    if (providers.length === 0) {
      container.appendChild(el("div", { class: "empty", text: "No extras configured." }));
      return;
    }
    for (const providerId of providers) {
      const domains = store[providerId] ?? [];
      if (domains.length === 0) continue;
      appendOAuthProviderSection(container, providerId, domains);
    }
  }
  function onAddOAuthExtra() {
    const provider = $("od-provider").value.trim();
    const domain = $("od-domain").value.trim();
    if (!provider) {
      showToast("Provider is required", true);
      return;
    }
    if (!domain) {
      showToast("Domain is required", true);
      return;
    }
    const r = addOAuthExtraDomain(localStorage, provider, domain);
    if (!r.added) {
      showToast(r.reason === "duplicate" ? `Already in ${provider} extras` : r.reason ?? "Failed", true);
      return;
    }
    showToast(`Added ${domain} to ${provider}`);
    $("od-domain").value = "";
    renderOAuthExtras();
  }
  document.addEventListener("DOMContentLoaded", () => {
    setupTabs();
    refreshList();
    renderOAuthExtras();
    $("refreshBtn").addEventListener("click", () => {
      refreshList();
      renderOAuthExtras();
    });
    $("s3-save").addEventListener("click", () => {
      onSaveS3().catch(reportAsyncError);
    });
    $("s3-clear").addEventListener("click", clearS3Form);
    $("c-save").addEventListener("click", () => {
      onSaveCustom().catch(reportAsyncError);
    });
    $("c-clear").addEventListener("click", clearCustomForm);
    $("od-add").addEventListener("click", onAddOAuthExtra);
  });
})();
