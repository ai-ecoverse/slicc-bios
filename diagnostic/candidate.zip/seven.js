export const seven = {"domain":"sliccy.ai","excludedLabels":["www","vault","vault-preview","get","mcpcat","echo"],"excludedLabelPrefixes":["vault-"]};
