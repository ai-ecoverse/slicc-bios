var CHUNK_SIZE = 32768;
function nodeBuffer() {
  return globalThis.Buffer;
}
var ATOB_BASE64_RE = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}(?:==)?|[A-Za-z0-9+/]{3}=?)?$/;
var BASE64_WHITESPACE_RE = /[\t\n\f\r ]/g;
function normalizeBase64(b64) {
  const compact = b64.replace(BASE64_WHITESPACE_RE, "");
  return ATOB_BASE64_RE.test(compact) ? compact : null;
}
function padded(b64) {
  const remainder = b64.length % 4;
  return remainder === 0 ? b64 : b64 + "=".repeat(4 - remainder);
}
function base64ToUint8(b64) {
  const B = nodeBuffer();
  if (B) {
    const normalized2 = normalizeBase64(b64);
    if (normalized2 === null) throw new Error("Invalid base64 string");
    return new Uint8Array(B.from(padded(normalized2), "base64"));
  }
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}
function uint8ToBase64(bytes) {
  const compact = bytes.byteOffset === 0 && bytes.byteLength === bytes.buffer.byteLength ? bytes : bytes.slice();
  const B = nodeBuffer();
  if (B) {
    return B.from(compact).toString("base64");
  }
  let binary = "";
  for (let i = 0; i < compact.byteLength; i += CHUNK_SIZE) {
    const slice = compact.subarray(i, Math.min(i + CHUNK_SIZE, compact.byteLength));
    binary += String.fromCharCode.apply(null, slice);
  }
  return btoa(binary);
}
var SLICC_HOSTED_ORIGIN = "https://www.sliccy.ai";
function unmaskString(pipeline, hostname, value) {
  const { text } = pipeline.unmaskBody(value, hostname);
  return { text, changed: text !== value };
}
function unmaskCdpFrame(frame, hostname, pipeline) {
  if (!frame || typeof frame !== "object") return { frame, changed: false };
  if (!pipeline.hasSecrets()) return { frame, changed: false };
  const method = frame.method;
  const params = frame.params;
  if (!params || typeof params !== "object") return { frame, changed: false };
  if (method === "Runtime.evaluate") {
    const p = params;
    if (typeof p.expression !== "string") return { frame, changed: false };
    const { text, changed } = unmaskString(pipeline, hostname, p.expression);
    if (!changed) return { frame, changed: false };
    return { frame: { ...frame, params: { ...p, expression: text } }, changed: true };
  }
  if (method === "Input.insertText") {
    const p = params;
    if (typeof p.text !== "string") return { frame, changed: false };
    const { text, changed } = unmaskString(pipeline, hostname, p.text);
    if (!changed) return { frame, changed: false };
    return { frame: { ...frame, params: { ...p, text } }, changed: true };
  }
  if (method === "Runtime.callFunctionOn") {
    const p = params;
    if (!Array.isArray(p.arguments)) return { frame, changed: false };
    let argsChanged = false;
    const nextArgs = p.arguments.map((arg) => {
      if (!arg || typeof arg !== "object") return arg;
      const a = arg;
      if (typeof a.value !== "string") return arg;
      const { text, changed } = unmaskString(pipeline, hostname, a.value);
      if (!changed) return arg;
      argsChanged = true;
      return { ...a, value: text };
    });
    if (!argsChanged) return { frame, changed: false };
    return { frame: { ...frame, params: { ...p, arguments: nextArgs } }, changed: true };
  }
  return { frame, changed: false };
}
function isTextContentType(contentType) {
  if (!contentType) return false;
  const normalized2 = contentType.toLowerCase();
  return normalized2.startsWith("text/") || normalized2.includes("json") || normalized2.includes("xml") || normalized2.includes("javascript") || normalized2.includes("ecmascript") || normalized2.includes("html") || normalized2.includes("css") || normalized2.includes("svg");
}
function isFormContentType(contentType) {
  if (!contentType) return false;
  return contentType.toLowerCase().includes("urlencoded");
}
function isTextRequestContentType(contentType) {
  if (!contentType) return false;
  return isTextContentType(contentType) || isFormContentType(contentType);
}
function normalizeLinkHeaderInput(input) {
  if (input == null) return null;
  if (Array.isArray(input)) {
    const headerString = input.join(", ").replace(/\n/g, ", ");
    return headerString.length === 0 ? null : headerString;
  }
  if (typeof input === "string") {
    const headerString = input.replace(/\n/g, ", ");
    return headerString.length === 0 ? null : headerString;
  }
  return null;
}
function readUnquotedParamValue(headerString, i) {
  const len = headerString.length;
  const start = i;
  while (i < len && headerString[i] !== ";" && headerString[i] !== "," && !isOWSChar(headerString[i])) i++;
  return { value: headerString.slice(start, i), end: i };
}
function readParamValue(headerString, i) {
  const len = headerString.length;
  i = skipOWS(headerString, i);
  if (i >= len || headerString[i] !== "=") return { value: "", end: i };
  i++;
  i = skipOWS(headerString, i);
  if (i < len && headerString[i] === '"') return readQuotedString(headerString, i);
  return readUnquotedParamValue(headerString, i);
}
function readParamName(headerString, i) {
  const len = headerString.length;
  const nameStart = i;
  while (i < len && isTokenChar(headerString.charCodeAt(i))) i++;
  if (i < len && headerString[i] === "*") i++;
  if (nameStart === i) return null;
  return { name: headerString.slice(nameStart, i).toLowerCase(), end: i };
}
function parseLinkParameters(headerString, startIndex) {
  const rawParams = [];
  const len = headerString.length;
  let i = startIndex;
  while (i < len) {
    i = skipOWS(headerString, i);
    if (i >= len) break;
    if (headerString[i] === ",") return { params: rawParams, endIndex: i + 1 };
    if (headerString[i] !== ";") {
      return { params: rawParams, endIndex: skipToNextValue(headerString, i) };
    }
    i++;
    i = skipOWS(headerString, i);
    const parsedName = readParamName(headerString, i);
    if (!parsedName) {
      return { params: rawParams, endIndex: skipToNextValue(headerString, i) };
    }
    const { value, end } = readParamValue(headerString, parsedName.end);
    rawParams.push([parsedName.name, value]);
    i = end;
  }
  return { params: rawParams, endIndex: i };
}
function parseLinkHeader(input, baseUrl) {
  const headerString = normalizeLinkHeaderInput(input);
  if (headerString == null) return [];
  const out = [];
  const len = headerString.length;
  let i = 0;
  while (i < len) {
    i = skipOWS(headerString, i);
    if (i >= len) break;
    if (headerString[i] !== "<") {
      i = skipToNextValue(headerString, i);
      continue;
    }
    const uriEnd = headerString.indexOf(">", i + 1);
    if (uriEnd === -1) break;
    const rawUri = headerString.slice(i + 1, uriEnd);
    const { params: rawParams, endIndex } = parseLinkParameters(headerString, uriEnd + 1);
    i = endIndex;
    const link = buildLink(rawUri, rawParams, baseUrl);
    if (link) out.push(link);
  }
  return out;
}
function skipOWS(s, i) {
  while (i < s.length && (s[i] === " " || s[i] === "	")) i++;
  return i;
}
function isOWSChar(c) {
  return c === " " || c === "	";
}
function skipToNextValue(s, i) {
  let inQuote = false;
  while (i < s.length) {
    const c = s[i];
    if (inQuote) {
      if (c === "\\" && i + 1 < s.length) {
        i += 2;
        continue;
      }
      if (c === '"') inQuote = false;
    } else {
      if (c === '"') inQuote = true;
      else if (c === ",") return i + 1;
    }
    i++;
  }
  return i;
}
function readQuotedString(s, i) {
  i++;
  let result = "";
  while (i < s.length) {
    const c = s[i];
    if (c === "\\") {
      i++;
      if (i < s.length) {
        result += s[i];
        i++;
      }
    } else if (c === '"') {
      return { value: result, end: i + 1 };
    } else {
      result += c;
      i++;
    }
  }
  return { value: result, end: i };
}
function isTokenChar(code) {
  if (code >= 48 && code <= 57) return true;
  if (code >= 65 && code <= 90) return true;
  if (code >= 97 && code <= 122) return true;
  switch (code) {
    case 33:
    case 35:
    case 36:
    case 37:
    case 38:
    case 39:
    case 42:
    case 43:
    case 45:
    case 46:
    case 94:
    case 95:
    case 96:
    case 124:
    case 126:
      return true;
  }
  return false;
}
function buildLink(rawUri, rawParams, baseUrl) {
  const params = {};
  const extOverrides = {};
  for (const [name, value] of rawParams) {
    if (name.endsWith("*")) {
      const decoded = decodeExtValue(value);
      if (decoded != null) extOverrides[name.slice(0, -1)] = decoded;
      continue;
    }
    if (name === "rel" && "rel" in params) continue;
    params[name] = value;
  }
  for (const [name, value] of Object.entries(extOverrides)) {
    params[name] = value;
  }
  const href = resolveURI(rawUri, baseUrl);
  const anchor = params.anchor != null ? resolveURI(params.anchor, baseUrl) : void 0;
  const relRaw = params.rel ?? "";
  const rel = relRaw.split(/[ \t]+/).filter((s) => s.length > 0);
  const link = { href, rel, params };
  if (anchor != null) link.anchor = anchor;
  if (params.type != null) link.type = params.type;
  if (params.title != null) link.title = params.title;
  if (params.hreflang != null) link.hreflang = params.hreflang;
  return link;
}
function resolveURI(ref, baseUrl) {
  if (!baseUrl) return ref;
  try {
    return new URL(ref, baseUrl).toString();
  } catch {
    return ref;
  }
}
function decodeExtValue(value) {
  const firstQuote = value.indexOf("'");
  if (firstQuote === -1) return null;
  const secondQuote = value.indexOf("'", firstQuote + 1);
  if (secondQuote === -1) return null;
  const charset = value.slice(0, firstQuote).toLowerCase();
  if (charset !== "utf-8") return null;
  try {
    return decodeURIComponent(value.slice(secondQuote + 1));
  } catch {
    return null;
  }
}
function getLinkHeaderValuesFromWebRequest(headers) {
  if (!headers) return [];
  const out = [];
  for (const h of headers) {
    if (h.name.toLowerCase() !== "link") continue;
    if (typeof h.value === "string" && h.value.length > 0) out.push(h.value);
  }
  return out;
}
var AI_CATALOG_REL = "ai-catalog";
function extractCatalog(links) {
  for (const link of links) {
    if (link.rel.includes(AI_CATALOG_REL)) {
      return { kind: "ai-catalog", url: link.href };
    }
  }
  return null;
}
function discoveryFingerprint(input) {
  return [input.origin ?? "", input.kind ?? "", input.url ?? ""].join("\0");
}
function extractCatalogFromWebRequest(headers, baseUrl) {
  const values = getLinkHeaderValuesFromWebRequest(headers);
  if (values.length === 0) return { match: null, links: [] };
  const links = parseLinkHeader(values, baseUrl);
  return { match: extractCatalog(links), links };
}
var EXTENSION_BRIDGE_PROTOCOL_VERSION = 1;
var EXTENSION_BRIDGE_PORT_NAME = "slicc.cdp-bridge";
var KINDS = /* @__PURE__ */ new Set(["handshake.hello", "handshake.welcome", "handshake.rejected", "cdp.request", "cdp.response", "cdp.event", "extension.lick", "extension.discovery", "leader.join-url", "extension.open-settings"]);
function isExtensionBridgeEnvelope(value) {
  if (typeof value !== "object" || value === null) return false;
  const v = value;
  return v.bridge === EXTENSION_BRIDGE_PROTOCOL_VERSION && typeof v.channelId === "string" && typeof v.kind === "string" && KINDS.has(v.kind);
}
function isBridgeVersionMismatch(value) {
  if (typeof value !== "object" || value === null) return false;
  const v = value;
  return typeof v.bridge === "number" && v.bridge !== EXTENSION_BRIDGE_PROTOCOL_VERSION && typeof v.channelId === "string" && typeof v.kind === "string";
}
var HANDOFF_REL = `${SLICC_HOSTED_ORIGIN}/rel/handoff`;
var UPSKILL_REL = `${SLICC_HOSTED_ORIGIN}/rel/upskill`;
function canonicaliseUpskillPath(raw) {
  const trimmed = raw.replace(/\/+$/, "");
  const lower = trimmed.toLowerCase();
  if (lower.endsWith("/skill.md")) return trimmed.slice(0, -"/skill.md".length);
  if (lower === "skill.md") return "";
  return trimmed;
}
var SAFE_BRANCH_RE = /^[A-Za-z0-9._/-]+$/;
var SAFE_PATH_RE = /^[A-Za-z0-9._/-]+$/;
var MAX_BRANCH_LEN = 250;
var MAX_PATH_LEN = 1024;
function isSafeUpskillBranch(value) {
  if (value.length === 0 || value.length > MAX_BRANCH_LEN) return false;
  if (!SAFE_BRANCH_RE.test(value)) return false;
  if (value.startsWith("-") || value.startsWith("/") || value.endsWith("/")) return false;
  if (value.includes("..")) return false;
  if (value.endsWith(".lock")) return false;
  return true;
}
function isSafeUpskillPath(value) {
  if (value.length === 0 || value.length > MAX_PATH_LEN) return false;
  if (!SAFE_PATH_RE.test(value)) return false;
  if (value.startsWith("-") || value.startsWith("/")) return false;
  if (value.includes("..")) return false;
  return true;
}
function applyUpskillParams(result, params) {
  const branch = params.branch;
  if (typeof branch === "string" && isSafeUpskillBranch(branch)) result.branch = branch;
  const pathParam = params.path;
  if (typeof pathParam === "string" && pathParam.length > 0) {
    const canon = canonicaliseUpskillPath(pathParam);
    if (canon.length > 0 && isSafeUpskillPath(canon)) result.path = canon;
  }
}
function extractHandoff(links) {
  for (const link of links) {
    if (link.rel.includes(HANDOFF_REL)) {
      const result = { verb: "handoff", target: link.href };
      if (link.title != null && link.title.length > 0) result.instruction = link.title;
      return result;
    }
    if (link.rel.includes(UPSKILL_REL)) {
      const result = { verb: "upskill", target: link.href };
      if (link.title != null && link.title.length > 0) result.instruction = link.title;
      applyUpskillParams(result, link.params);
      return result;
    }
  }
  return null;
}
function handoffFingerprint(input) {
  return [input.verb, input.target, input.branch ?? "", input.path ?? "", input.instruction ?? ""].join("\0");
}
function extractHandoffFromWebRequest(headers, baseUrl) {
  const values = getLinkHeaderValuesFromWebRequest(headers);
  if (values.length === 0) return { match: null, links: [] };
  const links = parseLinkHeader(values, baseUrl);
  return { match: extractHandoff(links), links };
}
var LEADER_EXT_ID_QUERY_NAME = "ext";
function decodeForbiddenRequestHeaders(headers) {
  const result = {};
  for (const [key, value] of Object.entries(headers)) {
    const lower = key.toLowerCase();
    if (lower === "x-proxy-cookie") {
      result["cookie"] = value;
    } else if (lower === "x-proxy-origin") {
      result["origin"] = value;
    } else if (lower === "x-proxy-referer") {
      result["referer"] = value;
    } else if (lower.startsWith("x-proxy-proxy-")) {
      result[lower.replace(/^x-proxy-/, "")] = value;
    } else {
      result[key] = value;
    }
  }
  return result;
}
var PROXY_WWW_AUTHENTICATE_HEADER = "X-Proxy-Www-Authenticate";
var RAW_FETCH_PROTOCOL_VERSION = 1;
var RAW_FETCH_BRIDGE_REQUEST_BODY_CAP = 256 * 1024 * 1024;
var RAW_FETCH_MAX_HEAD_BYTES = 1024 * 1024;
var RAW_REQUEST_SKIP_HEADERS = /* @__PURE__ */ new Set(["connection", "keep-alive", "proxy-connection", "te", "trailer", "transfer-encoding", "upgrade", "host", "content-length", "accept-encoding", "expect"]);
var RAW_RESPONSE_SKIP_HEADERS = /* @__PURE__ */ new Set(["connection", "keep-alive", "proxy-connection", "te", "trailer", "transfer-encoding", "upgrade"]);
var NODE_DECODED_CODINGS = /* @__PURE__ */ new Set(["gzip", "x-gzip", "deflate", "br"]);
var BROWSER_DECODED_CODINGS = /* @__PURE__ */ new Set([...NODE_DECODED_CODINGS, "zstd"]);
function isDecodedPartialResponse(input) {
  if (input.status !== 206) return false;
  const encoding = input.headers.filter(([name]) => name.toLowerCase() === "content-encoding").map(([, value]) => value).join(",");
  return codingsWereDecoded(encoding, input.decodedCodings ?? NODE_DECODED_CODINGS);
}
var NULL_BODY_STATUSES = /* @__PURE__ */ new Set([101, 103, 204, 205, 304]);
function connectionTokens(headers) {
  const tokens = /* @__PURE__ */ new Set();
  for (const [name, value] of headers) {
    if (name.toLowerCase() !== "connection") continue;
    for (const token of value.split(",")) {
      const trimmed = token.trim().toLowerCase();
      if (trimmed) tokens.add(trimmed);
    }
  }
  return tokens;
}
function stripRawRequestHeaders(headers) {
  const named = connectionTokens(headers);
  return headers.filter(([name]) => {
    const lower = name.toLowerCase();
    return !RAW_REQUEST_SKIP_HEADERS.has(lower) && !named.has(lower);
  });
}
function foldRawRequestHeaders(headers) {
  const out = {};
  for (const [name, value] of headers) {
    const lower = name.toLowerCase();
    const prior = out[lower];
    if (prior === void 0) out[lower] = value;
    else out[lower] = `${prior}${lower === "cookie" ? "; " : ", "}${value}`;
  }
  return out;
}
function codingsWereDecoded(contentEncoding, decodedCodings) {
  const codings = contentEncoding.split(",").map((c) => c.trim().toLowerCase()).filter((c) => c !== "" && c !== "identity");
  return codings.length > 0 && codings.every((c) => decodedCodings.has(c));
}
function rawResponseHasBody(method, status) {
  return method.toUpperCase() !== "HEAD" && !NULL_BODY_STATUSES.has(status);
}
function rawResponseHeaders(input) {
  const named = connectionTokens(input.headers);
  const withoutHop = input.headers.filter(([name]) => {
    const lower = name.toLowerCase();
    return !RAW_RESPONSE_SKIP_HEADERS.has(lower) && !named.has(lower);
  });
  if (!rawResponseHasBody(input.method, input.status)) return withoutHop;
  const encoding = withoutHop.filter(([name]) => name.toLowerCase() === "content-encoding").map(([, value]) => value).join(",");
  const decoded = codingsWereDecoded(encoding, input.decodedCodings ?? NODE_DECODED_CODINGS);
  const dropLength = decoded || input.bodyRewritten;
  return withoutHop.filter(([name]) => {
    const lower = name.toLowerCase();
    if (lower === "content-length") return !dropLength;
    if (lower === "content-encoding") return !decoded && encoding.trim().toLowerCase() !== "identity";
    return true;
  });
}
var RAW_FETCH_TAG_PREFIX = "slicc-raw-";
var RAW_FETCH_PORT_CHUNK_BYTES = 256 * 1024;
var RAW_FETCH_PORT_WINDOW = 4;
var RAW_FETCH_BUFFERED_REQUEST_BODY_CAP = 256 * 1024 * 1024;
var RAW_FETCH_STREAM_THRESHOLD_BYTES = 8 * 1024 * 1024;
function reasonFromStatusLine(statusLine) {
  const match = /^HTTP\/\S+\s+\d{3}\s*(.*)$/.exec(statusLine ?? "");
  return match?.[1]?.trim() ?? "";
}
function bytesToHex(bytes) {
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}
var KNOWN_PREFIXES = ["ghp_", "gho_", "ghu_", "ghs_", "ghr_", "github_pat_", "sk-", "pk-", "xoxb-", "xoxp-", "xoxa-", "xoxs-", "AKIA", "ABIA", "ACCA", "ASIA", "sk-ant-", "Bearer "];
var SORTED_PREFIXES = [...KNOWN_PREFIXES].sort((a, b) => b.length - a.length);
function detectPrefix(value) {
  for (const p of SORTED_PREFIXES) {
    if (value.startsWith(p)) return p;
  }
  return "";
}
async function hmacSha256(key, message) {
  const enc = new TextEncoder();
  const cryptoKey = await crypto.subtle.importKey("raw", enc.encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", cryptoKey, enc.encode(message));
  return new Uint8Array(sig);
}
async function hmacSha256Hex(key, message) {
  const cryptoKey = await crypto.subtle.importKey("raw", new TextEncoder().encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", cryptoKey, message);
  return bytesToHex(new Uint8Array(sig));
}
async function mask(sessionId, secretName, realValue) {
  const prefix = detectPrefix(realValue);
  const remainder = realValue.slice(prefix.length);
  const hmac = await hmacSha256(sessionId + secretName, realValue);
  let hex2 = bytesToHex(hmac);
  while (hex2.length < remainder.length) hex2 += hex2;
  const maskedRemainder = hex2.slice(0, remainder.length);
  return prefix + maskedRemainder;
}
var MIN_MASKABLE_SECRET_LENGTH = 9;
function buildScrubber(secrets) {
  const eligible = secrets.filter((s) => s.realValue.length >= MIN_MASKABLE_SECRET_LENGTH);
  if (eligible.length === 0) return (t) => t;
  const sorted = [...eligible].sort((a, b) => b.realValue.length - a.realValue.length);
  return (text) => {
    let result = text;
    for (const { realValue, maskedValue } of sorted) {
      if (result.includes(realValue)) {
        result = result.split(realValue).join(maskedValue);
      }
    }
    return result;
  };
}
function domainMatches(pattern, hostname) {
  const p = pattern.toLowerCase();
  const h = hostname.toLowerCase();
  if (p === "*") return true;
  if (!p.startsWith("*.")) {
    return p === h;
  }
  const suffix = p.slice(1);
  return h.length > suffix.length && h.endsWith(suffix);
}
function secretScopeHostname(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return "";
  }
}
function isAllowedDomain(patterns, hostname) {
  return patterns.some((p) => domainMatches(p, hostname));
}
function matchesDomains(hostname, patterns) {
  return isAllowedDomain(patterns, hostname);
}
function indexOfBytes(haystack, needle, from = 0) {
  outer: for (let i = from; i <= haystack.length - needle.length; i++) {
    for (let j = 0; j < needle.length; j++) {
      if (haystack[i + j] !== needle[j]) continue outer;
    }
    return i;
  }
  return -1;
}
function replaceAllBytes(haystack, needle, replacement) {
  if (indexOfBytes(haystack, needle) < 0) return haystack;
  const out = [];
  let i = 0;
  while (i < haystack.length) {
    const idx = indexOfBytes(haystack, needle, i);
    if (idx < 0) {
      for (let k = i; k < haystack.length; k++) out.push(haystack[k]);
      break;
    }
    for (let k = i; k < idx; k++) out.push(haystack[k]);
    for (let k = 0; k < replacement.length; k++) out.push(replacement[k]);
    i = idx + needle.length;
  }
  return new Uint8Array(out);
}
var HMAC_SIGN_HEADER = "x-slicc-hmac-sign";
var SecretsPipeline = class {
  sessionId;
  source;
  sessionStore;
  maskedToSecret = /* @__PURE__ */ new Map();
  exportPairs = [];
  exportShortPairs = [];
  consumableShortSecrets = /* @__PURE__ */ new Map();
  byName = /* @__PURE__ */ new Map();
  scrubber = (t) => t;
  constructor(opts) {
    this.sessionId = opts.sessionId;
    this.source = opts.source;
    this.sessionStore = opts.sessionStore;
  }
  async reload() {
    const all = await this.source.listAll();
    const persistedNames = new Set(all.map((s) => s.name));
    const session = (this.sessionStore?.listAll() ?? []).filter((s) => !persistedNames.has(s.name));
    const merged = [...all, ...session];
    const next = /* @__PURE__ */ new Map();
    const nextShort = /* @__PURE__ */ new Map();
    for (const s of merged) {
      if (s.value.length < MIN_MASKABLE_SECRET_LENGTH) {
        console.warn(`[slicc:secrets] secret "${s.name}" not masked: value shorter than ${MIN_MASKABLE_SECRET_LENGTH} chars`);
        nextShort.set(s.name, { name: s.name, realValue: s.value, maskedValue: s.value, domains: s.domains });
        continue;
      }
      const maskedValue = await mask(this.sessionId, s.name, s.value);
      next.set(maskedValue, { name: s.name, realValue: s.value, maskedValue, domains: s.domains });
    }
    this.maskedToSecret = next;
    this.exportPairs = Array.from(next.values());
    this.exportShortPairs = Array.from(nextShort.values());
    this.consumableShortSecrets = nextShort;
    const nextByName = /* @__PURE__ */ new Map();
    for (const ms of next.values()) nextByName.set(ms.name, ms);
    for (const ms of nextShort.values()) {
      if (nextByName.has(ms.name)) {
        console.warn(`[slicc:secrets] secret "${ms.name}" registered as both maskable and short-consumable`);
      }
      nextByName.set(ms.name, ms);
    }
    this.byName = nextByName;
    const pairs = Array.from(next.values()).map((ms) => ({ realValue: ms.realValue, maskedValue: ms.maskedValue }));
    this.scrubber = buildScrubber(pairs);
  }
  async maskOne(name, value) {
    return mask(this.sessionId, name, value);
  }
  hasSecrets() {
    return this.maskedToSecret.size > 0;
  }
  getMaskedEntries() {
    const entries = [];
    for (const ms of this.maskedToSecret.values()) {
      entries.push({ name: ms.name, maskedValue: ms.maskedValue, domains: ms.domains });
    }
    for (const ms of this.consumableShortSecrets.values()) {
      entries.push({ name: ms.name, maskedValue: ms.maskedValue, domains: ms.domains });
    }
    return entries;
  }
  unmask(text, hostname) {
    let result = text;
    for (const [maskedValue, ms] of this.maskedToSecret) {
      if (!result.includes(maskedValue)) continue;
      if (!matchesDomains(hostname, ms.domains)) {
        return { text, forbidden: { secretName: ms.name, hostname } };
      }
      result = result.split(maskedValue).join(ms.realValue);
    }
    return { text: result };
  }
  unmaskBody(text, hostname) {
    let result = text;
    for (const [maskedValue, ms] of this.maskedToSecret) {
      if (!result.includes(maskedValue)) continue;
      if (!matchesDomains(hostname, ms.domains)) continue;
      result = result.split(maskedValue).join(ms.realValue);
    }
    return { text: result };
  }
  unmaskAuthorizationBasic(headerValue2, hostname) {
    const pattern = /^Basic\s+(.+)$/;
    const match = pattern.exec(headerValue2);
    if (!match) return { value: headerValue2 };
    let decoded;
    try {
      decoded = atob(match[1].trim());
    } catch {
      return { value: headerValue2 };
    }
    const colon = decoded.indexOf(":");
    if (colon < 0) return { value: headerValue2 };
    let user = decoded.slice(0, colon);
    let pass = decoded.slice(colon + 1);
    let touched = false;
    for (const [maskedValue, ms] of this.maskedToSecret) {
      if (user.includes(maskedValue) || pass.includes(maskedValue)) {
        if (!matchesDomains(hostname, ms.domains)) {
          return { value: headerValue2, forbidden: { secretName: ms.name, hostname } };
        }
        if (user.includes(maskedValue)) user = user.split(maskedValue).join(ms.realValue);
        if (pass.includes(maskedValue)) pass = pass.split(maskedValue).join(ms.realValue);
        touched = true;
      }
    }
    if (!touched) return { value: headerValue2 };
    return { value: `Basic ${btoa(`${user}:${pass}`)}` };
  }
  extractAndUnmaskUrlCredentials(rawUrl) {
    let parsed2;
    try {
      parsed2 = new URL(rawUrl);
    } catch {
      return { url: rawUrl };
    }
    if (!parsed2.username && !parsed2.password) return { url: rawUrl };
    let user = decodeURIComponent(parsed2.username);
    let pass = decodeURIComponent(parsed2.password);
    const host = parsed2.hostname;
    let touched = false;
    for (const [maskedValue, ms] of this.maskedToSecret) {
      if (user.includes(maskedValue) || pass.includes(maskedValue)) {
        if (!matchesDomains(host, ms.domains)) {
          return { url: rawUrl, forbidden: { secretName: ms.name, hostname: host } };
        }
        if (user.includes(maskedValue)) {
          user = user.split(maskedValue).join(ms.realValue);
          touched = true;
        }
        if (pass.includes(maskedValue)) {
          pass = pass.split(maskedValue).join(ms.realValue);
          touched = true;
        }
      }
    }
    const synthetic = touched && (user || pass) ? `Basic ${btoa(`${user}:${pass}`)}` : void 0;
    parsed2.username = "";
    parsed2.password = "";
    return { url: parsed2.toString(), syntheticAuthorization: synthetic };
  }
  unmaskHeaders(headers, hostname) {
    for (const [key, val] of Object.entries(headers)) {
      if (key.toLowerCase() === "authorization" && /^Basic\s/i.test(val)) {
        const basic = this.unmaskAuthorizationBasic(val, hostname);
        if (basic.forbidden) return { forbidden: basic.forbidden };
        headers[key] = basic.value;
        continue;
      }
      const { text, forbidden: forbidden2 } = this.unmask(val, hostname);
      if (forbidden2) return { forbidden: forbidden2 };
      headers[key] = text;
    }
    return {};
  }
  async signHmac(spec, body, hostname, now = Date.now) {
    const sep = spec.indexOf(":");
    if (sep < 0) return {};
    const secretName = spec.slice(0, sep).trim();
    const rest = spec.slice(sep + 1);
    const sep2 = rest.indexOf(":");
    const headerName = (sep2 < 0 ? rest : rest.slice(0, sep2)).trim();
    const timestampHeader = sep2 < 0 ? void 0 : rest.slice(sep2 + 1).trim();
    if (!secretName || !headerName) return {};
    if (timestampHeader === "") return {};
    const ms = this.byName.get(secretName);
    if (!ms) {
      console.warn(`[slicc:secrets] signHmac: no secret named "${secretName}"`);
      return {};
    }
    if (!matchesDomains(hostname, ms.domains)) {
      return { forbidden: { secretName: ms.name, hostname } };
    }
    if (timestampHeader) {
      const timestampValue = String(Math.floor(now() / 1e3));
      const message = new Uint8Array(body.length + timestampValue.length + 1);
      message.set(new TextEncoder().encode(`${timestampValue}.`), 0);
      message.set(body, timestampValue.length + 1);
      const signatureHex2 = await hmacSha256Hex(ms.realValue, message);
      return { headerName, signatureHex: signatureHex2, timestampHeaderName: timestampHeader, timestampValue };
    }
    const signatureHex = await hmacSha256Hex(ms.realValue, body);
    return { headerName, signatureHex };
  }
  unmaskBodyBytes(body, hostname) {
    let out = body;
    const enc = new TextEncoder();
    for (const [maskedValue, ms] of this.maskedToSecret) {
      if (!matchesDomains(hostname, ms.domains)) continue;
      const needle = enc.encode(maskedValue);
      const replacement = enc.encode(ms.realValue);
      out = replaceAllBytes(out, needle, replacement);
    }
    return { bytes: out };
  }
  scrubResponse(text) {
    return this.scrubber(text);
  }
  scrubResponseBytes(bytes) {
    let out = bytes;
    const enc = new TextEncoder();
    for (const [maskedValue, ms] of this.maskedToSecret) {
      const needle = enc.encode(ms.realValue);
      const replacement = enc.encode(maskedValue);
      out = replaceAllBytes(out, needle, replacement);
    }
    return out;
  }
  scrubHeaders(headers) {
    const out = {};
    headers.forEach((v, k) => {
      out[k] = this.scrubber(v);
    });
    return out;
  }
  redactForExport(texts) {
    const base2 = this.exportPairs.length;
    const markers = this.exportPairs.map((pair, index) => ({ values: [pair.realValue, pair.maskedValue].filter(Boolean), marker: `\u27E6REDACTED:known-secret:k${index + 1}\u27E7` }));
    const shortMarkers = this.exportShortPairs.map((pair, index) => ({ values: [pair.realValue], marker: `\u27E6REDACTED:known-secret:k${base2 + index + 1}\u27E7` }));
    const allMarkers = [...markers, ...shortMarkers];
    let redactionCount = 0;
    return { texts: texts.map((input) => {
      let output = input;
      for (const { values, marker } of allMarkers) {
        for (const value of values) {
          const occurrences = output.split(value).length - 1;
          redactionCount += occurrences;
          output = output.replaceAll(value, marker);
        }
      }
      return output;
    }), redactionCount };
  }
};
function createRetryableUpload(source) {
  const ready = [];
  let inflight = null;
  let delivered = 0;
  let generation = 0;
  const fill = () => {
    inflight ??= source().then((chunk) => {
      ready.push(chunk);
    }).finally(() => {
      inflight = null;
    });
    return inflight;
  };
  const stream = () => {
    const own = ++generation;
    return new ReadableStream({ async pull(controller) {
      while (ready.length === 0) await fill();
      if (own !== generation) return;
      const chunk = ready[0];
      if (chunk === null || chunk === void 0) {
        controller.close();
        return;
      }
      ready.shift();
      delivered += chunk.byteLength;
      controller.enqueue(chunk);
    } }, { highWaterMark: 0 });
  };
  return { stream, untouched: () => delivered === 0 };
}
function rawUploadStreams(input) {
  if (!input.canStream) return false;
  const headers = foldRawRequestHeaders(input.headers);
  if (headers[HMAC_SIGN_HEADER] !== void 0) return false;
  if (isTextRequestContentType(headers["content-type"] ?? "")) return false;
  return input.bodyLength === void 0 || input.bodyLength >= RAW_FETCH_STREAM_THRESHOLD_BYTES;
}
function supportsRequestStreams() {
  let duplexAccessed = false;
  try {
    const hasContentType = new Request("https://example.invalid/", { body: new ReadableStream(), method: "POST", get duplex() {
      duplexAccessed = true;
      return "half";
    } }).headers.has("Content-Type");
    return duplexAccessed && !hasContentType;
  } catch {
    return false;
  }
}
function isUnsentRefusal(err, upload, signal) {
  return err instanceof TypeError && upload.untouched() && !signal?.aborted;
}
async function withUnsentUploadRetry(source, attempt, signal) {
  const upload = createRetryableUpload(source);
  try {
    return await attempt(upload.stream());
  } catch (err) {
    if (!isUnsentRefusal(err, upload, signal)) throw err;
    return await attempt(upload.stream());
  }
}
var DOMAINS_SUFFIX = "_DOMAINS";
function parseDomainsCsv(raw) {
  return raw.split(",").map((domain) => domain.trim()).filter((domain) => domain.length > 0);
}
function pairEnvEntriesToSecrets(entries) {
  const values = /* @__PURE__ */ new Map();
  const domains = /* @__PURE__ */ new Map();
  const order = [];
  for (const entry of entries) {
    if (entry.key.endsWith(DOMAINS_SUFFIX)) {
      const name = entry.key.slice(0, -DOMAINS_SUFFIX.length);
      if (name) domains.set(name, parseDomainsCsv(entry.value));
    } else {
      if (!values.has(entry.key)) order.push(entry.key);
      values.set(entry.key, entry.value);
    }
  }
  return order.flatMap((name) => {
    const value = values.get(name);
    const allowedDomains = domains.get(name);
    return value !== void 0 && allowedDomains?.length ? [{ name, value, domains: allowedDomains }] : [];
  });
}
var SessionSecretStore = class {
  entries = /* @__PURE__ */ new Map();
  set(name, value, domains = []) {
    this.entries.set(name, { name, value, domains: [...domains] });
  }
  get(name) {
    return this.entries.get(name)?.value;
  }
  getRecord(name) {
    const r = this.entries.get(name);
    return r ? { name: r.name, value: r.value, domains: [...r.domains] } : void 0;
  }
  has(name) {
    return this.entries.has(name);
  }
  setDomains(name, domains) {
    const r = this.entries.get(name);
    if (!r) return false;
    r.domains = [...domains];
    return true;
  }
  delete(name) {
    return this.entries.delete(name);
  }
  listAll() {
    return Array.from(this.entries.values()).map((r) => ({ name: r.name, value: r.value, domains: [...r.domains] }));
  }
  list() {
    return Array.from(this.entries.values()).map((r) => ({ name: r.name, domains: [...r.domains] }));
  }
  size() {
    return this.entries.size;
  }
};
function previewSecret(value, edge = 4) {
  const len = value.length;
  if (len === 0) return "";
  if (len <= 2) return "\u2026";
  const e = Math.min(Math.max(1, edge), Math.floor((len - 1) / 2));
  return `${value.slice(0, e)}\u2026${value.slice(len - e)}`;
}
var SIGNED_ALGORITHM = "AWS4-HMAC-SHA256";
var EMPTY_BODY_HASH = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
function hex(bytes) {
  const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let out = "";
  for (let i = 0; i < view.length; i++) {
    out += view[i].toString(16).padStart(2, "0");
  }
  return out;
}
async function sha256(data) {
  const digest = await crypto.subtle.digest("SHA-256", data);
  return hex(digest);
}
async function hmacSha2562(key, data) {
  const cryptoKey = await crypto.subtle.importKey("raw", key, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return crypto.subtle.sign("HMAC", cryptoKey, new TextEncoder().encode(data));
}
function ymd(d) {
  const pad = (n) => n.toString().padStart(2, "0");
  return `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}`;
}
function iso8601(d) {
  const pad = (n) => n.toString().padStart(2, "0");
  return `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}
function canonicalUri(url) {
  const segments = url.pathname.split("/");
  const encoded = segments.map((s) => encodeURIComponent(s).replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`));
  const path = encoded.join("/");
  return path === "" ? "/" : path;
}
function canonicalQuery(url) {
  const params = [];
  for (const [k, v] of url.searchParams.entries()) {
    params.push([k, v]);
  }
  params.sort(([ak, av], [bk, bv]) => ak === bk ? av < bv ? -1 : av > bv ? 1 : 0 : ak < bk ? -1 : 1);
  return params.map(([k, v]) => `${encodeURIComponent(k).replace(/\+/g, "%20")}=${encodeURIComponent(v).replace(/\+/g, "%20")}`).join("&");
}
function canonicalHeaders(headers) {
  const entries = Object.entries(headers).map(([k, v]) => [k.toLowerCase(), v.trim().replace(/\s+/g, " ")]);
  entries.sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
  const canonical = entries.map(([k, v]) => `${k}:${v}
`).join("");
  const signed = entries.map(([k]) => k).join(";");
  return { canonical, signed };
}
async function signSigV4(req, creds, region, service = "s3", now = /* @__PURE__ */ new Date()) {
  const date = ymd(now);
  const dateTime = iso8601(now);
  const bodyBytes = req.body ?? new Uint8Array(0);
  const bodyHash = bodyBytes.byteLength === 0 ? EMPTY_BODY_HASH : await sha256(bodyBytes);
  const headers = { ...req.headers, host: req.headers.host ?? req.headers.Host ?? req.url.host, "x-amz-date": dateTime };
  if (service === "s3") {
    headers["x-amz-content-sha256"] = bodyHash;
  }
  if (creds.sessionToken) {
    headers["x-amz-security-token"] = creds.sessionToken;
  }
  delete headers.Host;
  const { canonical: canonicalHeadersStr, signed: signedHeaders } = canonicalHeaders(headers);
  const canonicalRequest = [req.method, canonicalUri(req.url), canonicalQuery(req.url), canonicalHeadersStr, signedHeaders, bodyHash].join("\n");
  const credentialScope = `${date}/${region}/${service}/aws4_request`;
  const stringToSign = [SIGNED_ALGORITHM, dateTime, credentialScope, await sha256(new TextEncoder().encode(canonicalRequest))].join("\n");
  const kDate = await hmacSha2562(new TextEncoder().encode(`AWS4${creds.secretAccessKey}`), date);
  const kRegion = await hmacSha2562(kDate, region);
  const kService = await hmacSha2562(kRegion, service);
  const kSigning = await hmacSha2562(kService, "aws4_request");
  const signature = hex(await hmacSha2562(kSigning, stringToSign));
  const authorization = `${SIGNED_ALGORITHM} Credential=${creds.accessKeyId}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;
  return { ...req, headers: { ...headers, Authorization: authorization } };
}
var ALLOWED_METHODS = ["GET", "PUT", "POST", "DELETE", "HEAD"];
var PROFILE_NAME_REGEX = /^[a-zA-Z0-9._-]+$/;
var HOP_BY_HOP = /* @__PURE__ */ new Set(["connection", "keep-alive", "proxy-authenticate", "proxy-authorization", "te", "trailer", "transfer-encoding", "upgrade"]);
var DA_ORIGIN = "https://admin.da.live";
var DA_ALLOWED_ORIGINS = /* @__PURE__ */ new Set([DA_ORIGIN, "https://api.aem.live"]);
function isAllowedMethod(m) {
  return typeof m === "string" && ALLOWED_METHODS.includes(m);
}
var ProfileNotConfiguredError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "ProfileNotConfiguredError";
  }
};
async function resolveS3Profile(name, store) {
  const accessKeyId = await store.get(`s3.${name}.access_key_id`);
  const secretAccessKey = await store.get(`s3.${name}.secret_access_key`);
  if (!accessKeyId) {
    throw new ProfileNotConfiguredError(`profile '${name}' missing required field 'access_key_id'. Set it via: secret set s3.${name}.access_key_id <value>`);
  }
  if (!secretAccessKey) {
    throw new ProfileNotConfiguredError(`profile '${name}' missing required field 'secret_access_key'. Set it via: secret set s3.${name}.secret_access_key <value>`);
  }
  return { accessKeyId, secretAccessKey, sessionToken: await store.get(`s3.${name}.session_token`), region: await store.get(`s3.${name}.region`) ?? "us-east-1", endpoint: await store.get(`s3.${name}.endpoint`), pathStyle: await store.get(`s3.${name}.path_style`) === "true" };
}
function buildS3Url(profile, bucket, key, query) {
  let host;
  if (profile.endpoint) {
    try {
      host = new URL(profile.endpoint).host;
    } catch {
      throw new Error(`profile endpoint is not a valid URL: ${profile.endpoint}`);
    }
  } else {
    host = `s3.${profile.region}.amazonaws.com`;
  }
  const encodedKey = key.split("/").map(encodeURIComponent).join("/");
  const encodedBucket = encodeURIComponent(bucket);
  const pathPart = profile.pathStyle ? `${encodedBucket}/${encodedKey}` : encodedKey;
  const hostPart = profile.pathStyle ? host : `${encodedBucket}.${host}`;
  const url = new URL(`https://${hostPart}/${pathPart}`);
  if (query) {
    for (const [k, v] of Object.entries(query)) {
      url.searchParams.set(k, v);
    }
  }
  return url;
}
function passthroughHeaders(upstream) {
  const out = {};
  upstream.headers.forEach((value, key) => {
    if (!HOP_BY_HOP.has(key.toLowerCase())) {
      out[key] = value;
    }
  });
  return out;
}
async function executeS3SignAndForward(env, store, fetchImpl = fetch) {
  if (typeof env?.profile !== "string" || env.profile.length === 0 || !PROFILE_NAME_REGEX.test(env.profile)) {
    return { ok: false, error: "invalid profile name (allowed: alphanumeric, dot, underscore, hyphen)", errorCode: "invalid_profile" };
  }
  if (!isAllowedMethod(env.method)) {
    return { ok: false, error: "invalid method", errorCode: "invalid_request" };
  }
  if (typeof env.bucket !== "string" || env.bucket.length === 0) {
    return { ok: false, error: "invalid bucket", errorCode: "invalid_request" };
  }
  if (typeof env.key !== "string") {
    return { ok: false, error: "invalid key", errorCode: "invalid_request" };
  }
  let profile;
  try {
    profile = await resolveS3Profile(env.profile, store);
  } catch (err) {
    if (err instanceof ProfileNotConfiguredError) {
      return { ok: false, error: err.message, errorCode: "profile_not_configured" };
    }
    throw err;
  }
  let url;
  try {
    url = buildS3Url(profile, env.bucket, env.key, env.query);
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : "failed to build URL", errorCode: "invalid_request" };
  }
  const body = typeof env.bodyBase64 === "string" && env.bodyBase64.length > 0 ? base64ToUint8(env.bodyBase64) : void 0;
  const signed = await signSigV4({ method: env.method, url, headers: { ...env.headers ?? {}, Host: url.host }, body }, { accessKeyId: profile.accessKeyId, secretAccessKey: profile.secretAccessKey, sessionToken: profile.sessionToken }, profile.region, "s3");
  let upstream;
  try {
    upstream = await fetchImpl(url.toString(), { method: signed.method, headers: signed.headers, body: signed.body });
  } catch (err) {
    return { ok: false, error: `S3 fetch failed: ${err instanceof Error ? err.message : String(err)}`, errorCode: "fetch_failed" };
  }
  const upstreamBody = new Uint8Array(await upstream.arrayBuffer());
  return { ok: true, status: upstream.status, headers: passthroughHeaders(upstream), bodyBase64: uint8ToBase64(upstreamBody) };
}
async function executeDaSignAndForward(env, fetchImpl = fetch) {
  if (typeof env?.imsToken !== "string" || env.imsToken.length === 0) {
    return { ok: false, error: "imsToken is required", errorCode: "invalid_request" };
  }
  if (!isAllowedMethod(env.method)) {
    return { ok: false, error: "invalid method", errorCode: "invalid_request" };
  }
  if (typeof env.path !== "string" || !env.path.startsWith("/")) {
    return { ok: false, error: "path must be a string starting with /", errorCode: "invalid_request" };
  }
  const origin = env.origin ?? DA_ORIGIN;
  if (!DA_ALLOWED_ORIGINS.has(origin)) {
    return { ok: false, error: `origin '${origin}' is not an allowed DA upstream`, errorCode: "invalid_request" };
  }
  let url;
  try {
    url = new URL(origin + env.path);
    if (env.query) {
      for (const [k, v] of Object.entries(env.query)) {
        url.searchParams.set(k, v);
      }
    }
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : "failed to build URL", errorCode: "invalid_request" };
  }
  const body = typeof env.bodyBase64 === "string" && env.bodyBase64.length > 0 ? base64ToUint8(env.bodyBase64) : void 0;
  let upstream;
  try {
    upstream = await fetchImpl(url.toString(), { method: env.method, headers: { ...env.headers ?? {}, Authorization: `Bearer ${env.imsToken}` }, body });
  } catch (err) {
    return { ok: false, error: `DA fetch failed: ${err instanceof Error ? err.message : String(err)}`, errorCode: "fetch_failed" };
  }
  const upstreamBody = new Uint8Array(await upstream.arrayBuffer());
  return { ok: true, status: upstream.status, headers: passthroughHeaders(upstream), bodyBase64: uint8ToBase64(upstreamBody) };
}
var TARGETS = [{ kind: "ai-catalog", path: "/.well-known/ai-catalog.json" }, { kind: "llms-txt", path: "/llms.txt" }];
var DEFAULT_TIMEOUT_MS = 3e3;
async function probeWellKnown(origin, fetchImpl, options = {}) {
  const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  let base2;
  try {
    base2 = new URL(origin).origin;
  } catch {
    return [];
  }
  const settled = await Promise.all(TARGETS.map((target) => probeOne(base2, target, fetchImpl, timeoutMs)));
  return settled.filter((m) => m !== null);
}
async function probeOne(base2, target, fetchImpl, timeoutMs) {
  const url = base2 + target.path;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(new Error("timeout")), timeoutMs);
  try {
    const res = await fetchImpl(url, { method: "GET", signal: ctrl.signal, redirect: "manual", credentials: "omit" });
    if (res.status !== 200) return null;
    if (!contentTypeOk(res.headers.get("content-type"), target.kind)) return null;
    return { kind: target.kind, url };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}
function contentTypeOk(raw, kind) {
  if (raw == null) return true;
  const ct = raw.toLowerCase();
  if (ct.length === 0) return true;
  if (ct.includes("text/html") || ct.includes("application/xhtml")) return false;
  if (kind === "ai-catalog") {
    return ct.includes("json") || ct.includes("text/plain") || ct.includes("octet-stream");
  }
  return ct.includes("text/plain") || ct.includes("markdown") || ct.includes("octet-stream");
}
var SEALED_DOMAINS = ["DOM.", "DOMSnapshot.", "Accessibility.", "CSS.", "Overlay.", "DOMDebugger.", "LayerTree.", "Animation."];
var NODE_KEY = /^(?:[a-z]+N|n)odeIds?$/;
var NODE_EVENT_KEYS = ["nodeId", "parentId", "parentNodeId", "insertionPointId", "hostId"];
var DEEP = "slicc: refused: that reply nests too deeply to check for protected frames";
var WHOLE_PAGE = /* @__PURE__ */ new Set(["DOM.performSearch", "DOMSnapshot.getSnapshot"]);
var RARE_STRINGS = ["shadowRootType", "textValue", "inputValue", "pseudoType", "pseudoIdentifier", "currentSourceURL", "originURL"];
var DOCUMENT_STRINGS = ["documentURL", "title", "baseURL", "contentLanguage", "encodingName", "publicId", "systemId", "frameId"];
function isObj(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function list(value) {
  return Array.isArray(value) ? value : [];
}
var REALM_READS = /* @__PURE__ */ new Set(["Runtime.evaluate", "Runtime.callFunctionOn", "Runtime.getProperties", "Runtime.getExceptionDetails", "Runtime.compileScript", "Runtime.globalLexicalScopeNames", "Runtime.queryObjects", "Runtime.runScript", "Runtime.awaitPromise", "Runtime.consoleAPICalled", "Runtime.exceptionThrown", "Runtime.bindingCalled"]);
async function resolveFrameOrigins(tree, uncertain, readOrigin) {
  const pending = isObj(tree) ? [...list(tree["childFrames"])] : [];
  while (pending.length > 0) {
    const node = pending.pop();
    if (!isObj(node) || !isObj(node["frame"])) continue;
    const frame = node["frame"];
    const id = frame["id"];
    if (typeof id !== "string") continue;
    const url = frame["url"];
    if (typeof url === "string" && /^about:(?:blank|srcdoc)(?:[?#]|$)/i.test(url) || uncertain.has(id)) {
      frame["securityOrigin"] = await readOrigin(id).catch(() => "null");
    }
    pending.push(...list(node["childFrames"]));
  }
}
function unknownFrame(frame) {
  if (typeof frame["securityOrigin"] !== "string" || typeof frame["url"] !== "string") return true;
  try {
    const origin = new URL(String(frame["securityOrigin"]));
    new URL(String(frame["url"]));
    return origin.origin === "null";
  } catch {
    return true;
  }
}
function sealedRead(method) {
  return REALM_READS.has(method) || SEALED_DOMAINS.some((domain) => method.startsWith(domain));
}
function wholePage(method) {
  return WHOLE_PAGE.has(method) || REALM_READS.has(method) || method.startsWith("CSS.");
}
function frameSets(tree, hidden) {
  const visible = /* @__PURE__ */ new Set();
  const sealed = /* @__PURE__ */ new Set();
  const pending = [[tree, false, true]];
  while (pending.length > 0) {
    const [node, above, top] = pending.pop();
    const frame = isObj(node) ? node["frame"] : void 0;
    if (!isObj(node) || !isObj(frame) || typeof frame["id"] !== "string") continue;
    const shut = above || !top && hidden(frame);
    (shut ? sealed : visible).add(frame["id"]);
    for (const child of list(node["childFrames"])) pending.push([child, shut, false]);
  }
  return { visible, sealed };
}
function sealedNodes(snapshot, visible) {
  const strings = isObj(snapshot) ? list(snapshot["strings"]) : [];
  const nodes = /* @__PURE__ */ new Set();
  for (const doc of isObj(snapshot) ? list(snapshot["documents"]) : []) {
    const frame = isObj(doc) && typeof doc["frameId"] === "number" ? strings[doc["frameId"]] : "";
    if (visible.has(frame)) continue;
    const tree = isObj(doc) && isObj(doc["nodes"]) ? doc["nodes"] : {};
    for (const id of list(tree["backendNodeId"])) nodes.add(id);
  }
  return nodes;
}
function nodeSelectors(params) {
  const out = { backend: [], dom: [], objects: [] };
  for (const [key, value] of Object.entries(params)) {
    if (key === "objectId" && typeof value === "string") out.objects.push(value);
    if (!NODE_KEY.test(key)) continue;
    const ids = (Array.isArray(value) ? value : [value]).filter((id) => typeof id === "number");
    out[key.startsWith("backend") ? "backend" : "dom"].push(...ids);
  }
  return out;
}
function boundIds(node, out = [], depth = 0) {
  if (depth > 1e3) throw new Error(DEEP);
  if (node === null || typeof node !== "object") return out;
  if (Array.isArray(node)) {
    for (const item of node) boundIds(item, out, depth + 1);
    return out;
  }
  const value = node;
  if (typeof value["nodeId"] === "number" && value["nodeId"] > 0) out.push(value["nodeId"]);
  for (const item of Object.values(value)) boundIds(item, out, depth + 1);
  return out;
}
function sealedItem(item, seal) {
  if (!isObj(item)) return false;
  if (seal.nodes.has(item["backendNodeId"]) || seal.nodes.has(item["backendDOMNodeId"])) {
    return true;
  }
  return typeof item["nodeId"] === "string" && seal.sealed.has(item["frameId"]);
}
function pruneList(items, seal, cut) {
  const gone = /* @__PURE__ */ new Set();
  const drop = (item) => {
    if (isObj(item) && item["nodeId"] !== void 0) gone.add(item["nodeId"]);
    boundIds(item, cut);
    return false;
  };
  let kept = items.filter((item) => !sealedItem(item, seal) || drop(item));
  for (let grew = true; grew; ) {
    grew = false;
    kept = kept.filter((item) => {
      if (!isObj(item) || !gone.has(item["parentId"])) return true;
      grew = true;
      return drop(item);
    });
  }
  return kept;
}
function pruneSealed(value, seal, cut = [], depth = 0) {
  if (depth > 1e3) throw new Error(DEEP);
  if (value === null || typeof value !== "object") return cut;
  if (Array.isArray(value)) {
    for (const item of value) pruneSealed(item, seal, cut, depth + 1);
    return cut;
  }
  const node = value;
  const inner = node["contentDocument"];
  if (isObj(inner) && (seal.nodes.has(inner["backendNodeId"]) || typeof node["frameId"] !== "string" || !seal.visible.has(node["frameId"]))) {
    boundIds(inner, cut);
    delete node["contentDocument"];
  }
  for (const [key, item] of Object.entries(node)) {
    if (sealedItem(item, seal)) {
      boundIds(item, cut);
      delete node[key];
      continue;
    }
    if (Array.isArray(item)) node[key] = pruneList(item, seal, cut);
    pruneSealed(node[key], seal, cut, depth + 1);
  }
  return cut;
}
function sealedEvent(params, cut) {
  return NODE_EVENT_KEYS.some((key) => cut.has(params[key]));
}
function pruneSnapshot(snapshot, visible) {
  const strings = list(snapshot["strings"]);
  const documents = list(snapshot["documents"]);
  const index = /* @__PURE__ */ new Map();
  documents.forEach((doc, at) => {
    const frame = isObj(doc) && typeof doc["frameId"] === "number" ? strings[doc["frameId"]] : "";
    if (visible.has(frame)) index.set(at, index.size);
  });
  const fresh = [];
  const seen = /* @__PURE__ */ new Map();
  const str2 = (at) => {
    if (typeof at !== "number" || at < 0) return at;
    if (!seen.has(at)) {
      seen.set(at, fresh.length);
      const text = strings[at];
      fresh.push(typeof text === "string" ? text : "");
    }
    return seen.get(at);
  };
  const all = (items) => Array.isArray(items) ? items.map(str2) : items;
  const nested = (items) => Array.isArray(items) ? items.map(all) : items;
  const kept = documents.filter((_, at) => index.has(at)).map((raw) => {
    const doc = raw;
    const out = { ...doc };
    for (const key of DOCUMENT_STRINGS) out[key] = str2(doc[key]);
    const nodes = { ...isObj(doc["nodes"]) ? doc["nodes"] : {} };
    nodes["nodeName"] = all(nodes["nodeName"]);
    nodes["nodeValue"] = all(nodes["nodeValue"]);
    nodes["attributes"] = nested(nodes["attributes"]);
    for (const key of RARE_STRINGS) {
      const rare = nodes[key];
      if (isObj(rare)) nodes[key] = { ...rare, value: all(rare["value"]) };
    }
    const content = nodes["contentDocumentIndex"];
    if (isObj(content)) {
      const values = list(content["value"]);
      const pairs = list(content["index"]).map((node, at) => [node, index.get(values[at])]).filter(([, target]) => target !== void 0);
      nodes["contentDocumentIndex"] = { index: pairs.map(([node]) => node), value: pairs.map(([, target]) => target) };
    }
    out["nodes"] = nodes;
    const layout = doc["layout"];
    if (isObj(layout)) {
      out["layout"] = { ...layout, styles: nested(layout["styles"]), text: all(layout["text"]), blendedBackgroundColors: all(layout["blendedBackgroundColors"]) };
    }
    return out;
  });
  return { ...snapshot, documents: kept, strings: fresh };
}
var WAKE = { format: "jpeg", quality: 1, maxWidth: 16, maxHeight: 16 };
var CASTS = /* @__PURE__ */ new Set(["Page.startScreencast", "Page.stopScreencast", "Page.startScreenRecording", "Page.stopScreenRecording"]);
var KEEP = 32;
var Wake = class {
  constructor(send3) {
    this.send = send3;
  }
  send;
  count = 0;
  awake = false;
  stopping = false;
  cast = false;
  ours = [];
  waking = Promise.resolve();
  calm = Promise.resolve();
  calmed;
  resting = Promise.resolve();
  async command(method, params, forward) {
    if (CASTS.has(method)) return this.casting(method, params, forward);
    if (method !== "Page.captureScreenshot" || this.cast) return forward(method, params);
    await this.rise();
    try {
      return await forward(method, params);
    } finally {
      this.settle();
    }
  }
  async rise() {
    this.count += 1;
    if (this.count === 1) {
      this.calm = new Promise((resolve) => {
        this.calmed = resolve;
      });
      const rested = this.resting;
      this.waking = rested.then(() => this.send("Page.startScreencast", WAKE).then(() => {
        this.awake = true;
      }, () => void 0));
    }
    await this.waking;
  }
  settle() {
    this.count -= 1;
    if (this.count > 0) return;
    const calmed = this.calmed;
    if (!this.awake) {
      calmed();
      return;
    }
    this.awake = false;
    this.stopping = true;
    this.resting = this.send("Page.stopScreencast", {}).catch(() => void 0).then(() => {
      this.stopping = false;
      calmed();
    });
  }
  async casting(method, params, forward) {
    const starts = method.startsWith("Page.start");
    const before = this.cast;
    if (starts) this.cast = true;
    while (this.count > 0) await this.calm;
    await this.resting;
    try {
      const result = await forward(method, params);
      if (!starts) this.cast = false;
      return result;
    } catch (error) {
      if (starts) this.cast = before;
      throw error;
    }
  }
  hides(method, params) {
    if (!method.startsWith("Page.screencast")) return false;
    const id = params?.["sessionId"];
    if (!this.cast || this.count > 0 || this.awake || this.stopping) {
      if (id !== void 0 && !this.ours.includes(id)) {
        this.ours.push(id);
        if (this.ours.length > KEEP) this.ours.shift();
      }
      return true;
    }
    return id !== void 0 && this.ours.includes(id);
  }
};
var WORLD = "slicc: refused: that execution context belongs to a browser extension";
var UNSEEN_CONTEXT = "slicc: refused: that execution context or object is not exposed to browser automation";
var PROFILED = "slicc: refused: a browser extension runs scripts in this page, and profiling it would expose them";
var RESERVED_WORLD = "slicc: refused: that world name is reserved for the guard";
var EXTENSION_FRAME = "slicc: refused: another browser extension has a frame in this tab, and Chrome doesn't let one extension debug another's frames";
var ABOUT_WORLD = "slicc-navigate";
var EXTENSION_SCHEMES = ["chrome-extension:", "moz-extension:", "safari-web-extension:", "ms-browser-extension:"];
var PROFILED_DOMAINS = ["Debugger.", "DOMDebugger.", "Profiler.", "HeapProfiler."];
var OBJECT_KEY = /^(objectId|\w+ObjectId)$/;
var OPAQUE_KEYS = /* @__PURE__ */ new Set(["value", "unserializableValue", "expression", "functionDeclaration"]);
var FOREIGN_FRAME = /chrome-extension:\/\/ URL of different extension/i;
function isObj2(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function extensionOrigin(origin) {
  if (typeof origin !== "string") return false;
  const lower = origin.toLowerCase();
  return EXTENSION_SCHEMES.some((scheme2) => lower.startsWith(scheme2));
}
function foreignFrameError(error) {
  return FOREIGN_FRAME.test(String(error?.message ?? error));
}
function profiled(method) {
  return PROFILED_DOMAINS.some((domain) => method.startsWith(domain));
}
function objectContext(objectId) {
  const found = /^-?\d+\.(-?\d+)\.-?\d+$/.exec(objectId);
  return found ? Number(found[1]) : void 0;
}
function selectors(value, out = [], depth = 0) {
  if (depth > 16) {
    out.push({ kind: "deep" });
    return out;
  }
  if (Array.isArray(value)) {
    for (const item of value) selectors(item, out, depth + 1);
    return out;
  }
  if (!isObj2(value)) return out;
  for (const [key, item] of Object.entries(value)) {
    if (OPAQUE_KEYS.has(key)) continue;
    if ((key === "contextId" || key === "executionContextId") && typeof item === "number") {
      out.push({ kind: "id", value: item });
    } else if (key === "uniqueContextId" || key === "executionContextUniqueId") {
      out.push({ kind: "unique", value: item });
    } else if (OBJECT_KEY.test(key)) {
      out.push({ kind: "object", value: item });
    } else if (key === "executionContextName") {
      out.push({ kind: "name", value: item });
    } else if (typeof item === "object" && item !== null) {
      selectors(item, out, depth + 1);
    }
  }
  return out;
}
var Worlds = class {
  ids = /* @__PURE__ */ new Map();
  uniques = /* @__PURE__ */ new Map();
  names = /* @__PURE__ */ new Set();
  handles = /* @__PURE__ */ new Map();
  foreign = false;
  learn(value, depth = 0) {
    if (depth > 16 || typeof value !== "object" || value === null) return;
    if (Array.isArray(value)) {
      for (const item of value) this.learn(item, depth + 1);
      return;
    }
    for (const [key, item] of Object.entries(value)) {
      if (OBJECT_KEY.test(key) && typeof item === "string") {
        this.handles.delete(item);
        this.handles.set(item, true);
        if (this.handles.size > 5e4) {
          const oldest = this.handles.keys().next().value;
          if (oldest !== void 0) this.handles.delete(oldest);
        }
      } else {
        this.learn(item, depth + 1);
      }
    }
  }
  kindOf(context, protectedOrigin) {
    const aux = isObj2(context["auxData"]) ? context["auxData"] : {};
    const origin = typeof context["origin"] === "string" ? context["origin"] : "";
    if (aux["isDefault"] !== true && context["name"] === ABOUT_WORLD) return "ours";
    if (aux["isDefault"] !== true && (extensionOrigin(origin) || protectedOrigin(origin))) {
      return "foreign";
    }
    return void 0;
  }
  add(context, kind) {
    const hidden = kind !== void 0;
    const id = context["id"];
    if (typeof id === "number") {
      const before = this.ids.get(id);
      this.ids.set(id, { hidden: hidden || before?.hidden === true, context });
    }
    const unique = context["uniqueId"];
    if (typeof unique === "string") {
      this.uniques.set(unique, hidden || this.uniques.get(unique) === true);
    }
    const name = context["name"];
    if (hidden && typeof name === "string") this.names.add(name);
    const latched = kind === "foreign" && !this.foreign;
    if (kind === "foreign") this.foreign = true;
    return latched;
  }
  seen(id) {
    if (typeof id !== "number" || this.ids.has(id)) return;
    this.ids.set(id, { hidden: false, context: void 0 });
  }
  remove(id) {
    if (typeof id !== "number") return false;
    if (this.ids.get(id)?.hidden) return true;
    this.ids.delete(id);
    return false;
  }
  clear() {
    for (const [id, entry] of this.ids) if (!entry.hidden) this.ids.delete(id);
  }
  named(name) {
    return typeof name === "string" && this.names.has(name);
  }
  visible() {
    return [...this.ids.entries()].filter(([, entry]) => !entry.hidden && entry.context !== void 0).sort(([a], [b]) => a - b).map(([, entry]) => entry.context);
  }
  bindingContexts() {
    return [...this.ids.values()].map((entry) => entry.context).filter((context) => typeof context?.["uniqueId"] === "string" && this.uniques.get(context["uniqueId"]) === false);
  }
  verdict(selector) {
    if (selector.kind === "deep") return UNSEEN_CONTEXT;
    if (selector.kind === "name") {
      return typeof selector.value === "string" && this.names.has(selector.value) ? WORLD : void 0;
    }
    if (selector.kind === "unique") {
      const unique = selector.value;
      if (typeof unique !== "string" || !this.uniques.has(unique)) return UNSEEN_CONTEXT;
      return this.uniques.get(unique) ? WORLD : void 0;
    }
    const id = selector.value;
    if (selector.kind === "object") {
      const context = typeof id === "string" ? objectContext(id) : void 0;
      if (context !== void 0 && this.ids.get(context)?.hidden) return WORLD;
      return typeof id === "string" && this.handles.has(id) ? void 0 : UNSEEN_CONTEXT;
    }
    const entry = typeof id === "number" ? this.ids.get(id) : void 0;
    if (!entry) return UNSEEN_CONTEXT;
    return entry.hidden ? WORLD : void 0;
  }
  refusal(params) {
    for (const selector of selectors(params)) {
      const reason = this.verdict(selector);
      if (reason) return reason;
    }
    return void 0;
  }
  hides(params) {
    return selectors(params).some((selector) => {
      if (selector.kind === "deep") return true;
      if (selector.kind === "name") return false;
      return this.verdict(selector) === WORLD;
    });
  }
};
function scopedBinding(params) {
  if (params["executionContextId"] !== void 0 || params["executionContextName"] !== void 0) {
    return params;
  }
  return { ...params, executionContextName: "" };
}
var catalog_default = { schema: 1, minChromiumMajor: 116, browsers: [{ id: "chrome", name: "Google Chrome", channel: "stable", engine: "chromium", chromiumVersion: true, macos: { bundleId: "com.google.Chrome", app: "Google Chrome.app", executable: "Google Chrome", dataDir: ["Google", "Chrome"] }, windows: { roots: ["PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"], executables: [["Google", "Chrome", "Application", "chrome.exe"]], dataRoot: "LOCALAPPDATA", dataDir: ["Google", "Chrome", "User Data"], startMenuInternet: ["Google Chrome"] }, linux: { bins: ["google-chrome-stable", "google-chrome"], desktopIds: ["google-chrome", "com.google.Chrome"], flatpak: "com.google.Chrome", configDir: ["google-chrome"], debs: ["google-chrome-stable"] } }, { id: "edge", name: "Microsoft Edge", channel: "stable", engine: "chromium", chromiumVersion: true, macos: { bundleId: "com.microsoft.edgemac", app: "Microsoft Edge.app", executable: "Microsoft Edge", dataDir: ["Microsoft Edge"] }, windows: { roots: ["PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"], executables: [["Microsoft", "Edge", "Application", "msedge.exe"]], dataRoot: "LOCALAPPDATA", dataDir: ["Microsoft", "Edge", "User Data"], startMenuInternet: ["Microsoft Edge"] }, linux: { bins: ["microsoft-edge-stable", "microsoft-edge"], desktopIds: ["microsoft-edge", "com.microsoft.Edge"], flatpak: "com.microsoft.Edge", configDir: ["microsoft-edge"], debs: ["microsoft-edge-stable"] } }, { id: "brave", name: "Brave Browser", channel: "stable", engine: "chromium", chromiumVersion: false, macos: { bundleId: "com.brave.Browser", app: "Brave Browser.app", executable: "Brave Browser", dataDir: ["BraveSoftware", "Brave-Browser"] }, windows: { roots: ["PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"], executables: [["BraveSoftware", "Brave-Browser", "Application", "brave.exe"]], dataRoot: "LOCALAPPDATA", dataDir: ["BraveSoftware", "Brave-Browser", "User Data"], startMenuInternet: ["Brave"] }, linux: { bins: ["brave-browser", "brave-browser-stable", "brave"], desktopIds: ["brave-browser", "com.brave.Browser", "brave_brave"], flatpak: "com.brave.Browser", snap: "brave", configDir: ["BraveSoftware", "Brave-Browser"], debs: ["brave-browser"] } }, { id: "opera", name: "Opera", channel: "stable", engine: "chromium", chromiumVersion: false, macos: { bundleId: "com.operasoftware.Opera", app: "Opera.app", executable: "Opera", dataDir: ["com.operasoftware.Opera"] }, windows: { roots: ["LOCALAPPDATA", "PROGRAMFILES", "PROGRAMFILES(X86)"], executables: [["Programs", "Opera", "opera.exe"], ["Opera", "opera.exe"]], dataRoot: "APPDATA", dataDir: ["Opera Software", "Opera Stable"], startMenuInternet: ["OperaStable"] }, linux: { bins: ["opera"], desktopIds: ["opera", "com.opera.Opera", "opera_opera"], flatpak: "com.opera.Opera", snap: "opera", configDir: ["opera"], debs: ["opera-stable"] } }, { id: "vivaldi", name: "Vivaldi", channel: "stable", engine: "chromium", chromiumVersion: false, macos: { bundleId: "com.vivaldi.Vivaldi", app: "Vivaldi.app", executable: "Vivaldi", dataDir: ["Vivaldi"] }, windows: { roots: ["LOCALAPPDATA", "PROGRAMFILES", "PROGRAMFILES(X86)"], executables: [["Vivaldi", "Application", "vivaldi.exe"]], dataRoot: "LOCALAPPDATA", dataDir: ["Vivaldi", "User Data"], startMenuInternet: ["Vivaldi"] }, linux: { bins: ["vivaldi-stable", "vivaldi"], desktopIds: ["vivaldi-stable", "com.vivaldi.Vivaldi"], flatpak: "com.vivaldi.Vivaldi", configDir: ["vivaldi"], debs: ["vivaldi-stable"] } }, { id: "arc", name: "Arc", channel: "stable", engine: "chromium", chromiumVersion: false, macos: { bundleId: "company.thebrowser.Browser", app: "Arc.app", executable: "Arc", dataDir: ["Arc", "User Data"] } }, { id: "atlas", name: "ChatGPT Atlas", channel: "stable", engine: "chromium", chromiumVersion: false, macos: { bundleId: "com.openai.atlas", app: "ChatGPT Atlas.app", executable: "ChatGPT Atlas" } }, { id: "dia", name: "Dia", channel: "stable", engine: "chromium", chromiumVersion: false, macos: { bundleId: "company.thebrowser.dia", app: "Dia.app", executable: "Dia", dataDir: ["Dia", "User Data"] } }, { id: "chrome-beta", name: "Google Chrome Beta", channel: "beta", engine: "chromium", chromiumVersion: true, macos: { bundleId: "com.google.Chrome.beta", app: "Google Chrome Beta.app", executable: "Google Chrome Beta", dataDir: ["Google", "Chrome Beta"] }, windows: { roots: ["PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"], executables: [["Google", "Chrome Beta", "Application", "chrome.exe"]], dataRoot: "LOCALAPPDATA", dataDir: ["Google", "Chrome Beta", "User Data"], startMenuInternet: ["Google Chrome Beta"] }, linux: { bins: ["google-chrome-beta"], desktopIds: ["google-chrome-beta"], configDir: ["google-chrome-beta"], debs: ["google-chrome-beta"] } }, { id: "chrome-dev", name: "Google Chrome Dev", channel: "dev", engine: "chromium", chromiumVersion: true, macos: { bundleId: "com.google.Chrome.dev", app: "Google Chrome Dev.app", executable: "Google Chrome Dev", dataDir: ["Google", "Chrome Dev"] }, windows: { roots: ["PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"], executables: [["Google", "Chrome Dev", "Application", "chrome.exe"]], dataRoot: "LOCALAPPDATA", dataDir: ["Google", "Chrome Dev", "User Data"], startMenuInternet: ["Google Chrome Dev"] }, linux: { bins: ["google-chrome-unstable"], desktopIds: ["google-chrome-unstable", "com.google.ChromeDev"], flatpak: "com.google.ChromeDev", configDir: ["google-chrome-unstable"], debs: ["google-chrome-unstable"] } }, { id: "chrome-canary", name: "Google Chrome Canary", channel: "canary", engine: "chromium", chromiumVersion: true, macos: { bundleId: "com.google.Chrome.canary", app: "Google Chrome Canary.app", executable: "Google Chrome Canary", dataDir: ["Google", "Chrome Canary"] }, windows: { roots: ["LOCALAPPDATA"], executables: [["Google", "Chrome SxS", "Application", "chrome.exe"]], dataRoot: "LOCALAPPDATA", dataDir: ["Google", "Chrome SxS", "User Data"], startMenuInternet: ["Google Chrome Canary"] }, linux: { bins: ["google-chrome-canary"], desktopIds: ["google-chrome-canary"], configDir: ["google-chrome-canary"], debs: ["google-chrome-canary"] } }, { id: "brave-beta", name: "Brave Browser Beta", channel: "beta", engine: "chromium", chromiumVersion: false, macos: { bundleId: "com.brave.Browser.beta", app: "Brave Browser Beta.app", executable: "Brave Browser Beta", dataDir: ["BraveSoftware", "Brave-Browser-Beta"] }, windows: { roots: ["PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"], executables: [["BraveSoftware", "Brave-Browser-Beta", "Application", "brave.exe"]], dataRoot: "LOCALAPPDATA", dataDir: ["BraveSoftware", "Brave-Browser-Beta", "User Data"] }, linux: { bins: ["brave-browser-beta"], desktopIds: ["brave-browser-beta"], configDir: ["BraveSoftware", "Brave-Browser-Beta"], debs: ["brave-browser-beta"] } }, { id: "brave-nightly", name: "Brave Browser Nightly", channel: "nightly", engine: "chromium", chromiumVersion: false, macos: { bundleId: "com.brave.Browser.nightly", app: "Brave Browser Nightly.app", executable: "Brave Browser Nightly", dataDir: ["BraveSoftware", "Brave-Browser-Nightly"] }, windows: { roots: ["PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"], executables: [["BraveSoftware", "Brave-Browser-Nightly", "Application", "brave.exe"]], dataRoot: "LOCALAPPDATA", dataDir: ["BraveSoftware", "Brave-Browser-Nightly", "User Data"] }, linux: { bins: ["brave-browser-nightly"], desktopIds: ["brave-browser-nightly"], configDir: ["BraveSoftware", "Brave-Browser-Nightly"], debs: ["brave-browser-nightly"] } }, { id: "edge-beta", name: "Microsoft Edge Beta", channel: "beta", engine: "chromium", chromiumVersion: true, macos: { bundleId: "com.microsoft.edgemac.Beta", app: "Microsoft Edge Beta.app", executable: "Microsoft Edge Beta", dataDir: ["Microsoft Edge Beta"] }, windows: { roots: ["PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"], executables: [["Microsoft", "Edge Beta", "Application", "msedge.exe"]], dataRoot: "LOCALAPPDATA", dataDir: ["Microsoft", "Edge Beta", "User Data"], startMenuInternet: ["Microsoft Edge Beta"] }, linux: { bins: ["microsoft-edge-beta"], desktopIds: ["microsoft-edge-beta"], configDir: ["microsoft-edge-beta"], debs: ["microsoft-edge-beta"] } }, { id: "edge-dev", name: "Microsoft Edge Dev", channel: "dev", engine: "chromium", chromiumVersion: true, macos: { bundleId: "com.microsoft.edgemac.Dev", app: "Microsoft Edge Dev.app", executable: "Microsoft Edge Dev", dataDir: ["Microsoft Edge Dev"] }, windows: { roots: ["PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"], executables: [["Microsoft", "Edge Dev", "Application", "msedge.exe"]], dataRoot: "LOCALAPPDATA", dataDir: ["Microsoft", "Edge Dev", "User Data"], startMenuInternet: ["Microsoft Edge Dev"] }, linux: { bins: ["microsoft-edge-dev"], desktopIds: ["microsoft-edge-dev"], configDir: ["microsoft-edge-dev"], debs: ["microsoft-edge-dev"] } }, { id: "edge-canary", name: "Microsoft Edge Canary", channel: "canary", engine: "chromium", chromiumVersion: true, macos: { bundleId: "com.microsoft.edgemac.Canary", app: "Microsoft Edge Canary.app", executable: "Microsoft Edge Canary", dataDir: ["Microsoft Edge Canary"] }, windows: { roots: ["LOCALAPPDATA"], executables: [["Microsoft", "Edge SxS", "Application", "msedge.exe"]], dataRoot: "LOCALAPPDATA", dataDir: ["Microsoft", "Edge SxS", "User Data"], startMenuInternet: ["Microsoft Edge Canary"] } }, { id: "vivaldi-snapshot", name: "Vivaldi Snapshot", channel: "snapshot", engine: "chromium", chromiumVersion: false, macos: { bundleId: "com.vivaldi.Vivaldi.snapshot", app: "Vivaldi Snapshot.app", executable: "Vivaldi Snapshot", dataDir: ["Vivaldi Snapshot"] }, linux: { bins: ["vivaldi-snapshot"], desktopIds: ["vivaldi-snapshot"], configDir: ["vivaldi-snapshot"], debs: ["vivaldi-snapshot"] } }, { id: "chrome-for-testing", name: "Google Chrome for Testing", channel: "testing", engine: "chromium", chromiumVersion: true, macos: { bundleId: "com.google.chrome.for.testing", app: "Google Chrome for Testing.app", executable: "Google Chrome for Testing", dataDir: ["Google", "Chrome for Testing"] }, windows: { dataRoot: "LOCALAPPDATA", dataDir: ["Google", "Chrome for Testing", "User Data"] }, linux: { configDir: ["google-chrome-for-testing"] } }, { id: "chromium", name: "Chromium", channel: "stable", engine: "chromium", chromiumVersion: true, macos: { bundleId: "org.chromium.Chromium", app: "Chromium.app", executable: "Chromium", dataDir: ["Chromium"] }, windows: { roots: ["LOCALAPPDATA", "PROGRAMFILES", "PROGRAMFILES(X86)"], executables: [["Chromium", "Application", "chrome.exe"]], dataRoot: "LOCALAPPDATA", dataDir: ["Chromium", "User Data"], startMenuInternet: ["Chromium"] }, linux: { bins: ["chromium", "chromium-browser"], desktopIds: ["chromium", "chromium-browser", "chromium_chromium", "org.chromium.Chromium"], flatpak: "org.chromium.Chromium", snap: "chromium", snapDataDir: ["chromium"], configDir: ["chromium"], debs: ["chromium", "chromium-browser"] } }], electron: { macosApps: [{ bundleId: "com.microsoft.teams2", name: "Microsoft Teams" }, { bundleId: "com.microsoft.VSCode", name: "Visual Studio Code" }, { bundleId: "com.microsoft.VSCodeInsiders", name: "VS Code Insiders" }, { bundleId: "com.spotify.client", name: "Spotify" }, { bundleId: "com.tinyspeck.slackmacgap", name: "Slack" }, { bundleId: "com.hnc.Discord", name: "Discord" }, { bundleId: "com.todesktop.230313mzl4w4u92", name: "Cursor" }, { bundleId: "com.figma.Desktop", name: "Figma" }, { bundleId: "notion.id", name: "Notion" }, { bundleId: "com.obsproject.obs-studio", name: "OBS Studio" }, { bundleId: "com.1password.1password", name: "1Password" }, { bundleId: "us.zoom.xos", name: "Zoom" }, { bundleId: "com.linear", name: "Linear" }, { bundleId: "com.loom.desktop", name: "Loom" }, { bundleId: "md.obsidian", name: "Obsidian" }, { bundleId: "com.bitwarden.desktop", name: "Bitwarden" }, { bundleId: "com.todoist.mac.Todoist", name: "Todoist" }, { bundleId: "com.github.GitHubClient", name: "GitHub Desktop" }, { bundleId: "com.postmanlabs.mac", name: "Postman" }, { bundleId: "org.whispersystems.signal-desktop", name: "Signal" }, { bundleId: "com.tdesktop.Telegram", name: "Telegram Desktop" }, { bundleId: "com.logseq.logseq", name: "Logseq" }, { bundleId: "com.whatsonchain.WhatsOnChain", name: "WhatsOnChain" }, { bundleId: "io.trystorybook.app", name: "Storybook" }, { bundleId: "com.mongodb.compass", name: "MongoDB Compass" }, { bundleId: "com.insomnia.app", name: "Insomnia" }, { bundleId: "com.jetbrains.toolbox", name: "JetBrains Toolbox" }, { bundleId: "com.electron.replit", name: "Replit" }, { bundleId: "com.twitch.studio", name: "Twitch Studio" }], debugBlocked: ["Claude", "1Password"], idPrefix: "electron:" }, rank: { tiers: { sevenOpen: 1, endpoint: 2, chrome: 3, chromium: 4, electron: 5, six: 6 }, chromeId: "chrome" }, discovery: { activePortFile: "DevToolsActivePort", probePorts: [9222, 9223, 9224, 9225, 9226, 9227, 9228, 9229], sourceRank: { "devtools-active-port": 0, flag: 1, process: 2, probe: 3 }, chromeMajorPattern: "(?:Chrome|Chromium|HeadlessChrome)/(\\d+)", names: { electronUserAgent: " Electron/", electron: "Electron", products: { Edg: "Microsoft Edge", HeadlessChrome: "Chrome (headless)" }, fallback: "Chromium" }, process: { unix: ["ps", "-ax", "-o", "pid=", "-o", "command="], windows: ["powershell", "-NoProfile", "-Command", "Get-CimInstance Win32_Process | Select-Object ProcessId, CommandLine | ConvertTo-Json -Compress"], portFlag: "--remote-debugging-port", userDataDirFlag: "--user-data-dir", valueQuotes: ['"', "'"], valueStop: "--", wrappers: ["node", "npx", "tsx", "npm", "open", "bash", "zsh", "sh", "csh", "fish", "dash", "timeout", "env", "sudo", "caffeinate", "cmd", "powershell", "pwsh"], wrapperSuffixes: [".exe", ".cmd", ".bat"] } }, seven: { originScheme: "https", originHostPattern: "^([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)\\.sliccy\\.ai$", excludedLabels: ["www", "vault", "vault-preview", "get", "mcpcat", "echo"], excludedLabelPrefixes: ["vault-"], sitePattern: "[*.]sliccy.ai", switches: ["--disable-background-timer-throttling", "--disable-backgrounding-occluded-windows", "--disable-renderer-backgrounding", "--disable-background-tracing"], disabledFeatures: ["LocalNetworkAccessChecks", "LocalNetworkAccessChecksWebSockets", "IntensiveWakeUpThrottling", "HighEfficiencyModeAvailable", "InfiniteTabsFreezing", "InfiniteTabsFreezingOnMemoryPressure", "CPUMeasurementInFreezingPolicy", "MemoryMeasurementInFreezingPolicy", "AllowDevtoolsConnectedDiscard"], prefs: [{ path: ["tab_freezing_enabled"], value: false, form: "six" }, { path: ["performance_tuning", "tab_freezing", "enabled"], value: false, form: "chrome-154" }, { path: ["performance_tuning", "high_efficiency_mode", "state"], value: 0, form: "chrome-154" }], discardExceptions: [{ path: ["performance_tuning", "tab_discarding", "exceptions"], type: "list", form: "six" }, { path: ["performance_tuning", "tab_discarding", "exceptions_with_time"], type: "chrome-time-map", form: "chrome-154" }], cleanExit: [{ path: ["profile", "exit_type"], value: "Normal" }, { path: ["profile", "exited_cleanly"], value: true }] }, protectedOrigins: { domains: ["sliccy.ai"], hosts: ["vault.sliccy.ai"], schemes: ["https", "http"], innerSchemes: ["blob", "filesystem", "view-source"], anySchemes: ["devtools"], protectedSchemes: ["chrome", "chrome-untrusted", "chrome-search", "chrome-native", "chrome-distiller", "chrome-experimental-site-token-provider", "isolated-app", "externalfile", "content", "chrome-extension", "devtools", "edge", "brave", "opera", "vivaldi", "arc", "file"], schemeExceptions: ["chrome://newtab", "chrome://new-tab-page", "chrome-untrusted://new-tab-page", "edge://newtab", "brave://newtab", "opera://startpage"], aboutScheme: "chrome", targetTypes: ["browser_ui"], inheriting: ["about:blank", "about:srcdoc"], errorPage: { url: "chrome-error://chromewebdata/", target: "previous", redact: "origin" }, unparseable: "protected", unparseableRefusal: "slicc: refused: slicc can't parse this URL, so it could be a protected page", refusal: "slicc: refused: target is on seven's origin" }, profiles: { root: ["slicc", "seven-profiles"], snapRoot: ["slicc", "seven-profiles"], legacyRoot: ["slicc", "profiles"], sixProfilePattern: "^browser-coding-agent-chrome(-[0-9]+)?$", namePattern: "^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$", six: { roots: { macos: { base: { home: ["Library", "Application Support"] }, path: ["Slicc", "profiles"] }, linux: { base: { env: "XDG_STATE_HOME", home: [".local", "state"] }, path: ["slicc", "profiles"] }, windows: { base: { env: "LOCALAPPDATA", home: ["AppData", "Local"] }, path: ["Slicc", "profiles"] } }, defaultName: "browser-coding-agent-chrome", defaultPort: 5710, portSuffix: "-{port}", userDataDirEnv: "SLICC_USER_DATA_DIR" } }, launch: { chromiumArgs: ["--remote-debugging-port=0", "--user-data-dir={profile}", "--no-first-run", "--no-default-browser-check"], headless: "--headless=new", disableFeaturesFlag: "--disable-features=", electron: { portFlag: "--remote-debugging-port={port}", minPort: 9333, reservedPorts: [9222, 9223, 9224, 9225, 9226, 9227, 9228, 9229] } }, platforms: { macos: { config: { home: ["Library", "Application Support"] } }, windows: { config: { env: "APPDATA", home: ["AppData", "Roaming"] }, roots: { PROGRAMFILES: { env: "PROGRAMFILES", absolute: "C:\\Program Files" }, "PROGRAMFILES(X86)": { env: "PROGRAMFILES(X86)", absolute: "C:\\Program Files (x86)" }, LOCALAPPDATA: { env: "LOCALAPPDATA", home: ["AppData", "Local"] }, APPDATA: { env: "APPDATA", home: ["AppData", "Roaming"] } }, registry: { hives: ["HKCU", "HKLM"], startMenuInternet: ["SOFTWARE\\Clients\\StartMenuInternet", "SOFTWARE\\WOW6432Node\\Clients\\StartMenuInternet"], openCommand: "shell\\open\\command", appPaths: "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths", appPathNames: ["chrome.exe", "msedge.exe", "brave.exe", "vivaldi.exe", "opera.exe"] } }, linux: { config: { env: "XDG_CONFIG_HOME", home: [".config"] } } } };
var parse = (text) => {
  if (typeof text !== "string") return null;
  try {
    return new URL(text);
  } catch {
    return null;
  }
};
var scheme = (u) => u.protocol.slice(0, -1);
var hostOf = (u) => {
  const h = u.hostname.toLowerCase();
  return h.endsWith(".") ? h.slice(0, -1) : h;
};
var originOf = (u) => {
  if (!u?.host) return null;
  return `${scheme(u)}://${hostOf(u)}${u.port ? `:${u.port}` : ""}`;
};
var under = (host, domain) => host === domain || host.endsWith(`.${domain}`);
function protectedOrigins(rules, extraOrigins = []) {
  const extra = extraOrigins.map((o) => originOf(parse(o))).filter(Boolean);
  const extraHosts = extraOrigins.map((o) => parse(o)).filter((u) => u?.host).map(hostOf);
  const unwrap = (u) => {
    for (let i = 0; u && rules.innerSchemes.includes(scheme(u)) && i < 8; i += 1) {
      u = parse(u.href.slice(u.protocol.length));
    }
    return u;
  };
  const alias = (u) => {
    if (!u || scheme(u) !== "about" || !rules.aboutScheme) return u;
    if (rules.inheriting.includes(`about:${u.pathname.toLowerCase()}`)) return u;
    return parse(`${rules.aboutScheme}://${u.pathname}${u.search}${u.hash}`) ?? u;
  };
  const exempt = (text) => text === "" || text === "null" || text === "://";
  const failed = (u) => !u || rules.innerSchemes.includes(scheme(u));
  const unparseable = (text) => !exempt(text) && failed(unwrap(parse(text)));
  const url = (text, { readOnly = false } = {}) => {
    const u = alias(unwrap(parse(text)));
    if (failed(u)) return rules.unparseable === "protected" && !readOnly && !exempt(text);
    const s = scheme(u);
    if (rules.anySchemes.includes(s)) return true;
    if ((rules.protectedSchemes ?? []).includes(s)) return !(rules.schemeExceptions ?? []).includes(`${s}://${hostOf(u)}`);
    if (rules.schemes.includes(s) && rules.hosts.includes(hostOf(u))) return true;
    if (rules.schemes.includes(s) && rules.domains.some((d) => under(hostOf(u), d))) return true;
    const o = originOf(u);
    return o !== null && extra.includes(o);
  };
  const inheriting = (text) => {
    if (text === "") return true;
    const u = parse(text);
    return u !== null && scheme(u) === "about" && rules.inheriting.includes(`about:${u.pathname.toLowerCase()}`);
  };
  const target = ({ url: text, previous = false, opener, type, documentURL, unreachableURL, navigating = false }) => {
    if (type && (rules.targetTypes ?? []).includes(type)) return true;
    if (rules.errorPage && documentURL === rules.errorPage.url && unreachableURL === text && !navigating) return previous;
    if (inheriting(text)) return previous || opener === "protected" || opener === "unknown";
    return url(text);
  };
  const cookieDomain = (domain) => {
    let d = domain.toLowerCase();
    if (d.startsWith(".")) d = d.slice(1);
    if (d.endsWith(".")) d = d.slice(0, -1);
    if (d === "") return false;
    if (rules.domains.some((x) => under(d, x))) return true;
    return [...rules.domains, ...rules.hosts, ...extraHosts].some((h) => under(h, d));
  };
  const storageKey = (key) => {
    const [first, ...rest] = key.split("^");
    return [first, ...rest.filter((p) => p.startsWith("0")).map((p) => p.slice(1))].some((text) => url(text, { readOnly: true }));
  };
  return { url, target, cookieDomain, storageKey, unparseable };
}
var base = protectedOrigins(catalog_default.protectedOrigins);
var FORBIDDEN_HOST = /[\u0000-\u0020%\u007f#/:<>?@[\\\]^|]/;
var failClosed = catalog_default.protectedOrigins.unparseable === "protected";
function parsed(text) {
  try {
    return new URL(text);
  } catch {
    return null;
  }
}
function noncanonical(text) {
  if (typeof text !== "string") return false;
  const inner = catalog_default.protectedOrigins.innerSchemes;
  let u = parsed(text);
  for (let i = 0; u && inner.includes(u.protocol.slice(0, -1)) && i < 8; i += 1) {
    u = parsed(u.href.slice(u.protocol.length));
  }
  if (!u?.hostname || u.hostname.startsWith("[")) return false;
  return FORBIDDEN_HOST.test(u.hostname);
}
var guard = { ...base, url: (text, options = {}) => base.url(text, options) || failClosed && !options.readOnly && noncanonical(text), target: (info) => base.target(info) || failClosed && noncanonical(info.url), unparseable: (text) => base.unparseable(text) || noncanonical(text) };
var PROTECTED_RULES = catalog_default.protectedOrigins;
var PROTECTED_REFUSAL = catalog_default.protectedOrigins.refusal;
function isProtectedUrl(rawUrl, readOnly = false) {
  if (!rawUrl) return false;
  return guard.url(rawUrl, { readOnly });
}
function isUnparseableUrl(rawUrl) {
  return guard.unparseable(rawUrl);
}
function refuseUnparseableDestination(url) {
  if (typeof url === "string" && /^\s*[a-z][a-z0-9+.-]*:/i.test(url) && guard.unparseable(url)) {
    throw new Error(catalog_default.protectedOrigins.unparseableRefusal);
  }
}
function isProtectedTarget(url, previous = false, opener, type) {
  return guard.target({ url, previous, opener, type });
}
function isProtectedTargetType(type) {
  return typeof type === "string" && guard.target({ url: "about:blank", opener: "unprotected", type });
}
function isProtectedCookieDomain(domain) {
  return guard.cookieDomain(domain);
}
function isProtectedStorageKey(key) {
  return guard.storageKey(key);
}
async function openerStateOf(tab, getTab) {
  if (typeof tab.openerTabId !== "number") return void 0;
  try {
    const opener = await getTab(tab.openerTabId);
    if (!opener) return "unknown";
    const openerProtected = isProtectedTarget(opener.url ?? "", false, "unknown") || isProtectedUrl(opener.pendingUrl);
    return openerProtected ? "protected" : "unprotected";
  } catch {
    return "unknown";
  }
}
async function isProtectedTab(tab, getTab) {
  if (!tab) return false;
  if (isProtectedUrl(tab.pendingUrl)) return true;
  const url = tab.url ?? "";
  if (isProtectedUrl(url)) return true;
  return isProtectedTarget(url, false, await openerStateOf(tab, getTab));
}
var ERROR_PAGE = "chrome-error://chromewebdata/";
var BROWSER_LEVEL = /* @__PURE__ */ new Set(["Browser.getVersion", "Browser.getBrowserCommandLine", "Browser.getHistograms", "Browser.getHistogram", "Browser.getWindowForTarget", "Browser.getWindowBounds", "Browser.setWindowBounds", "Browser.setDockTile", "Target.getTargets", "Target.getBrowserContexts", "Target.setDiscoverTargets"]);
function unfragmented(url) {
  const at = url.indexOf("#");
  return at < 0 ? url : url.slice(0, at);
}
function contentResult(method) {
  return sealedRead(method) || method.startsWith("DOM.") || method.startsWith("CSS.") || method.startsWith("Accessibility.") || method.startsWith("Runtime.") || method === "Page.captureSnapshot" || method === "Page.getResourceContent" || method === "Page.searchInResource" || method === "Page.captureScreenshot" || method === "Page.printToPDF" || method === "Page.getFrameTree" || method === "Page.getResourceTree" || method === "Page.getNavigationHistory" || method === "Debugger.getScriptSource" || method === "Network.getResponseBody" || method === "Network.getRequestPostData" || method === "Network.getResponseBodyForInterception" || method === "Network.streamResourceContent" || method === "IO.read" || method === "IO.resolveBlob" || method === "Fetch.getResponseBody" || method === "Fetch.takeResponseBodyAsStream";
}
function errorPageRead(method) {
  return contentResult(method) && !BODY_METHODS.has(method) && method !== "Page.getNavigationHistory" || method.startsWith("Input.") || method === "Page.createIsolatedWorld" || method === "Page.startScreencast" || method === "Page.screencastFrame" || method === "Page.startScreenRecording";
}
var FRAME_CHANGES = /* @__PURE__ */ new Set(["DOM.documentUpdated", "Network.loadingFailed", "Page.backForwardCacheNotUsed", "Page.documentOpened", "Page.domContentEventFired", "Page.lifecycleEvent", "Page.loadEventFired", "Page.navigatedWithinDocument", "Runtime.executionContextCreated", "Runtime.executionContextDestroyed", "Runtime.executionContextsCleared"]);
function invalidates(method, params) {
  return FRAME_CHANGES.has(method) || ["Page.frame", "Target.", "Inspector."].some((prefix) => method.startsWith(prefix)) || ["Network.", "Fetch."].some((prefix) => method.startsWith(prefix)) && (params?.["type"] === "Document" || params?.["resourceType"] === "Document");
}
function framesKey(frames) {
  if (!frames.some((frame) => isObj3(frame) && frame["frameId"] === 0)) return void 0;
  const rows = [];
  for (const frame of frames) {
    if (!isObj3(frame) || !str(frame["documentId"])) return void 0;
    rows.push(JSON.stringify([frame["frameId"], frame["parentFrameId"], frame["documentId"], frame["parentDocumentId"], frame["documentLifecycle"], frame["frameType"], frame["processId"], frame["url"], frame["errorOccurred"]]));
  }
  return JSON.stringify(rows.sort());
}
var ORIGIN_KEYS = /* @__PURE__ */ new Set(["origin", "securityOrigin", "ownerOrigin", "issuerOrigin", "topLevelOrigin", "topLevelSite", "embeddedOrigin", "requestingOrigin", "scopeURL", "manifestId"]);
var FREE_FORM = /* @__PURE__ */ new Set(["expression", "arguments", "value", "headers", "postData", "functionDeclaration", "source", "text", "body", "data", "message"]);
var BODY_METHODS = /* @__PURE__ */ new Set(["Network.getResponseBody", "Network.searchInResponseBody", "Network.streamResourceContent", "Network.getResponseBodyForInterception", "Network.takeResponseBodyForInterceptionAsStream", "Network.getRequestPostData", "Network.replayXHR", "Fetch.getResponseBody", "Fetch.takeResponseBodyAsStream", "Audits.getEncodedResponse"]);
var COOKIE_SETTERS = /* @__PURE__ */ new Set(["Network.setCookie", "Network.setCookies", "Network.deleteCookies", "Storage.setCookies", "Page.deleteCookie"]);
var COOKIE_READERS = /* @__PURE__ */ new Set(["Network.getCookies", "Network.getAllCookies", "Storage.getCookies", "Page.getCookies"]);
var FETCH_ANSWERS = /* @__PURE__ */ new Set(["Fetch.continueRequest", "Fetch.fulfillRequest", "Fetch.failRequest", "Fetch.continueResponse", "Fetch.continueWithAuth", "Fetch.getResponseBody", "Fetch.takeResponseBodyAsStream"]);
var FETCH_SETTLES = /* @__PURE__ */ new Set(["Fetch.continueRequest", "Fetch.fulfillRequest", "Fetch.failRequest", "Fetch.continueResponse", "Fetch.continueWithAuth"]);
var REFUSED_METHODS = /* @__PURE__ */ new Map([["Page.setDocumentContent", "unbound document replacement is not supported"], ["Runtime.runScript", "script execution without a unique context binding is not supported"], ["Target.exposeDevToolsProtocol", "Target.exposeDevToolsProtocol would give a page the whole browser"], ["Target.sendMessageToTarget", "Target.sendMessageToTarget is refused: attach with flatten: true instead"], ["Target.attachToBrowserTarget", "Target.attachToBrowserTarget would give a page the whole browser"], ["Tracing.start", "Tracing.start records every target, seven's included"], ["Network.loadNetworkResource", "Network.loadNetworkResource follows redirects the guard cannot see, into seven's pages too"], ["Extensions.loadUnpacked", "Extensions.loadUnpacked can reach seven's origin"], ["Network.clearBrowserCookies", "Network.clearBrowserCookies would clear seven's cookies"], ["Storage.clearCookies", "Storage.clearCookies would clear seven's cookies"], ["Browser.resetPermissions", "Browser.resetPermissions would reset seven's permissions"], ["Security.setIgnoreCertificateErrors", "ignoring certificate errors would let a forged seven's origin load"], ["Security.setOverrideCertificateErrors", "overriding certificate errors would let a forged seven's origin load"]]);
var COOKIES_REFUSAL = "slicc: refused: cookie is on seven's origin";
var UNSEEN_REFUSAL = "slicc: refused: request was not seen by the shield";
var UNSETTLED_REFUSAL = "slicc: refused: navigation not settled, retry";
var STREAM_REFUSAL = "slicc: refused: stream handle was not opened through the shield";
var BODY_READ_REFUSAL = "slicc: refused: this paused response body was already read the other way";
var FETCH_READS = /* @__PURE__ */ new Set(["Fetch.getResponseBody", "Fetch.takeResponseBodyAsStream"]);
var REDIRECTS = /* @__PURE__ */ new Set([301, 302, 303, 307, 308]);
var SETTLES = /* @__PURE__ */ new Set(["Network.responseReceived", "Network.loadingFinished", "Network.loadingFailed"]);
var REROUTE_REFUSAL = "slicc: refused: the rewritten request answered with a protected url, so the guard failed it";
var PAUSE_REFUSAL = "slicc: refused: request was not paused toward this client";
var GUARD_FETCH_PATTERN = { urlPattern: "*", resourceType: "Document", requestStage: "Request" };
var NAVIGATES = /* @__PURE__ */ new Set(["Page.navigate", "Network.loadNetworkResource"]);
var ABOUT_OTHER = "slicc: refused: about: urls other than about:blank do not open";
var ABOUT_STUCK = "slicc: refused: the page did not open about:blank itself";
var ABOUT_WRAPPED = "slicc: refused: view-source and other wrappers of about: urls do not open";
function wrapsAbout(url, inner) {
  let text = url;
  for (let depth = 0; depth < 8; depth += 1) {
    if (typeof text !== "string" || !URL.canParse(text)) return false;
    const parsed2 = new URL(text);
    const scheme2 = parsed2.protocol.slice(0, -1);
    if (scheme2 === "about") return depth > 0;
    if (!inner.includes(scheme2)) return false;
    text = parsed2.href.slice(parsed2.protocol.length);
  }
  return true;
}
function aboutUrl(url) {
  if (typeof url !== "string" || !URL.canParse(url)) return void 0;
  const parsed2 = new URL(url);
  return parsed2.protocol === "about:" ? parsed2 : void 0;
}
function frameIn(tree, frameId) {
  const pending = [tree];
  while (pending.length > 0) {
    const node = pending.pop();
    if (!isObj3(node)) continue;
    const frame = node["frame"];
    if (isObj3(frame) && (frameId ? frame["id"] === frameId : frame["parentId"] === void 0)) {
      return frame;
    }
    if (Array.isArray(node["childFrames"])) pending.push(...node["childFrames"]);
  }
  return void 0;
}
function sameDocument(current, next) {
  return next.includes("#") && current.split("#")[0] === next.split("#")[0];
}
var DocumentBindings = class {
  frames = /* @__PURE__ */ new Map();
  contexts = /* @__PURE__ */ new Map();
  handles = /* @__PURE__ */ new Map();
  backends = /* @__PURE__ */ new Map();
  namespaces = /* @__PURE__ */ new Map();
  proven = /* @__PURE__ */ new Set();
  remember(tree) {
    const pending = [tree];
    while (pending.length > 0) {
      const node = pending.pop();
      if (!isObj3(node)) continue;
      this.frame(node["frame"]);
      if (Array.isArray(node["childFrames"])) pending.push(...node["childFrames"]);
    }
  }
  frame(frame) {
    if (!isObj3(frame)) return;
    const id = str(frame["id"]);
    const loaderId = str(frame["loaderId"]);
    if (id !== void 0 && loaderId !== void 0) {
      this.frames.set(id, { frameId: id, loaderId });
    }
  }
  context(context) {
    const aux = isObj3(context["auxData"]) ? context["auxData"] : {};
    const document = this.frames.get(str(aux["frameId"]) ?? "");
    const id = context["id"];
    if (document && typeof id === "number") {
      this.contexts.set(id, { ...document, uniqueId: str(context["uniqueId"]) });
    }
  }
  frameOf(context, tree) {
    const aux = isObj3(context["auxData"]) ? context["auxData"] : {};
    return frameIn(tree, str(aux["frameId"]));
  }
  current(document, tree) {
    if (!document) return false;
    return frameIn(tree, document.frameId)?.["loaderId"] === document.loaderId;
  }
  key(key, value) {
    if (key === "searchId" && typeof value === "string") return `search:${value}`;
    if (/^(objectId|\w+ObjectId)$/.test(key) && typeof value === "string") return `object:${value}`;
    if (/^(?:backendDOMN|[a-z]+N|n)odeIds?$/.test(key) && typeof value === "number") {
      return `${key.startsWith("backend") ? "backend" : "node"}:${value}`;
    }
    return void 0;
  }
  namespace(objectId) {
    return typeof objectId === "string" ? /^(-?\d+\.-?\d+)\.-?\d+$/.exec(objectId)?.[1] : void 0;
  }
  proof(context, objectId) {
    const document = this.contexts.get(context["id"]);
    const namespace = this.namespace(objectId);
    const unique = str(context["uniqueId"]);
    if (!document || !namespace || unique === void 0) return false;
    this.namespaces.set(namespace, document);
    this.proven.add(unique);
    return true;
  }
  learn(value, document, depth = 0) {
    if (depth > 32 || !value || typeof value !== "object") return;
    if (isObj3(value) && typeof value["nodeId"] === "number" && typeof value["backendNodeId"] === "number") {
      this.backends.set(value["nodeId"], value["backendNodeId"]);
    }
    for (const [key, item] of Object.entries(value)) {
      if (key === "value" && isObj3(value) && typeof value["type"] === "string") continue;
      const values = Array.isArray(item) ? item : [item];
      for (const entry of values) {
        const handle = this.key(key, entry);
        if (handle) {
          const owner = handle.startsWith("object:") ? this.namespaces.get(this.namespace(entry) ?? "") : document;
          this.handles.set(handle, owner);
          if (this.handles.size > 5e4) this.handles.delete(this.handles.keys().next().value);
        } else {
          this.learn(entry, document, depth + 1);
        }
      }
    }
  }
  event(params, mainFrameId) {
    const created = isObj3(params["context"]) ? params["context"] : {};
    const context = this.contexts.get(params["executionContextId"] ?? created["id"]);
    const parent = this.handles.get(`node:${String(params["parentId"] ?? params["parentNodeId"])}`);
    this.learn(params, context ?? parent ?? this.frames.get(str(params["frameId"]) ?? mainFrameId));
  }
  scopeContext(key, item, tree) {
    if (key === "contextId" || key === "executionContextId") {
      if (!this.current(this.contexts.get(item), tree)) refuse(UNSEEN_CONTEXT);
    }
    if (key === "uniqueContextId" || key === "executionContextUniqueId") {
      const document = [...this.contexts.values()].find((entry) => entry.uniqueId === item);
      if (!this.current(document, tree)) refuse(UNSEEN_CONTEXT);
    }
  }
  scope(params, tree) {
    for (const [key, value] of Object.entries(params)) {
      const values = Array.isArray(value) ? value : [value];
      for (const item of values) {
        this.scopeContext(key, item, tree);
        if (key === "arguments" && isObj3(item) && item["objectId"]) {
          this.scope({ objectId: item["objectId"] }, tree);
        }
        const handle = this.key(key, item);
        const document = handle?.startsWith("object:") && this.handles.has(handle) ? this.namespaces.get(this.namespace(item) ?? "") : this.handles.get(handle ?? "");
        if (handle && !this.current(document, tree)) refuse(UNSEEN_CONTEXT);
      }
    }
  }
  bind(method, params, visible, tree, mainFrameId) {
    this.scope(params, tree);
    if (params["nodeId"] !== void 0 && ["DOM.describeNode", "DOM.getOuterHTML", "DOM.resolveNode", "DOM.focus", "DOM.scrollIntoViewIfNeeded", "DOM.getBoxModel", "DOM.getContentQuads", "DOM.setFileInputFiles"].includes(method)) {
      const backendNodeId = this.backends.get(params["nodeId"]);
      if (backendNodeId !== void 0) {
        const { nodeId, ...rest2 } = params;
        params = { ...rest2, backendNodeId };
      }
    }
    const root = frameIn(tree, void 0);
    const owner = Object.entries(params).flatMap(([key, value]) => {
      const values = Array.isArray(value) ? value : [value];
      return values.map((entry) => this.handles.get(this.key(key, entry) ?? ""));
    }).find((entry) => entry !== void 0);
    let document = owner ?? (root && { frameId: str(root["id"]) ?? "", loaderId: str(root["loaderId"]) ?? "" });
    if (params["objectId"]) document = this.namespaces.get(this.namespace(params["objectId"]) ?? "");
    const keyed = method === "Runtime.evaluate" || method === "Runtime.callFunctionOn";
    const numbered = ["Runtime.compileScript", "Runtime.runScript", "Runtime.globalLexicalScopeNames"].includes(method);
    if (!keyed && !numbered || method === "Runtime.callFunctionOn" && params["objectId"]) {
      return { params, document };
    }
    const id = params["contextId"] ?? params["executionContextId"];
    const unique = params["uniqueContextId"];
    const context = [...visible].reverse().find((entry) => {
      if (id !== void 0 && entry["id"] !== id) return false;
      if (unique !== void 0 && entry["uniqueId"] !== unique) return false;
      const aux = isObj3(entry["auxData"]) ? entry["auxData"] : {};
      if (id === void 0 && unique === void 0 && !(aux["isDefault"] && aux["frameId"] === mainFrameId)) return false;
      return this.current(this.contexts.get(entry["id"]), tree);
    });
    if (!context || typeof context["uniqueId"] !== "string") refuse(UNSEEN_CONTEXT);
    document = this.contexts.get(context["id"]);
    const { contextId, executionContextId, uniqueContextId, ...rest } = params;
    return { document, params: keyed ? { ...rest, uniqueContextId: context["uniqueId"] } : { ...rest, executionContextId: context["id"] } };
  }
};
function isObj3(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function str(value) {
  return typeof value === "string" ? value : void 0;
}
function refuse(reason) {
  throw new Error(reason.startsWith("slicc: refused: ") ? reason : `slicc: refused: ${reason}`);
}
function webSocketAsHttp(url) {
  const lower = url.toLowerCase();
  if (lower.startsWith("wss:")) return `https:${url.slice(4)}`;
  if (lower.startsWith("ws:")) return `http:${url.slice(3)}`;
  return url;
}
function urlProtected(text, readOnly = false) {
  if (isProtectedUrl(text, readOnly)) return true;
  const web = webSocketAsHttp(text);
  return web !== text && isProtectedUrl(web, readOnly);
}
var SCHEME = /[a-z0-9+.-]/i;
var LETTER = /[a-z]/i;
var URL_END = /[\s"'<>`\u0000-\u001f]/;
var BOUNDARY = /[\s<>"'`=,;([{]/;
var ANCHORS = /(?:https?|wss?):[\\/]*|[\\/]{2,}/gi;
var ANCHOR = /(?:https?|wss?):|[\\/]{2}/i;
var IGNORED = /[\t\n\r]+/g;
var HAS_IGNORED = /[\t\n\r]/;
var JOINS = /* @__PURE__ */ new Set([",", ";", "(", ")"]);
var URL_CAP = 4096;
var HOST_CAP = 300;
var SEEN_CAP = 4096;
var AUTHORITY_END = /[\\/?#@]/g;
var TAIL = URL_CAP + 64;
var PIECE = 65536;
var NEXT_URL = /^(?:[a-z][a-z0-9+.-]*:)?[\\/]{2,}[^\\/]/i;
var ENCODED_KEYS = ["body", "data", "content", "postData"];
var KEY_COLLISION = "slicc: refused: two keys of this payload reduce to the same protected origin";
var ENCODED = "slicc: refused: an encoded payload names a protected url";
var WEB_SCHEMES = ["https", "http", "wss", "ws"];
var URL_KEYS = ["url", "unreachableUrl", "userTypedURL"];
var TARGETS2 = /* @__PURE__ */ new Set(["location", "content-location", "refresh", "link"]);
var AUTHORITY = /^[a-z][a-z0-9+.-]*:\/\/[^/?#]*/i;
function originOf2(text) {
  try {
    const origin = new URL(text).origin;
    if (origin && origin !== "null") return origin;
  } catch {
  }
  return AUTHORITY.exec(text)?.[0] ?? "about:blank";
}
var judge = (url) => urlProtected(url);
var judgeReadOnly = (url) => urlProtected(url, true);
function normalized(text) {
  if (!HAS_IGNORED.test(text)) return { text, cuts: [], breaks: void 0 };
  const parts = [];
  const cuts = [];
  let length = 0;
  let last = 0;
  IGNORED.lastIndex = 0;
  for (let found = IGNORED.exec(text); found; found = IGNORED.exec(text)) {
    parts.push(text.slice(last, found.index));
    length += found.index - last;
    last = found.index + found[0].length;
    cuts.push([length, last]);
  }
  parts.push(text.slice(last));
  return { text: parts.join(""), cuts, breaks: new Set(cuts.map(([at]) => at)) };
}
function original(n, at) {
  let low = 0;
  let high = n.cuts.length - 1;
  let found;
  while (low <= high) {
    const mid = low + high >> 1;
    const cut = n.cuts[mid];
    if (cut[0] <= at) {
      found = cut;
      low = mid + 1;
    } else {
      high = mid - 1;
    }
  }
  return found === void 0 ? at : found[1] + at - found[0];
}
function originalEnd(n, end) {
  return end === 0 ? 0 : original(n, end - 1) + 1;
}
function schemeStarts(text, colon, breaks) {
  let start = colon;
  while (start > 0 && colon - start < 32 && SCHEME.test(text[start - 1] ?? "")) start -= 1;
  while (start < colon && !LETTER.test(text[start] ?? "")) start += 1;
  if (start === colon) return [];
  const out = [start];
  for (let at = start + 1; at < colon; at += 1) {
    if (breaks?.has(at) && LETTER.test(text[at] ?? "")) out.push(at);
  }
  const scheme2 = text.slice(start, colon).toLowerCase();
  const inner = WEB_SCHEMES.find((w) => scheme2.length > w.length && scheme2.endsWith(w));
  if (inner !== void 0) out.push(colon - inner.length);
  return out;
}
function openings(text, at, anchor, breaks) {
  if (anchor[0] !== "/" && anchor[0] !== "\\") {
    return schemeStarts(text, at + anchor.indexOf(":"), breaks).map((start) => [start, ""]);
  }
  if (text[at - 1] === ":") return schemeStarts(text, at - 1, breaks).map((start) => [start, ""]);
  if (at > 0 && !BOUNDARY.test(text[at - 1] ?? "") && !breaks?.has(at)) return [];
  return [[at, "https:"]];
}
function stopFrom(text, from, breaks) {
  let end = from;
  while (end < text.length && !URL_END.test(text[end] ?? "")) {
    if (end > from && breaks?.has(end) && NEXT_URL.test(text.slice(end, end + 40))) {
      return { at: end, join: false };
    }
    if (JOINS.has(text[end] ?? "") && NEXT_URL.test(text.slice(end + 1, end + 40))) {
      return { at: end, join: true };
    }
    end += 1;
  }
  return { at: end, join: false };
}
function urlEnd(memo, text, from, breaks) {
  if (!(memo.from <= from && from < memo.stop.at)) {
    memo.from = from;
    memo.stop = stopFrom(text, from, breaks);
  }
  const { at, join } = memo.stop;
  return join && text[at - 1] === ")" && at - 1 > from ? at - 1 : at;
}
function authorityEnd(memo, text, from) {
  if (memo.authority < from) {
    memo.ats = [];
    AUTHORITY_END.lastIndex = from;
    let found = AUTHORITY_END.exec(text);
    while (found && found[0] === "@") {
      memo.ats.push(found.index);
      found = AUTHORITY_END.exec(text);
    }
    memo.authority = found?.index ?? text.length;
  }
  return memo.authority;
}
function hostStart(memo, run, end) {
  let low = 0;
  let high = memo.ats.length - 1;
  let found = run - 1;
  while (low <= high) {
    const mid = low + high >> 1;
    const at = memo.ats[mid];
    if (at < end) {
      found = Math.max(found, at);
      low = mid + 1;
    } else {
      high = mid - 1;
    }
  }
  return found + 1;
}
function judgeOnce(memo, url, isProtected) {
  const known = memo.seen.get(url);
  if (known !== void 0) return known;
  const hit = isProtected(url);
  if (memo.seen.size < SEEN_CAP) memo.seen.set(url, hit);
  return hit;
}
function urlAt(memo, text, found, breaks, isProtected) {
  const at = found.index;
  const run = at + found[0].length;
  const next = text[run];
  if (next === void 0 || URL_END.test(next)) return void 0;
  const starts = openings(text, at, found[0], breaks);
  if (starts.length === 0) return void 0;
  const end = urlEnd(memo, text, run, breaks);
  const hostEnd = Math.min(end, authorityEnd(memo, text, run));
  const host = hostStart(memo, run, hostEnd);
  const pending = hostEnd === text.length ? memo.pending : void 0;
  if (pending?.start === -1) {
    pending.start = starts[0][0];
    pending.run = run;
  }
  const long = memo.work > memo.budget && hostEnd - host > HOST_CAP;
  if (long && pending) return void 0;
  for (const [start, prefix] of starts) {
    const scheme2 = prefix + text.slice(start, run).replace(/\\/g, "/");
    memo.work += run - start + hostEnd - host;
    if (!long && !judgeOnce(memo, scheme2 + text.slice(host, hostEnd), isProtected)) continue;
    return { start, end, url: prefix + text.slice(start, end).replace(/\\/g, "/") };
  }
  return void 0;
}
function scan(n, isProtected, pending) {
  const out = [];
  const { text, breaks } = n;
  if (!ANCHOR.test(text)) return out;
  const memo = { from: -1, stop: { at: -1, join: false }, authority: -1, ats: [], pending, work: 0, budget: 4 * text.length + 65536, seen: /* @__PURE__ */ new Map() };
  ANCHORS.lastIndex = 0;
  for (let found = ANCHORS.exec(text); found; found = ANCHORS.exec(text)) {
    const span = urlAt(memo, text, found, breaks, isProtected);
    if (!span) continue;
    out.push(span);
    ANCHORS.lastIndex = Math.max(span.end, ANCHORS.lastIndex);
  }
  return out;
}
function bare(span) {
  const origin = originOf2(span.url);
  return span.url === origin || span.url === `${origin}/` ? void 0 : origin;
}
function redactText(text) {
  const n = normalized(text);
  let out = "";
  let last = 0;
  for (const span of scan(n, judge)) {
    const origin = bare(span);
    if (origin === void 0) continue;
    out += text.slice(last, original(n, span.start)) + origin;
    last = originalEnd(n, span.end);
  }
  return last === 0 ? text : out + text.slice(last);
}
function namesProtectedUrl(text) {
  return typeof text === "string" && scan(normalized(text), judge).length > 0;
}
function tailOf(text) {
  return text.replace(IGNORED, "\n").replace(/[\\/]{3,}/g, "//").slice(-TAIL);
}
function carried(joined, text, pending) {
  if (pending.start === -1 || pending.start >= text.length - TAIL) return tailOf(joined);
  const scheme2 = text.slice(pending.start, pending.run).replace(/[\\/]{3,}/g, "//");
  return scheme2 + text.slice(Math.max(pending.run, text.length - URL_CAP));
}
var UrlStream = class {
  page = true;
  head = "";
  named = false;
  refused = false;
  push(chunk, isProtected = judge) {
    const head = this.head;
    const joined = head + chunk;
    const n = normalized(joined);
    let out = "";
    let last = head.length;
    let open = "";
    const pending = { start: -1, run: -1 };
    for (const span of scan(n, isProtected, pending)) {
      const start = original(n, span.start);
      const end = originalEnd(n, span.end);
      if (end === joined.length && joined.length - start > URL_CAP) open = originOf2(span.url);
      const origin = bare(span);
      if (end <= head.length || origin === void 0) continue;
      this.named = true;
      out += joined.slice(last, Math.max(start, last)) + (start >= head.length ? origin : "");
      last = end;
    }
    this.head = open ? `${open}/` : carried(joined, n.text, pending);
    return last === head.length ? chunk : out + joined.slice(last);
  }
  pushEncoded(encoded) {
    const clean = /[^A-Za-z0-9+/=]/.test(encoded) ? encoded.replace(/[\t\n\f\r ]+/g, "") : encoded;
    for (let at = 0; at < clean.length && !this.named; at += PIECE) {
      let piece;
      try {
        piece = atob(clean.slice(at, at + PIECE));
      } catch {
        this.named = true;
        return;
      }
      this.push(piece, judgeReadOnly);
    }
  }
};
function encodedNamesProtected(encoded) {
  const stream = new UrlStream();
  stream.pushEncoded(encoded);
  return stream.named;
}
function streamRead(stream, result) {
  if (stream.refused) refuse(ENCODED);
  const data = result["data"];
  if (typeof data !== "string") return result;
  if (result["base64Encoded"] !== true) {
    const next = stream.push(data);
    return next === data ? result : { ...result, data: next };
  }
  stream.pushEncoded(data);
  if (!stream.named) return result;
  stream.refused = true;
  refuse(ENCODED);
}
var NetworkStreams = class {
  streams = /* @__PURE__ */ new Map();
  buffer(id, result) {
    if (!this.streams.has(id)) {
      if (!id || this.streams.size >= 500) refuse(ENCODED);
      this.streams.set(id, new UrlStream());
    }
    this.read(id, result["bufferedData"]);
    return result;
  }
  read(id, data) {
    const stream = this.streams.get(id);
    if (!stream) refuse(ENCODED);
    streamRead(stream, { data, base64Encoded: true });
  }
  end(id) {
    this.streams.delete(id);
  }
};
function encodedNamed(value, method) {
  const keys = value["base64Encoded"] === true ? [...ENCODED_KEYS] : [];
  if (method === "Network.dataReceived") keys.push("data");
  if (method === "Network.streamResourceContent") keys.push("bufferedData");
  if (method === "Audits.getEncodedResponse") keys.push("body");
  if ((method === "Network.webSocketFrameReceived" || method === "Network.webSocketFrameSent") && value["opcode"] === 2) keys.push("payloadData");
  return keys.some((key) => {
    const item = value[key];
    return typeof item === "string" && encodedNamesProtected(item);
  });
}
function cleaned(target) {
  return target.replace(/[\t\n\r]/g, "").replace(/^[\u0000-\u0020]+|[\u0000-\u0020]+$/g, "").replace(/^(['"])(.*)\1$/s, "$2");
}
function resolved(target, base2) {
  try {
    return new URL(cleaned(target), base2 || "https://slicc.invalid/").href;
  } catch {
    return "";
  }
}
function targetSpans(name, line) {
  const lower = name.toLowerCase();
  if (lower === "link") {
    return [...line.matchAll(/<([^>]*)>/g)].map((m) => [m.index + 1, m.index + 1 + (m[1] ?? "").length]);
  }
  if (lower !== "refresh") return [[line.length - line.trimStart().length, line.length]];
  const named = /url\s*=\s*/i.exec(line);
  if (named) return [[named.index + named[0].length, line.length]];
  const bare2 = /^[\s\d.]*[;,]\s*/.exec(line);
  return bare2 ? [[bare2[0].length, line.length]] : [];
}
function redactLine(name, line, base2) {
  let out = "";
  let last = 0;
  let hit = false;
  for (const [start, end] of targetSpans(name, line)) {
    const url = resolved(line.slice(start, end), base2);
    if (!url || !urlProtected(url)) continue;
    hit = true;
    out += line.slice(last, start) + originOf2(url);
    last = end;
  }
  return { text: last === 0 ? line : out + line.slice(last), hit };
}
function headerTarget(name, value, base2) {
  if (typeof name !== "string" || typeof value !== "string" || !TARGETS2.has(name.toLowerCase())) {
    return { text: value, hit: false };
  }
  const lines = value.split("\n").map((line) => redactLine(name, line, base2));
  return { text: lines.map((l) => l.text).join("\n"), hit: lines.some((l) => l.hit) };
}
function headerNamed(name, value, base2) {
  return namesProtectedUrl(value) || headerTarget(name, value, base2).hit;
}
function redactHeaders(headers, base2) {
  if (Array.isArray(headers)) {
    let out2 = headers;
    headers.forEach((header, index) => {
      if (!isObj3(header)) return;
      const next = headerTarget(header["name"], header["value"], base2).text;
      if (next === header["value"]) return;
      if (out2 === headers) out2 = [...headers];
      out2[index] = { ...header, value: next };
    });
    return out2;
  }
  if (!isObj3(headers)) return headers;
  let out = headers;
  for (const [name, value] of Object.entries(headers)) {
    const next = headerTarget(name, value, base2).text;
    if (next === value) continue;
    if (out === headers) out = { ...headers };
    out[name] = next;
  }
  return out;
}
function redactHeadersText(text, base2) {
  const parts = text.split(/(\r?\n)/);
  let changed = false;
  const out = parts.map((part) => {
    const found = /^([^:]+):(.*)$/s.exec(part);
    if (!found) return part;
    const name = found[1] ?? "";
    const value = found[2] ?? "";
    const next = headerTarget(name.trim(), value, base2).text;
    if (next === value) return part;
    changed = true;
    return `${name}:${String(next)}`;
  });
  return changed ? out.join("") : text;
}
function urlNamed(text) {
  return typeof text === "string" && text !== "" && urlProtected(text);
}
function withHeaders(value) {
  let out = value;
  const request = value["request"];
  if (Array.isArray(value["responseHeaders"])) {
    const base2 = isObj3(request) ? str(request["url"]) ?? "" : "";
    const next = redactHeaders(value["responseHeaders"], base2);
    if (next !== value["responseHeaders"]) out = { ...out, responseHeaders: next };
  }
  const url = str(value["url"]) ?? "";
  if (isObj3(value["headers"])) {
    const next = redactHeaders(value["headers"], url);
    if (next !== value["headers"]) out = { ...out, headers: next };
  }
  const text = str(value["headersText"]);
  if (text !== void 0) {
    const next = redactHeadersText(text, url);
    if (next !== text) out = { ...out, headersText: next };
  }
  return out;
}
function redactKeys(source) {
  const keys = Object.keys(source);
  const renamed = keys.map((key) => redactText(key));
  if (renamed.every((key, index) => key === keys[index])) return source;
  if (new Set(renamed).size !== renamed.length) throw new Error(KEY_COLLISION);
  return Object.fromEntries(keys.map((key, index) => [renamed[index], source[key]]));
}
function redactProtected(value, method) {
  if (typeof value === "string") return redactText(value);
  if (value === null || typeof value !== "object") return value;
  if (Array.isArray(value)) {
    let out2 = value;
    value.forEach((item, index) => {
      const next = redactProtected(item, method);
      if (next === item) return;
      if (out2 === value) out2 = [...value];
      out2[index] = next;
    });
    return out2;
  }
  const original2 = value;
  if (encodedNamed(original2, method)) refuse(ENCODED);
  const source = redactKeys(withHeaders(original2));
  let out = source;
  for (const [key, item] of Object.entries(source)) {
    const next = redactProtected(item, method);
    if (next === item) continue;
    if (out === source) out = { ...source };
    out[key] = next;
  }
  if (method === "Page.getFrameTree" && ["url", "securityOrigin", "unreachableUrl"].some((key) => urlNamed(original2[key]))) {
    out = { ...out };
    delete out["name"];
    delete out["urlFragment"];
  }
  if ("urlFragment" in original2 && URL_KEYS.some((k) => urlNamed(original2[k]))) {
    if (out === original2) out = { ...original2 };
    delete out["urlFragment"];
  }
  return out;
}
function headersNameProtected(headers, base2 = "") {
  if (Array.isArray(headers)) {
    return headers.some((header) => isObj3(header) && headerNamed(header["name"], header["value"], base2));
  }
  if (!isObj3(headers)) return false;
  return Object.entries(headers).some(([name, value]) => headerNamed(name, value, base2));
}
function responseNamesProtected(method, params) {
  const response = params["response"];
  const redirect = params["redirectResponse"];
  if (isObj3(response) && headersNameProtected(response["headers"], str(response["url"]))) {
    return true;
  }
  if (isObj3(redirect) && headersNameProtected(redirect["headers"], str(redirect["url"]))) {
    return true;
  }
  if (!method.endsWith("responseReceivedExtraInfo")) return false;
  const text = str(params["headersText"]) ?? "";
  return headersNameProtected(params["headers"]) || namesProtectedUrl(text) || redactHeadersText(text, "") !== text;
}
function binaryHeadersNameProtected(binary) {
  if (typeof binary !== "string" || binary === "") return false;
  try {
    return namesProtectedUrl(atob(binary));
  } catch {
    return true;
  }
}
function answerNamesProtected(params, base2) {
  return headersNameProtected(params["responseHeaders"], base2) || headersNameProtected(params["headers"], base2) || binaryHeadersNameProtected(params["binaryResponseHeaders"]);
}
function treeNamesProtected(tree, errorOnly = false) {
  const pending = [tree];
  while (pending.length > 0) {
    const node = pending.pop();
    if (!isObj3(node)) continue;
    const frame = isObj3(node["frame"]) ? node["frame"] : {};
    for (const key of errorOnly ? ["unreachableUrl"] : ["url", "unreachableUrl"]) {
      const url = str(frame[key]);
      if (url && urlProtected(url)) return true;
    }
    if (Array.isArray(node["childFrames"])) pending.push(...node["childFrames"]);
  }
  return false;
}
var DISCOVERY_EVENTS = /* @__PURE__ */ new Set(["Target.targetCreated", "Target.targetInfoChanged", "Target.targetDestroyed", "Target.targetCrashed"]);
var ERROR_PAGE_READS = /* @__PURE__ */ new Set(["Page.captureSnapshot", "Page.getResourceContent", "Page.searchInResource"]);
function mentions(value) {
  if (typeof value === "string") return value.includes("://") && urlProtected(value, true);
  if (Array.isArray(value)) return value.some(mentions);
  if (isObj3(value)) return Object.values(value).some(mentions);
  return false;
}
function storageEntryProtected(key, item) {
  if (FREE_FORM.has(key)) return false;
  if (typeof item !== "string") return namesProtectedStorage(item);
  if (ORIGIN_KEYS.has(key) && urlProtected(item, true)) return true;
  if (key === "storageKey") return isProtectedStorageKey(item);
  if (key === "cacheId") return isProtectedStorageKey(item.split("|")[0] ?? "");
  return false;
}
function namesProtectedStorage(value) {
  if (Array.isArray(value)) return value.some(namesProtectedStorage);
  if (!isObj3(value)) return false;
  return Object.entries(value).some(([key, item]) => storageEntryProtected(key, item));
}
function hostOf2(text) {
  try {
    return new URL(text).hostname || void 0;
  } catch {
    return void 0;
  }
}
function siteProtected(site) {
  if (urlProtected(site)) return true;
  const host = hostOf2(site);
  return host !== void 0 && isProtectedCookieDomain(host);
}
function cookieProtected(cookie) {
  if (!isObj3(cookie)) return false;
  const domain = str(cookie["domain"]);
  if (domain && isProtectedCookieDomain(domain)) return true;
  const url = str(cookie["url"]);
  if (url && siteProtected(url)) return true;
  const partition = cookie["partitionKey"];
  if (typeof partition === "string") return siteProtected(partition);
  const top = isObj3(partition) ? str(partition["topLevelSite"]) : void 0;
  return top !== void 0 && siteProtected(top);
}
function cookieRefused(params) {
  const cookies = params["cookies"];
  if (Array.isArray(cookies)) return cookies.some(cookieProtected);
  return cookieProtected(params);
}
function cookieUrlUnparseable(params) {
  const urls = params["urls"];
  const cookies = params["cookies"];
  return [...Array.isArray(urls) ? urls : [], params["url"], ...Array.isArray(cookies) ? cookies.map((c) => isObj3(c) ? c["url"] : void 0) : []].some((url) => typeof url === "string" && isUnparseableUrl(url));
}
function dropProtectedCookies(result) {
  const cookies = result["cookies"];
  if (Array.isArray(cookies)) result["cookies"] = cookies.filter((c) => !cookieProtected(c));
}
function stripProtectedAssociated(params) {
  const cookies = params["associatedCookies"];
  if (!Array.isArray(cookies)) return;
  params["associatedCookies"] = cookies.filter((item) => !(isObj3(item) && cookieProtected(item["cookie"])));
}
var SET_COOKIE = /^set-cookie$/i;
var CACHED = ["fromDiskCache", "fromServiceWorker", "fromPrefetchCache", "fromEarlyHints"];
function headerValue(headers, name) {
  if (!isObj3(headers)) return void 0;
  const key = Object.keys(headers).find((k) => k.toLowerCase() === name);
  return key === void 0 ? void 0 : String(headers[key]);
}
function hopOf(redirect) {
  if (CACHED.some((key) => redirect[key] === true)) return "done";
  return { status: redirect["status"], location: headerValue(redirect["headers"], "location") };
}
function hopMatches(hop, params) {
  if (hop === void 0 || hop === "done") return false;
  return params["statusCode"] === hop.status && headerValue(params["headers"], "location") === hop.location;
}
function stripCookie(headers) {
  if (!isObj3(headers)) return;
  for (const key of Object.keys(headers)) if (/^cookie$/i.test(key)) delete headers[key];
}
function stripSetCookie(params) {
  const headers = params["headers"];
  if (isObj3(headers)) {
    for (const key of Object.keys(headers)) if (SET_COOKIE.test(key)) delete headers[key];
  }
  const text = params["headersText"];
  if (typeof text !== "string") return;
  const out = [];
  let dropping = false;
  for (const line of text.split(/(?<=\n)/)) {
    if (/^set-cookie\s*:/i.test(line)) dropping = true;
    else if (!/^[ \t]/.test(line)) dropping = false;
    if (!dropping) out.push(line);
  }
  params["headersText"] = out.join("");
}
function redacted(info) {
  let origin = "about:blank";
  try {
    const parsed2 = new URL(str(info["url"]) ?? "");
    if (parsed2.origin !== "null") origin = parsed2.origin;
  } catch {
  }
  return { ...info, url: origin, title: origin };
}
function redactHistory(result) {
  const entries = result["entries"];
  if (!Array.isArray(entries)) return;
  result["entries"] = entries.map((entry) => {
    if (!isObj3(entry)) return entry;
    const url = str(entry["url"]) ?? "";
    const typed = str(entry["userTypedURL"]) ?? "";
    if (!urlProtected(url) && !urlProtected(typed)) return entry;
    const origin = str(redacted({ url: urlProtected(url) ? url : typed })["url"]) ?? "about:blank";
    return { ...entry, url: origin, userTypedURL: origin, title: origin };
  });
}
function requestUrl(params) {
  const request = params["request"];
  const response = params["response"];
  return (isObj3(request) ? str(request["url"]) : void 0) ?? (isObj3(response) ? str(response["url"]) : void 0) ?? str(params["url"]);
}
function requestKey(params) {
  return str(params?.["requestId"]) ?? str(params?.["interceptionId"]);
}
function initScriptGuard() {
  const rules = JSON.stringify({ s: PROTECTED_RULES.schemes, h: PROTECTED_RULES.hosts, d: PROTECTED_RULES.domains, p: PROTECTED_RULES.protectedSchemes, x: PROTECTED_RULES.schemeExceptions });
  const refusal = JSON.stringify(PROTECTED_RULES.refusal);
  return `if((function(r,o){function q(s,h){return r.p.indexOf(s)>=0&&r.x.indexOf(s+'://'+h)<0}var l=self.location;if(l&&q(l.protocol.slice(0,-1),l.hostname.toLowerCase()))return true;try{var u=new URL(o),h=u.hostname.toLowerCase().replace(/\\.$/,''),s=u.protocol.slice(0,-1);return q(s,h)||r.s.indexOf(s)>=0&&(r.h.indexOf(h)>=0||r.d.some(function(d){return h===d||h.slice(-d.length-1)==='.'+d}))}catch(e){return false}})(${rules},self.origin))throw new Error(${refusal});
`;
}
function wildcard(pattern, text) {
  let re = "";
  for (let i = 0; i < pattern.length; i += 1) {
    const c = pattern[i] ?? "";
    if (c === "\\" && i + 1 < pattern.length) {
      i += 1;
      re += (pattern[i] ?? "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    } else if (c === "*") re += ".*";
    else if (c === "?") re += ".";
    else re += c.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  return new RegExp(`^${re}$`, "s").test(text);
}
function patternMatches(pattern, paused) {
  if (!isObj3(pattern)) return false;
  const stage = "responseStatusCode" in paused || "responseErrorReason" in paused ? "Response" : "Request";
  if ((str(pattern["requestStage"]) ?? "Request") !== stage) return false;
  const type = str(pattern["resourceType"]);
  if (type !== void 0 && type !== str(paused["resourceType"])) return false;
  return wildcard(str(pattern["urlPattern"]) ?? "*", requestUrl(paused) ?? "");
}
var Bounded = class {
  constructor(limit) {
    this.limit = limit;
  }
  limit;
  map = /* @__PURE__ */ new Map();
  get(key) {
    return this.map.get(key);
  }
  has(key) {
    return this.map.has(key);
  }
  set(key, value) {
    this.map.delete(key);
    this.map.set(key, value);
    if (this.map.size > this.limit) {
      const oldest = this.map.keys().next().value;
      if (oldest !== void 0) this.map.delete(oldest);
    }
  }
  delete(key) {
    const value = this.map.get(key);
    this.map.delete(key);
    return value;
  }
  clear() {
    this.map.clear();
  }
};
function shieldProbe(work) {
  let timer;
  const late = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(PROTECTED_RULES.refusal)), 2e3);
  });
  return Promise.race([work, late]).finally(() => clearTimeout(timer));
}
var TabShield = class {
  constructor(send3, onBlocked, failedDocuments = new Bounded(200), readTab = async () => void 0, lookupTab = async () => void 0, readFrames = async () => void 0) {
    this.send = send3;
    this.onBlocked = onBlocked;
    this.failedDocuments = failedDocuments;
    this.readTab = readTab;
    this.lookupTab = lookupTab;
    this.readFrames = readFrames;
    this.wake = new Wake(send3);
  }
  send;
  onBlocked;
  failedDocuments;
  readTab;
  lookupTab;
  readFrames;
  requests = new Bounded(5e3);
  held = new Bounded(500);
  settled = new Bounded(5e3);
  frames = new Bounded(1e3);
  forwarded = new Bounded(2e3);
  pausedUrls = new Bounded(2e3);
  bodyReads = new Bounded(2e3);
  streams = new Bounded(500);
  networkStreams = new NetworkStreams();
  hiddenFrames = new Bounded(1e3);
  uncertainFrames = new Bounded(1e3);
  namedBodies = new Bounded(2e3);
  hops = new Bounded(500);
  reroutes = /* @__PURE__ */ new Map();
  worlds = new Worlds();
  documents = new DocumentBindings();
  pendingFrames = /* @__PURE__ */ new Set();
  startedFrames = /* @__PURE__ */ new Set();
  pageObserved = false;
  clientFetch = null;
  seal;
  cut = /* @__PURE__ */ new Set();
  mainFrameId = "";
  blockedFlag = false;
  epoch = 0;
  content;
  wake;
  get blocked() {
    return this.blockedFlag;
  }
  invalidate() {
    this.epoch += 1;
  }
  readyPromise = null;
  install() {
    if (!this.readyPromise) this.readyPromise = this.arm();
    return this.readyPromise;
  }
  async arm() {
    await this.send("Fetch.enable", this.fetchParams());
    await this.send("Network.setBypassServiceWorker", { bypass: true });
    await this.inventoryFrames();
    await this.send("Runtime.enable", {});
    this.pageObserved = await shieldProbe(this.send("Page.enable", {}).then(() => this.send("Page.setLifecycleEventsEnabled", { enabled: true }))).then(() => true, () => false);
  }
  async inventoryFrames() {
    const tree = await this.send("Page.getFrameTree", {});
    const root = tree["frameTree"];
    this.documents.remember(root);
    const main = isObj3(root) && isObj3(root["frame"]) ? str(root["frame"]["id"]) : void 0;
    if (!main) refuse(PROTECTED_RULES.refusal);
    this.mainFrameId = main;
    const pending = [root];
    while (pending.length > 0) {
      const node = pending.pop();
      if (!isObj3(node)) continue;
      const frame = isObj3(node["frame"]) ? node["frame"] : {};
      const url = `${str(frame["url"]) ?? ""}${str(frame["urlFragment"]) ?? ""}`;
      const origin = str(frame["securityOrigin"]) ?? "";
      const id = str(frame["id"]);
      if (id) this.frames.set(id, [url, origin]);
      if (id && id !== main && (extensionOrigin(url) || extensionOrigin(origin))) {
        this.hiddenFrames.set(id, true);
        continue;
      }
      if (urlProtected(url) || urlProtected(origin)) refuse(PROTECTED_RULES.refusal);
      if (await this.inheritedProtected(frame)) refuse(PROTECTED_RULES.refusal);
      if (Array.isArray(node["childFrames"])) pending.push(...node["childFrames"]);
    }
  }
  inputGate(method) {
    if (method.startsWith("Input.") && (!this.pageObserved || this.pendingFrames.size > 0)) refuse(UNSETTLED_REFUSAL);
  }
  fetchParams() {
    const client = this.clientFetch;
    const patterns = client ? client.patterns : [];
    return { patterns: [GUARD_FETCH_PATTERN, ...patterns], handleAuthRequests: client?.handleAuthRequests === true };
  }
  block() {
    if (this.blockedFlag) return;
    this.blockedFlag = true;
    this.onBlocked();
  }
  async command(method, params, forward) {
    const input = method === "Runtime.addBinding" ? scopedBinding(params ?? {}) : params ?? {};
    if (this.blockedFlag) refuse(PROTECTED_RULES.refusal);
    await this.gate(method, input);
    await this.admit(method, input);
    if (["Runtime.enable", "Runtime.disable", "Page.enable", "Page.disable", "Page.setLifecycleEventsEnabled"].includes(method)) return {};
    const about = method === "Page.navigate" ? aboutUrl(input["url"]) : void 0;
    if (about) return this.openBlank(input, about);
    const rewritten = this.rewrite(method, input);
    if (rewritten === null) return {};
    const settles = FETCH_SETTLES.has(method);
    const pauseId = String(input["requestId"]);
    let read;
    if (settles) {
      if (!this.forwarded.has(pauseId)) refuse(PAUSE_REFUSAL);
      this.forwarded.delete(pauseId);
      read = this.bodyReads.delete(pauseId);
    }
    const reroute = this.pendingReroute(method, input, pauseId);
    const seal = await this.sealFor(method, input);
    const binding = await this.bind(method, rewritten);
    await this.gate(method, input);
    this.inputGate(method);
    let result;
    try {
      result = await this.wake.command(method, params === void 0 && binding.params === input ? void 0 : binding.params, forward);
    } catch (err) {
      this.reroutes.delete(pauseId);
      const dropped = settles && /Invalid InterceptionId|not found|No such request/i.test(String(err));
      if (dropped) refuse(PAUSE_REFUSAL);
      if (settles) {
        this.forwarded.set(pauseId, true);
        if (read !== void 0) this.bodyReads.set(pauseId, read);
      }
      throw err;
    }
    if (reroute !== void 0) await this.settleReroute(pauseId, reroute);
    if (this.blockedFlag) refuse(PROTECTED_RULES.refusal);
    await this.checkReturn(method, input);
    const opened = await this.after(method, await this.unseal(seal, method, result ?? {}), input);
    await this.checkReturn(method, input);
    this.documents.learn(opened, binding.document);
    return opened;
  }
  frameHidden(frame) {
    const origin = frame["securityOrigin"];
    if (this.frameProtected(str(frame["id"]) ?? "") || unknownFrame(frame)) return true;
    if (extensionOrigin(frame["url"]) || extensionOrigin(origin)) return true;
    return [origin, frame["url"], frame["unreachableUrl"]].some((url) => typeof url === "string" && url !== "" && urlProtected(url));
  }
  async sealFor(method, params) {
    if (!sealedRead(method)) return void 0;
    const tree = await this.send("Page.getFrameTree", {}).catch(() => refuse(PROTECTED_RULES.refusal));
    await resolveFrameOrigins(tree["frameTree"], this.uncertainFrames, (id) => this.documentOrigin(id));
    const frames = frameSets(tree["frameTree"], (frame) => this.frameHidden(frame));
    if (frames.visible.size === 0) refuse(PROTECTED_RULES.refusal);
    const seal = { ...frames, nodes: /* @__PURE__ */ new Set() };
    this.seal = seal;
    if (frames.sealed.size === 0) return seal;
    const frameId = params["frameId"];
    if (typeof frameId === "string" && !frames.visible.has(frameId)) {
      refuse(PROTECTED_RULES.refusal);
    }
    if (method === "DOMSnapshot.captureSnapshot") return seal;
    const snapshot = await this.send("DOMSnapshot.captureSnapshot", { computedStyles: [] }).catch(() => refuse(PROTECTED_RULES.refusal));
    seal.nodes = sealedNodes(snapshot, frames.visible);
    if (seal.nodes.size === 0) return seal;
    if (wholePage(method)) refuse(PROTECTED_RULES.refusal);
    const { backend, dom, objects } = nodeSelectors(params);
    const ids = [...backend];
    for (const nodeId of dom) ids.push(await this.backendOf({ nodeId }, true));
    for (const objectId of objects) ids.push(await this.backendOf({ objectId }, false));
    if (ids.some((id) => seal.nodes.has(id))) refuse(PROTECTED_RULES.refusal);
    return seal;
  }
  async backendOf(params, strict) {
    try {
      const answer = await this.send("DOM.describeNode", params);
      return isObj3(answer["node"]) ? answer["node"]["backendNodeId"] : void 0;
    } catch (error) {
      if (strict) throw error;
      return void 0;
    }
  }
  async unseal(seal, method, result) {
    if (!seal) return result;
    if (method === "DOMSnapshot.captureSnapshot") return pruneSnapshot(result, seal.visible);
    if (seal.sealed.size === 0) return result;
    this.cutNodes(pruneSealed(result, seal));
    if (seal.nodes.size === 0) return result;
    if (seal.nodes.has(result["backendNodeId"]) || seal.sealed.has(str(result["frameId"]) ?? "")) {
      refuse(PROTECTED_RULES.refusal);
    }
    const nodeId = result["nodeId"];
    if (typeof nodeId === "number" && seal.nodes.has(await this.backendOf({ nodeId }, false))) {
      refuse(PROTECTED_RULES.refusal);
    }
    if (Array.isArray(result["nodeIds"])) {
      const kept = [];
      for (const id of result["nodeIds"]) {
        if (!seal.nodes.has(await this.backendOf({ nodeId: id }, false))) kept.push(id);
      }
      result["nodeIds"] = kept;
    }
    return result;
  }
  cutNodes(ids) {
    for (const id of ids) this.cut.add(id);
    while (this.cut.size > 1e5) this.cut.delete(this.cut.values().next().value);
  }
  async sealEvent(method, params) {
    if (method === "DOM.documentUpdated") {
      this.cut.clear();
      return true;
    }
    try {
      await this.sealFor(method, { ...params, nodeId: params["nodeId"] ?? params["parentId"] ?? params["parentNodeId"] ?? params["hostId"] ?? params["insertionPointId"] });
    } catch {
      return false;
    }
    if (sealedEvent(params, this.cut)) {
      this.cutNodes(boundIds(params));
      return false;
    }
    const last = this.seal;
    const seal = { nodes: last?.nodes ?? /* @__PURE__ */ new Set(), sealed: { has: (id) => this.frameProtected(str(id) ?? "") || last?.sealed.has(str(id) ?? "") === true }, visible: { has: (id) => {
      const frame = str(id) ?? "";
      if (!frame || this.frameProtected(frame)) return false;
      return this.frames.has(frame) || last?.visible.has(frame) === true;
    } } };
    try {
      this.cutNodes(pruneSealed(params, seal));
    } catch {
      return false;
    }
    return true;
  }
  pendingReroute(method, params, id) {
    if (method !== "Fetch.continueRequest" || params["url"] === void 0) return void 0;
    return new Promise((resolve) => this.reroutes.set(id, resolve));
  }
  async settleReroute(id, reroute) {
    const late = new Promise((resolve) => setTimeout(resolve, 1e4, true));
    const allowed = await Promise.race([reroute, late]);
    this.reroutes.delete(id);
    if (!allowed) refuse(REROUTE_REFUSAL);
  }
  rerouted(paused, id) {
    const waiting = this.reroutes.get(id);
    const settled = paused["responseStatusCode"] !== void 0 || paused["responseErrorReason"] !== void 0;
    if (!waiting || !settled) return false;
    this.reroutes.delete(id);
    const url = requestUrl(paused) ?? "";
    const named = urlProtected(url) || headersNameProtected(paused["responseHeaders"], url);
    waiting(!named);
    if (!named) return false;
    const networkId = str(paused["networkId"]);
    if (networkId) this.requests.set(networkId, true);
    this.answer("Fetch.failRequest", { requestId: id, errorReason: "BlockedByClient" });
    return true;
  }
  visibleContexts() {
    return this.worlds.visible();
  }
  async frameOf(frameId) {
    const tree = await this.send("Page.getFrameTree", {});
    return frameIn(tree["frameTree"], frameId);
  }
  async documentOrigin(frameId) {
    const world = await this.send("Page.createIsolatedWorld", { frameId, worldName: ABOUT_WORLD });
    const answer = await this.send("Runtime.evaluate", { expression: "self.origin", contextId: world["executionContextId"], returnByValue: true });
    const result = answer["result"];
    const origin = isObj3(result) ? str(result["value"]) : void 0;
    if (answer["exceptionDetails"] !== void 0 || origin === void 0) {
      throw new Error("no origin");
    }
    return origin;
  }
  async inheritedProtected(frame) {
    const frameId = str(frame["id"]) ?? "";
    let current = frame;
    for (let attempt = 0; attempt < 5; attempt += 1) {
      const url = str(current["url"]) ?? "";
      if (urlProtected(url) || urlProtected(str(current["securityOrigin"]) ?? "")) return true;
      if (url !== "" && !url.startsWith("about:")) return false;
      try {
        return urlProtected(await this.documentOrigin(frameId));
      } catch {
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
      current = await this.frameOf(frameId).catch(() => void 0);
      if (!current) return true;
    }
    return true;
  }
  async openBlank(params, about) {
    if (about.pathname !== "blank") refuse(ABOUT_OTHER);
    const url = about.href;
    const before = await this.frameOf(str(params["frameId"]));
    if (!before) throw new Error("No frame with given id found");
    const frameId = str(before["id"]) ?? "";
    const world = await this.send("Page.createIsolatedWorld", { frameId, worldName: ABOUT_WORLD });
    const ran = await this.send("Runtime.evaluate", { expression: `location.assign(${JSON.stringify(url)})`, contextId: world["executionContextId"] });
    if (ran["exceptionDetails"] !== void 0) refuse(ABOUT_STUCK);
    const current = `${str(before["url"]) ?? ""}${str(before["urlFragment"]) ?? ""}`;
    if (sameDocument(current, url)) return { frameId };
    const deadline = Date.now() + 1e4;
    while (Date.now() < deadline) {
      await new Promise((resolve) => setTimeout(resolve, 50));
      const now = await this.frameOf(frameId);
      if (!now || now["loaderId"] === before["loaderId"]) continue;
      if (this.blockedFlag || urlProtected(str(now["securityOrigin"]) ?? "") || await this.inheritedProtected(now)) {
        refuse(PROTECTED_RULES.refusal);
      }
      return { frameId, loaderId: now["loaderId"], isDownload: false };
    }
    refuse(ABOUT_STUCK);
  }
  async prove(tree) {
    for (const context of this.worlds.bindingContexts()) {
      const unique = str(context["uniqueId"]);
      const frame = this.documents.frameOf(context, tree);
      const current = this.documents.current(this.documents.contexts.get(context["id"]), tree);
      if (unique === void 0 || this.documents.proven.has(unique) && current || !frame || urlProtected(str(frame["url"]) ?? "") || urlProtected(str(frame["securityOrigin"]) ?? "")) continue;
      if (!current && context["origin"] !== frame["securityOrigin"] && frame["url"] !== ERROR_PAGE) continue;
      let answer;
      try {
        answer = await shieldProbe(this.send("Runtime.evaluate", { expression: "({})", uniqueContextId: unique, objectGroup: "slicc:document-binding" }));
      } catch (error) {
        if (!current) continue;
        throw error;
      }
      if (!current) {
        const checked = await shieldProbe(this.send("Page.getFrameTree", {}));
        if (frameIn(checked["frameTree"], str(frame["id"]))?.["loaderId"] !== frame["loaderId"]) continue;
        this.documents.frame(frame);
        this.documents.context(context);
      }
      const remote = isObj3(answer["result"]) ? answer["result"] : {};
      const objectId = remote["objectId"];
      if (!this.documents.proof(context, objectId)) refuse(UNSEEN_CONTEXT);
      void this.send("Runtime.releaseObject", { objectId }).catch(() => void 0);
    }
  }
  async bind(method, params) {
    if (method.startsWith("Input.") && (!this.pageObserved || this.pendingFrames.size > 0)) refuse(UNSETTLED_REFUSAL);
    if (!sealedRead(method) && !method.startsWith("Runtime.")) return { params, document: void 0 };
    const tree = await shieldProbe(this.send("Page.getFrameTree", {})).catch(() => refuse(UNSETTLED_REFUSAL));
    const root = frameIn(tree["frameTree"], void 0);
    if (urlProtected(str(root?.["url"]) ?? "") || urlProtected(str(root?.["securityOrigin"]) ?? "")) refuse(PROTECTED_RULES.refusal);
    await this.prove(tree["frameTree"]);
    return this.documents.bind(method, params, this.worlds.bindingContexts(), tree["frameTree"], str(root?.["id"]) ?? this.mainFrameId);
  }
  retryReady() {
    return !this.blockedFlag && this.frames.get(this.mainFrameId)?.[0] !== ERROR_PAGE && this.pendingFrames.size === 0 && this.startedFrames.size === 0;
  }
  commitMismatch(tab, historyUrl) {
    const committed = this.frames.get(this.mainFrameId)?.[0];
    if (committed === tab.url && isProtectedUrl(tab.url)) return false;
    const pending = historyUrl || tab.pendingUrl;
    return Boolean(committed && (committed !== tab.url || pending && committed !== pending));
  }
  async retryShown(error) {
    const deadline = Date.now() + 250;
    const check = () => {
      if (!this.retryReady() || Date.now() >= deadline) throw error;
    };
    const work = async () => {
      for (; ; ) {
        check();
        await new Promise((resolve) => setTimeout(resolve, Math.min(10, deadline - Date.now())));
        check();
        const fresh = await this.readLive();
        check();
        let historyUrl;
        try {
          this.refuseShown(fresh, await this.openerState(fresh));
          await this.protectedHistory((url) => {
            historyUrl = url;
          });
          check();
          return fresh;
        } catch (next) {
          if (!(next instanceof Error) || next.message !== PROTECTED_RULES.refusal) throw error;
          if (!this.commitMismatch(fresh, historyUrl)) throw error;
        }
      }
    };
    let timer;
    try {
      return await Promise.race([work(), new Promise((_, reject) => {
        timer = setTimeout(() => reject(error), 250);
      })]);
    } finally {
      clearTimeout(timer);
    }
  }
  async gate(method, params) {
    if (BROWSER_LEVEL.has(method)) return;
    if (FETCH_SETTLES.has(method)) {
      this.admitSettle(params);
      return;
    }
    let tab = await this.readLive();
    const confirmed = await this.confirmedError(tab);
    let historyUrl;
    try {
      this.refuseShown(confirmed ? this.failedView(tab) : tab, await this.openerState(tab));
      if (method.startsWith("Input.") && tab.status === "loading") refuse(UNSETTLED_REFUSAL);
      if (tab.status === "loading" && !confirmed) {
        await this.protectedHistory((url) => {
          historyUrl = url;
        });
      }
    } catch (error) {
      if (!(error instanceof Error) || error.message !== PROTECTED_RULES.refusal) throw error;
      if (confirmed || !this.retryReady() || !this.commitMismatch(tab, historyUrl)) throw error;
      tab = await this.retryShown(error);
      if (method.startsWith("Input.") && tab.status === "loading") refuse(UNSETTLED_REFUSAL);
    }
  }
  async readLive() {
    let tab;
    try {
      tab = await this.readTab();
    } catch {
      refuse(PROTECTED_RULES.refusal);
    }
    if (!tab) refuse(PROTECTED_RULES.refusal);
    return tab;
  }
  async openerState(tab) {
    if (typeof tab.openerTabId !== "number") return void 0;
    try {
      const opener = await this.lookupTab(tab.openerTabId);
      if (!opener) return "unknown";
      const openerUrl = isProtectedTarget(opener.url ?? "", false, "unknown");
      const openerPending = isProtectedUrl(opener.pendingUrl);
      return openerUrl || openerPending ? "protected" : "unprotected";
    } catch {
      return "unknown";
    }
  }
  failedAt(url) {
    if (!url) return false;
    return this.failedDocuments.has(unfragmented(url));
  }
  failedView(tab) {
    if (!this.failedAt(tab.url ?? "")) return tab;
    const pendingUrl = this.failedAt(tab.pendingUrl ?? "") ? "" : tab.pendingUrl;
    return { ...tab, url: ERROR_PAGE, title: "", pendingUrl };
  }
  refuseShown(tab, opener) {
    const url = tab.url ?? "";
    const pending = tab.pendingUrl ?? "";
    if (pending !== "" && pending !== url && isProtectedUrl(pending)) refuse(PROTECTED_RULES.refusal);
    if (isProtectedUrl(url) || isProtectedTarget(url, false, opener)) refuse(PROTECTED_RULES.refusal);
  }
  admitSettle(params) {
    const stored = this.pausedUrls.get(str(params?.["requestId"]) ?? "") ?? "";
    if (stored !== "" && urlProtected(stored)) refuse(PROTECTED_RULES.refusal);
    const next = str(params?.["url"]);
    if (next !== void 0 && urlProtected(next)) refuse(PROTECTED_RULES.refusal);
  }
  async confirmedError(tab) {
    const url = tab.url ?? "";
    if (!this.failedAt(url)) return false;
    const tree = await shieldProbe(this.send("Page.getFrameTree", {})).catch(() => void 0);
    const root = tree?.["frameTree"];
    const frame = isObj3(root) && isObj3(root["frame"]) ? root["frame"] : void 0;
    if (!isObj3(frame) || str(frame["url"]) !== ERROR_PAGE) return false;
    const unreachable = str(frame["unreachableUrl"]);
    return unreachable !== void 0 && unfragmented(unreachable) === unfragmented(url);
  }
  async protectedHistory(onRefused) {
    const history = await this.send("Page.getNavigationHistory", {}).catch(() => refuse(UNSETTLED_REFUSAL));
    const entries = Array.isArray(history["entries"]) ? history["entries"] : [];
    const index = history["currentIndex"];
    const entry = typeof index === "number" ? entries[index] : void 0;
    if (!isObj3(entry) || typeof entry["url"] !== "string" || !entry["url"]) refuse(UNSETTLED_REFUSAL);
    if (urlProtected(entry["url"])) {
      onRefused?.(entry["url"]);
      refuse(PROTECTED_RULES.refusal);
    }
  }
  async checkContent(method, params = {}) {
    if (method === "Page.getFrameTree" && await this.confirmedError(await this.readLive())) return;
    if (method === "IO.read" && this.streams.get(str(params["handle"]) ?? "")?.page === false) return;
    const reads = errorPageRead(method);
    const frameId = str(params["frameId"]);
    if (!reads && frameId === void 0) return;
    const tree = reads && !method.startsWith("Runtime.") ? await this.witnessed(frameId) : await this.contentTree();
    if (frameId !== void 0 && !frameIn(tree.frameTree, frameId)) refuse(PROTECTED_RULES.refusal);
    if (reads && tree.sealed) refuse(PROTECTED_RULES.refusal);
  }
  async witnessed(frameId) {
    const epoch = this.epoch;
    const frames = await this.contentFrames();
    const key = framesKey(frames);
    const cached = this.content;
    if (key !== void 0 && cached?.key === key && cached.epoch === this.epoch && (frameId === void 0 || frameIn(cached.frameTree, frameId))) return cached;
    const tree = await this.contentTree();
    if (key !== void 0) {
      const confirmed = framesKey(await this.contentFrames());
      if (confirmed === key && epoch === this.epoch) this.content = { ...tree, key, epoch };
    }
    return tree;
  }
  async contentFrames() {
    const read = await shieldProbe(Promise.resolve().then(() => this.readFrames()).then((frames2) => ({ frames: frames2 }))).catch(() => refuse(UNSETTLED_REFUSAL));
    const frames = read["frames"];
    if (!Array.isArray(frames) || frames.length === 0) refuse(UNSETTLED_REFUSAL);
    if (frames.some((frame) => isObj3(frame) && frame["errorOccurred"] === true && urlProtected(str(frame["url"]) ?? ""))) refuse(PROTECTED_RULES.refusal);
    return frames;
  }
  async contentTree() {
    const tree = await shieldProbe(this.send("Page.getFrameTree", {})).catch(() => refuse(UNSETTLED_REFUSAL));
    const root = frameIn(tree["frameTree"], void 0);
    const url = str(root?.["url"]);
    const origin = str(root?.["securityOrigin"]);
    if (!root || !str(root["id"]) || !url || origin === void 0) refuse(UNSETTLED_REFUSAL);
    return { frameTree: tree["frameTree"], sealed: urlProtected(url) || urlProtected(origin) || treeNamesProtected(tree["frameTree"], true) };
  }
  async checkReturn(method, params) {
    if (this.blockedFlag) refuse(PROTECTED_RULES.refusal);
    await this.checkContent(method, params);
    if (contentResult(method) && !FETCH_SETTLES.has(method)) await this.committed();
  }
  async committed() {
    const tab = await this.readLive();
    if (await this.confirmedError(tab)) {
      this.refuseShown(this.failedView(tab), await this.openerState(tab));
      return;
    }
    let historyUrl;
    try {
      this.refuseShown(tab, await this.openerState(tab));
      const url = tab.url ?? "";
      if (PROTECTED_RULES.innerSchemes.some((scheme2) => url.startsWith(`${scheme2}:`))) return;
      if (tab.pendingUrl && tab.pendingUrl !== url) return;
      await this.protectedHistory((url2) => {
        historyUrl = url2;
      });
    } catch (error) {
      if (!(error instanceof Error) || error.message !== PROTECTED_RULES.refusal) throw error;
      if (!this.retryReady() || !this.commitMismatch(tab, historyUrl)) throw error;
      await this.retryShown(error);
    }
  }
  async admit(method, params) {
    const outright = REFUSED_METHODS.get(method);
    if (outright) refuse(outright);
    this.admitBrowserWide(method, params);
    this.admitUrls(method, params);
    if (namesProtectedStorage(params)) refuse(PROTECTED_RULES.refusal);
    this.admitFrame(params);
    this.admitWorlds(method, params);
    this.admitRequestIds(method, params);
    if (method === "Page.navigateToHistoryEntry") await this.admitHistory(params);
    await this.checkContent(method, params);
    if (ERROR_PAGE_READS.has(method)) {
      const tree = await this.send("Page.getFrameTree", {});
      if (treeNamesProtected(tree["frameTree"])) refuse(PROTECTED_RULES.refusal);
    }
  }
  admitBrowserWide(method, params) {
    if ((method === "Browser.setPermission" || method === "Browser.grantPermissions") && !str(params["origin"])) {
      refuse("browser-wide permissions would reach seven's origin");
    }
    if (method === "Target.getTargetInfo" && params["targetId"] !== void 0) {
      refuse("Target.getTargetInfo of another target is not supported on a page session");
    }
    if (method === "Target.setAutoAttach" && params["autoAttach"] === true) {
      refuse("auto-attach is not supported by the extension bridge");
    }
    if (method === "Network.setBypassServiceWorker" && params["bypass"] !== true) {
      refuse("service workers stay bypassed so seven's pages cannot load from cache");
    }
  }
  admitUrls(method, params) {
    if ((COOKIE_SETTERS.has(method) || COOKIE_READERS.has(method)) && cookieUrlUnparseable(params)) refuse(PROTECTED_RULES.unparseableRefusal);
    if (COOKIE_SETTERS.has(method)) {
      if (cookieRefused(params)) refuse(COOKIES_REFUSAL);
      return;
    }
    const url = str(params["url"]);
    refuseUnparseableDestination(url);
    if (NAVIGATES.has(method) && url !== void 0 && url !== "" && !URL.canParse(url)) {
      refuse("a relative url would open one of the extension's own pages");
    }
    if (NAVIGATES.has(method) && wrapsAbout(url, PROTECTED_RULES.innerSchemes)) {
      refuse(ABOUT_WRAPPED);
    }
    if (url && urlProtected(url, method.startsWith("Debugger."))) refuse(PROTECTED_RULES.refusal);
  }
  admitFrame(params) {
    const frameId = str(params["frameId"]);
    if (frameId && this.frameProtected(frameId)) refuse(PROTECTED_RULES.refusal);
  }
  admitWorlds(method, params) {
    if (profiled(method) && this.worlds.foreign) refuse(PROFILED);
    if (params["worldName"] === ABOUT_WORLD) refuse(RESERVED_WORLD);
    if (this.worlds.named(params["worldName"])) refuse(WORLD);
    const reason = this.worlds.refusal(params);
    if (reason) refuse(reason);
  }
  admitPaused(method, id, params) {
    if (answerNamesProtected(params, this.pausedUrls.get(id) ?? "")) {
      refuse(PROTECTED_RULES.refusal);
    }
    if (!FETCH_READS.has(method)) return;
    if (this.namedBodies.has(id)) refuse(PROTECTED_RULES.refusal);
    const read = this.bodyReads.get(id);
    if (read !== void 0 && read !== method) refuse(BODY_READ_REFUSAL);
    this.bodyReads.set(id, method);
  }
  admitRequestIds(method, params) {
    if (FETCH_ANSWERS.has(method)) {
      const id = str(params["requestId"]);
      if (!id || !this.forwarded.has(id)) refuse(PAUSE_REFUSAL);
      this.admitPaused(method, id, params);
      return;
    }
    if (BODY_METHODS.has(method)) {
      const id = requestKey(params);
      const state2 = id ? this.requests.get(id) : void 0;
      if (state2 === void 0) refuse(UNSEEN_REFUSAL);
      if (state2) refuse(PROTECTED_RULES.refusal);
      return;
    }
    if (method === "IO.read" && !this.streams.has(str(params["handle"]) ?? "")) refuse(STREAM_REFUSAL);
  }
  async admitHistory(params) {
    const history = await this.send("Page.getNavigationHistory", {});
    const entries = Array.isArray(history["entries"]) ? history["entries"] : [];
    const entry = entries.find((e) => isObj3(e) && e["id"] === params["entryId"]);
    const url = isObj3(entry) ? str(entry["url"]) ?? "" : "";
    if (urlProtected(url)) refuse(PROTECTED_RULES.refusal);
  }
  rewrite(method, params) {
    if (method === "Fetch.enable") {
      const patterns = Array.isArray(params["patterns"]) ? params["patterns"] : [{ urlPattern: "*" }];
      this.clientFetch = { patterns, handleAuthRequests: params["handleAuthRequests"] === true };
      return this.fetchParams();
    }
    if (method === "Fetch.disable") {
      this.clientFetch = null;
      void this.send("Fetch.enable", this.fetchParams()).catch(() => this.block());
      return null;
    }
    if (method === "Fetch.continueRequest" && params["url"] !== void 0) {
      return { ...params, interceptResponse: true };
    }
    if (method === "Page.addScriptToEvaluateOnNewDocument") {
      return { ...params, source: initScriptGuard() + (str(params["source"]) ?? "") };
    }
    if (method === "Page.addScriptToEvaluateOnLoad") {
      return { ...params, scriptSource: initScriptGuard() + (str(params["scriptSource"]) ?? "") };
    }
    return params;
  }
  async after(method, result, params) {
    if (method === "Page.captureSnapshot") {
      const data = (str(result["data"]) ?? "").replace(/=\r?\n/g, "");
      if (redactText(data) !== data) refuse(PROTECTED_RULES.refusal);
    }
    this.worlds.learn(result);
    if (method === "Page.createIsolatedWorld") this.worlds.seen(result["executionContextId"]);
    const stream = str(result["stream"]);
    if (stream) {
      const opened = new UrlStream();
      opened.page = !BODY_METHODS.has(method);
      this.streams.set(stream, opened);
    }
    const resource = result["resource"];
    const resourceStream = isObj3(resource) ? str(resource["stream"]) : void 0;
    if (resourceStream) this.streams.set(resourceStream, new UrlStream());
    if (method === "Page.getFrameTree" || method === "Page.getResourceTree") {
      await resolveFrameOrigins(result["frameTree"], this.uncertainFrames, (id) => this.documentOrigin(id));
      this.pruneFrames(result["frameTree"]);
    }
    if (COOKIE_READERS.has(method)) dropProtectedCookies(result);
    if (method === "Page.getNavigationHistory") redactHistory(result);
    if (method === "Target.getTargetInfo" && isObj3(result["targetInfo"])) {
      const info = result["targetInfo"];
      if (isProtectedTargetType(info["type"])) refuse(PROTECTED_RULES.refusal);
      if (isProtectedTarget(str(info["url"]) ?? "", false, "unknown")) result["targetInfo"] = redacted(info);
    }
    if (method === "Network.streamResourceContent") {
      return this.networkStreams.buffer(str(params["requestId"]) ?? "", result);
    }
    const read = method === "IO.read" ? this.streams.get(str(params["handle"]) ?? "") : void 0;
    return read ? streamRead(read, result) : result;
  }
  onEvent(method, params) {
    const p = params ?? {};
    if (invalidates(method, p)) this.invalidate();
    const id = str(p["requestId"]) ?? "";
    if (method === "Network.loadingFinished" || method === "Network.loadingFailed") {
      this.networkStreams.end(id);
    }
    if (method === "Network.dataReceived" && typeof p["data"] === "string") {
      try {
        this.networkStreams.read(id, p["data"]);
      } catch {
        return [];
      }
    }
    if (method === "Fetch.requestPaused") return this.onPaused(p);
    if (method === "Fetch.authRequired") return this.onAuth(p);
    if (this.wake.hides(method, p)) return [];
    this.track(p);
    if (this.watchCommit(method, p)) return [];
    if (profiled(method) && this.worlds.foreign) return [];
    if (this.worlds.hides(p)) return [];
    if (this.frameProtected(str(p["frameId"]) ?? "")) return [];
    if (DISCOVERY_EVENTS.has(method)) return [];
    if (errorPageRead(method)) {
      return this.checkContent(method, p).then(async () => {
        if (sealedRead(method) && !await this.sealEvent(method, p)) return [];
        return this.deliver({ method, params: p });
      }, () => []);
    }
    if (method.startsWith("Target.")) {
      if (isObj3(p["targetInfo"]) && isProtectedTargetType(p["targetInfo"]["type"])) return [];
      return [this.redactTarget(method, p)];
    }
    return this.deliver({ method, params: p });
  }
  initiatedByProtected(paused) {
    if (this.frameProtected(str(paused["frameId"]) ?? "")) return true;
    const request = paused["request"];
    const headers = isObj3(request) && isObj3(request["headers"]) ? request["headers"] : {};
    return Object.entries(headers).some(([name, value]) => {
      const lower = name.toLowerCase();
      return (lower === "referer" || lower === "origin") && value !== "null" && urlProtected(str(value) ?? "");
    });
  }
  onPaused(paused) {
    const id = str(paused["requestId"]) ?? "";
    if (this.rerouted(paused, id)) return [];
    const protectedUrl = urlProtected(requestUrl(paused) ?? "");
    const tainted = protectedUrl || this.initiatedByProtected(paused);
    this.requests.set(id, tainted);
    const networkId = str(paused["networkId"]);
    if (networkId) this.requests.set(networkId, tainted || this.requests.get(networkId) === true);
    if (protectedUrl && paused["resourceType"] === "Document") {
      this.failedDocuments.set((requestUrl(paused) ?? "").split("#")[0] ?? "", true);
      this.answer("Fetch.failRequest", { requestId: id, errorReason: "BlockedByClient" });
      return [];
    }
    if (headersNameProtected(paused["responseHeaders"], requestUrl(paused))) {
      this.namedBodies.set(id, true);
      if (networkId) this.requests.set(networkId, true);
    }
    const wanted = this.clientFetch?.patterns.some((pattern) => patternMatches(pattern, paused)) === true;
    if (tainted || this.blockedFlag || !wanted) {
      this.answer("Fetch.continueRequest", { requestId: id });
      return [];
    }
    this.forwarded.set(id, true);
    this.pausedUrls.set(id, requestUrl(paused) ?? "");
    return [{ method: "Fetch.requestPaused", params: paused }];
  }
  onAuth(event) {
    const id = str(event["requestId"]) ?? "";
    const protectedUrl = urlProtected(requestUrl(event) ?? "") || this.requests.get(id) === true;
    if (protectedUrl || this.blockedFlag || this.clientFetch?.handleAuthRequests !== true) {
      this.answer("Fetch.continueWithAuth", { requestId: id, authChallengeResponse: { response: "Default" } });
      return [];
    }
    this.forwarded.set(id, true);
    return [{ method: "Fetch.authRequired", params: event }];
  }
  answer(method, params) {
    this.send(method, params).catch(() => {
    });
  }
  track(params) {
    const id = str(params["requestId"]);
    const url = requestUrl(params);
    if (!id || url === void 0) return;
    const initiator = params["initiator"];
    const fromProtected = urlProtected(str(params["documentURL"]) ?? "") || urlProtected(isObj3(initiator) ? str(initiator["url"]) ?? "" : "") || this.frameProtected(str(params["frameId"]) ?? "");
    const tainted = fromProtected || urlProtected(url) || this.requests.get(id) === true;
    this.requests.set(id, tainted);
  }
  frameProtected(frameId) {
    if (!frameId) return false;
    if (this.hiddenFrames.has(frameId)) return true;
    return (this.frames.get(frameId) ?? []).some((url) => urlProtected(url));
  }
  navigation(method, params) {
    const id = str(params["frameId"]) ?? "";
    if (["Page.frameStartedLoading", "Page.frameStartedNavigating"].includes(method)) {
      this.startedFrames.add(id);
      this.pendingFrames.add(id);
    }
    if (["Page.frameRequestedNavigation", "Page.frameScheduledNavigation"].includes(method)) {
      this.pendingFrames.add(id);
    }
    if (method === "Page.lifecycleEvent" && params["name"] === "init" && params["frameId"] === this.mainFrameId && params["loaderId"] !== this.documents.frames.get(this.mainFrameId)?.loaderId) {
      this.pendingFrames.add(id);
      this.startedFrames.add(id);
    }
    if (["Page.frameStoppedLoading", "Page.frameDetached", "Page.navigatedWithinDocument"].includes(method) || method === "Page.frameClearedScheduledNavigation" && !this.startedFrames.has(id)) {
      this.pendingFrames.delete(id);
      this.startedFrames.delete(id);
    }
    if (method !== "Page.frameNavigated" || !isObj3(params["frame"])) return;
    const frame = params["frame"];
    this.documents.frame(frame);
    this.pendingFrames.delete(str(frame["id"]) ?? "");
    this.pendingFrames.delete("");
    this.startedFrames.delete(str(frame["id"]) ?? "");
    this.startedFrames.delete("");
    if (frame["parentId"] === void 0) {
      this.pendingFrames.clear();
      this.startedFrames.clear();
    }
  }
  watchCommit(method, params) {
    this.navigation(method, params);
    if (method === "Page.frameNavigated" && isObj3(params["frame"])) {
      const frame = params["frame"];
      const url = `${str(frame["url"]) ?? ""}${str(frame["urlFragment"]) ?? ""}`;
      const origin = str(frame["securityOrigin"]) ?? "";
      const id = str(frame["id"]);
      if (id) this.frames.set(id, [url, origin]);
      if (frame["parentId"] === void 0) {
        if (id) this.mainFrameId = id;
        if (urlProtected(url) || urlProtected(origin)) this.block();
        return false;
      }
      if (id && (extensionOrigin(url) || extensionOrigin(origin))) {
        this.hiddenFrames.set(id, true);
        return true;
      }
      return false;
    }
    if (method === "Runtime.executionContextDestroyed") {
      this.documents.contexts.delete(params["executionContextId"]);
      return this.worlds.remove(params["executionContextId"]);
    }
    if (method === "Runtime.executionContextsCleared") {
      this.documents.contexts.clear();
      this.worlds.clear();
      return false;
    }
    if (method === "Runtime.executionContextCreated" && isObj3(params["context"])) {
      return this.watchContext(params["context"]);
    }
    return false;
  }
  watchContext(context) {
    this.documents.context(context);
    const aux = isObj3(context["auxData"]) ? context["auxData"] : {};
    const origin = str(context["origin"]) ?? "";
    const frame = str(aux["frameId"]);
    let kind = this.worlds.kindOf(context, urlProtected);
    if (aux["isDefault"] !== false && kind === void 0) {
      if (frame) this.frames.set(frame, [...this.frames.get(frame) ?? [], origin]);
      const child = frame !== void 0 && frame !== this.mainFrameId;
      if (child && unknownFrame({ securityOrigin: origin, url: origin })) {
        this.uncertainFrames.set(frame, true);
      }
      if (child && (extensionOrigin(origin) || frame && this.hiddenFrames.has(frame))) {
        if (frame) this.hiddenFrames.set(frame, true);
        kind = "foreign";
      } else if (urlProtected(origin)) {
        this.block();
        return true;
      }
    }
    if (this.worlds.add(context, kind)) this.quietProfilers();
    return kind !== void 0;
  }
  pruneFrames(tree) {
    if (!isObj3(tree) || !Array.isArray(tree["childFrames"])) return;
    const kept = tree["childFrames"].filter((node) => {
      const frame = isObj3(node) && isObj3(node["frame"]) ? node["frame"] : {};
      const id = str(frame["id"]) ?? "";
      const hidden = this.frameHidden(frame);
      if (hidden && id) this.hiddenFrames.set(id, true);
      return !hidden;
    });
    tree["childFrames"] = kept;
    for (const node of kept) this.pruneFrames(node);
  }
  quietProfilers() {
    for (const method of ["Debugger.disable", "Profiler.disable", "HeapProfiler.disable"]) {
      this.send(method, {}).catch(() => {
      });
    }
  }
  redactTarget(method, params) {
    const info = params["targetInfo"];
    if (!isObj3(info)) return { method, params };
    const opener = str(info["openerId"]) ? "unknown" : void 0;
    if (!isProtectedTarget(str(info["url"]) ?? "", false, opener)) return { method, params };
    return { method, params: { ...params, targetInfo: redacted(info) } };
  }
  redirectHop(params, id) {
    const redirect = params["redirectResponse"];
    const from = isObj3(redirect) ? str(redirect["url"]) : void 0;
    if (!from || urlProtected(from) || !urlProtected(requestUrl(params) ?? "")) return false;
    this.requests.set(id, true);
    this.held.delete(id);
    if (this.hops.get(id) !== "done") this.hops.set(id, hopOf(redirect));
    stripSetCookie(redirect);
    stripCookie(redirect["requestHeaders"]);
    const request = params["request"];
    if (isObj3(request)) stripCookie(request["headers"]);
    return true;
  }
  redirectExtra(params, id) {
    const status = params["statusCode"];
    if (typeof status !== "number" || !REDIRECTS.has(status)) return false;
    const awaited = hopMatches(this.hops.get(id), params);
    const named = responseNamesProtected("Network.responseReceivedExtraInfo", params);
    if (this.requests.get(id) === true ? !awaited : !named) return false;
    this.hops.set(id, "done");
    this.requests.set(id, true);
    stripProtectedAssociated(params);
    stripSetCookie(params);
    return true;
  }
  redirected(event, id) {
    const params = event.params ?? {};
    if (!id) return false;
    if (event.method === "Network.requestWillBeSent") return this.redirectHop(params, id);
    if (event.method === "Network.responseReceivedExtraInfo") return this.redirectExtra(params, id);
    return false;
  }
  settle(id) {
    const held = this.held.delete(id) ?? [];
    if (this.requests.get(id) !== false) return [];
    this.settled.set(id, true);
    return held;
  }
  deliver(event) {
    const params = event.params ?? {};
    const id = str(params["requestId"]);
    if (this.redirected(event, id)) return [event];
    if (id && this.requests.get(id) === true) {
      this.held.delete(id);
      return [];
    }
    if (mentions(params) || responseNamesProtected(event.method, params)) {
      if (id) {
        this.requests.set(id, true);
        this.held.delete(id);
      }
      return [];
    }
    if (id && event.method.endsWith("ExtraInfo")) {
      stripProtectedAssociated(params);
      if (!this.settled.has(id)) {
        this.held.set(id, [...this.held.get(id) ?? [], event]);
        return [];
      }
    }
    const released = id && SETTLES.has(event.method) ? this.settle(id) : [];
    if (event.method.startsWith("DOM.") || event.method.startsWith("Runtime.")) {
      this.documents.event(params, this.mainFrameId);
    }
    this.worlds.learn(params);
    return [event, ...released];
  }
};
var STORAGE_KEY = "slicc_protected_frame_tabs";
var chain = Promise.resolve();
async function readTabs() {
  const got = await chrome.storage.session.get(STORAGE_KEY);
  const raw = got[STORAGE_KEY];
  return new Set(Array.isArray(raw) ? raw.filter((v) => typeof v === "number") : []);
}
function update(mutate) {
  const next = chain.then(async () => {
    const tabs = await readTabs();
    if (mutate(tabs)) await chrome.storage.session.set({ [STORAGE_KEY]: [...tabs] });
  });
  chain = next.catch(() => {
  });
  return next;
}
async function tabHasProtectedFrame(tabId) {
  await chain;
  try {
    return (await readTabs()).has(tabId);
  } catch {
    return true;
  }
}
function noteFrameResponse(details) {
  const { tabId, type, url } = details;
  if (tabId < 0) return Promise.resolve();
  if (type === "main_frame") return update((tabs) => tabs.delete(tabId));
  if (type === "sub_frame" && isProtectedUrl(url) && !extensionOrigin(url)) {
    return update((tabs) => {
      if (tabs.has(tabId)) return false;
      tabs.add(tabId);
      return true;
    });
  }
  return Promise.resolve();
}
function installProtectedFrameTracker() {
  chrome.webRequest.onHeadersReceived.addListener((details) => {
    noteFrameResponse(details).catch(() => {
    });
  }, { urls: ["<all_urls>"], types: ["main_frame", "sub_frame"] });
  chrome.tabs.onRemoved.addListener((tabId) => {
    update((tabs) => tabs.delete(tabId)).catch(() => {
    });
  });
}
function readTargetIdParam(params, label = "targetId") {
  const targetId = params[label];
  if (typeof targetId !== "string") {
    throw new Error(`Invalid targetId: ${String(targetId)}`);
  }
  return targetId;
}
function readCreateTargetUrl(params) {
  const url = params["url"];
  return typeof url === "string" && url !== "" ? url : "about:blank";
}
var RELATIVE_REFUSAL = "slicc: refused: a relative url would open one of the extension's own pages";
function exactTabId(targetId) {
  const tabId = parseInt(targetId, 10);
  if (!Number.isFinite(tabId) || tabId <= 0 || String(tabId) !== targetId) {
    throw new Error(`slicc: refused: Invalid targetId: ${targetId} is not a tab`);
  }
  return tabId;
}
var ERROR_PAGE2 = "chrome-error://chromewebdata/";
var DISCOVERY_REFUSAL = "slicc: refused: the extension bridge does not report target discovery events";
var failedTabs = new Bounded(500);
function failedBefore(tabId, url) {
  if (!url) return false;
  return failedTabs.get(String(tabId))?.has(url.split("#")[0] ?? url) === true;
}
function failuresOf(tabId) {
  const known = failedTabs.get(String(tabId));
  if (known) return known;
  const fresh = new Bounded(200);
  failedTabs.set(String(tabId), fresh);
  return fresh;
}
function failedView(tabId, tab) {
  if (!tab || !failedBefore(tabId, tab.url)) return tab;
  const pending = failedBefore(tabId, tab.pendingUrl) ? "" : tab.pendingUrl;
  return { ...tab, url: ERROR_PAGE2, pendingUrl: pending };
}
async function confirmFailure(tabId, deps) {
  const tab = await deps.getTab(tabId);
  if (!failedBefore(tabId, tab?.url) && !failedBefore(tabId, tab?.pendingUrl)) return;
  const tree = await deps.sendDebuggerCommand(tabId, "Page.getFrameTree").catch(() => void 0);
  const frameTree = tree?.["frameTree"];
  const frame = frameTree?.["frame"];
  const unreachable = frame?.["unreachableUrl"];
  if (typeof unreachable === "string" && failedBefore(tabId, unreachable)) return;
  failedTabs.get(String(tabId))?.clear();
}
async function protectedNow(tabId, deps) {
  return isProtectedTab(failedView(tabId, await deps.getTab(tabId)), deps.getTab);
}
async function guardedTab(params, deps) {
  const tabId = exactTabId(readTargetIdParam(params));
  if (await protectedNow(tabId, deps)) throw new Error(PROTECTED_REFUSAL);
  return tabId;
}
var LEADER_TAB_ID_KEY = "slicc_leader_tab_id";
var BRIDGE_ALLOWED_ORIGINS = [SLICC_HOSTED_ORIGIN];
function senderUrlIsLeaderTab(rawUrl) {
  if (!rawUrl) return false;
  try {
    return new URL(rawUrl).searchParams.get("slicc") === "leader";
  } catch {
    return false;
  }
}
async function validateBridgePin(sender, deps) {
  const allowed = deps.allowedOrigins ?? BRIDGE_ALLOWED_ORIGINS;
  if (!sender) return { ok: false, reason: "no-sender" };
  if (!sender.origin || !allowed.includes(sender.origin)) {
    return { ok: false, reason: "origin-not-allowed" };
  }
  const senderTabId = sender.tab?.id;
  if (typeof senderTabId !== "number") {
    return { ok: false, reason: "no-sender-tab" };
  }
  if (sender.frameId !== 0) {
    return { ok: false, reason: "not-top-frame" };
  }
  const storedTabId = await deps.readStoredLeaderTabId();
  if (storedTabId === void 0) {
    if (senderUrlIsLeaderTab(sender.url) && deps.writeStoredLeaderTabId) {
      await deps.writeStoredLeaderTabId(senderTabId);
      return { ok: true };
    }
    return { ok: false, reason: "leader-tab-not-pinned" };
  }
  if (storedTabId !== senderTabId) {
    return { ok: false, reason: "sender-tab-not-leader" };
  }
  return { ok: true };
}
var welcomedLeaderPorts = /* @__PURE__ */ new Map();
var fronts = /* @__PURE__ */ new Map();
function noteBridgeTabActivated(info) {
  fronts.set(info.windowId, { current: info.tabId, previous: fronts.get(info.windowId)?.current });
}
function noteBridgeWindowRemoved(windowId) {
  fronts.delete(windowId);
}
function frontBefore(windowId, tabId) {
  const seen = fronts.get(windowId);
  return seen?.current === tabId ? seen.previous : seen?.current;
}
async function seedFronts(deps) {
  for (const tab of await deps.queryTabs()) {
    if (tab.active && typeof tab.id === "number" && typeof tab.windowId === "number") {
      if (!fronts.has(tab.windowId)) fronts.set(tab.windowId, { current: tab.id });
    }
  }
}
function noteBridgeTabOpened(tabId, openerId, deps) {
  for (const state2 of liveBridgePortStates.values()) {
    keepLeaderFront(state2, tabId, openerId, deps).catch(() => {
    });
  }
}
var FRAME_EVENTS = ["onBeforeNavigate", "onCommitted", "onDOMContentLoaded", "onCompleted", "onErrorOccurred", "onHistoryStateUpdated", "onReferenceFragmentUpdated", "onTabReplaced"];
function installBridgeFrontListeners(deps) {
  chrome.tabs.onActivated.addListener(noteBridgeTabActivated);
  chrome.windows.onRemoved.addListener(noteBridgeWindowRemoved);
  chrome.tabs.onCreated.addListener((tab) => noteBridgeTabOpened(tab.id, tab.openerTabId, deps));
  chrome.webNavigation.onCreatedNavigationTarget.addListener((details) => {
    noteBridgeTabChanged(details.tabId);
    noteBridgeTabChanged(details.sourceTabId);
    noteBridgeTabOpened(details.tabId, details.sourceTabId, deps);
  });
  for (const name of FRAME_EVENTS) chrome.webNavigation[name].addListener(noteBridgeFrames);
}
function noteBridgeFrames(details) {
  noteBridgeTabChanged(details.tabId);
  if (details.replacedTabId !== void 0) noteBridgeTabChanged(details.replacedTabId);
}
function noteBridgeTabChanged(tabId) {
  tabShields.get(tabId)?.invalidate();
}
async function keepLeaderFront(state2, tabId, openerId, deps) {
  const leader = state2.leaderTabId;
  if (leader === void 0 || tabId === void 0 || openerId === void 0) return;
  if (!state2.ownedTabs.has(openerId) && ![...state2.sessionToTab.values()].includes(openerId)) {
    return;
  }
  const [opened, client] = await Promise.all([deps.getTab(tabId), deps.getTab(leader)]);
  const windowId = client?.windowId;
  if (!opened?.active || windowId === void 0 || frontBefore(windowId, tabId) !== leader) return;
  if (opened.windowId === windowId) await deps.showTab(leader);
  else await deps.updateWindow(windowId, { focused: true });
}
var liveBridgePortStates = /* @__PURE__ */ new Map();
function invalidatePortDebuggerAttachment(state2, tabId) {
  state2.ownedTabs.delete(tabId);
  state2.attachRefCounts.delete(tabId);
  for (const [sessionId, attachedTabId] of state2.sessionToTab) {
    if (attachedTabId === tabId) {
      state2.sessionToTab.delete(sessionId);
      state2.pageSessions.delete(sessionId);
      state2.lifecycleSessions.delete(sessionId);
    }
  }
  state2.runtimeTabs.delete(tabId);
}
function notifyBridgeDebuggerDetached(tabId) {
  tabShields.delete(tabId);
  for (const [port, state2] of liveBridgePortStates) {
    const detachedSessionIds = [...state2.sessionToTab].filter(([, attachedTabId]) => attachedTabId === tabId).map(([sessionId]) => sessionId);
    invalidatePortDebuggerAttachment(state2, tabId);
    if (state2.channelId === null) continue;
    for (const sessionId of detachedSessionIds) {
      try {
        port.postMessage({ bridge: EXTENSION_BRIDGE_PROTOCOL_VERSION, channelId: state2.channelId, kind: "cdp.event", method: "Target.detachedFromTarget", params: { sessionId, targetId: String(tabId) } });
      } catch {
      }
    }
  }
}
function noteBridgeMainFrameResponse(details) {
  if (details.type !== "main_frame" || !failedBefore(details.tabId, details.url)) return;
  failedTabs.get(String(details.tabId))?.clear();
}
function checkBridgeTabProtection(tabId, url) {
  if (url && !failedBefore(tabId, url)) failedTabs.get(String(tabId))?.clear();
  if (!url || !isProtectedUrl(url)) return /* @__PURE__ */ new Set();
  if (failedBefore(tabId, url)) return /* @__PURE__ */ new Set();
  return cutProtectedTab(tabId);
}
function cutProtectedTab(tabId) {
  const detached = /* @__PURE__ */ new Set();
  tabShields.delete(tabId);
  failedTabs.get(String(tabId))?.clear();
  for (const [port, state2] of liveBridgePortStates) {
    const detachedSessionIds = [...state2.sessionToTab].filter(([, tid]) => tid === tabId).map(([sid]) => sid);
    if (detachedSessionIds.length === 0) continue;
    for (const sid of detachedSessionIds) state2.cut.add(sid);
    while (state2.cut.size > 1e3) {
      const oldest = state2.cut.values().next().value;
      if (oldest !== void 0) state2.cut.delete(oldest);
    }
    invalidatePortDebuggerAttachment(state2, tabId);
    detached.add(tabId);
    if (state2.channelId === null) continue;
    for (const sessionId of detachedSessionIds) {
      try {
        port.postMessage({ bridge: EXTENSION_BRIDGE_PROTOCOL_VERSION, channelId: state2.channelId, kind: "cdp.event", method: "Target.detachedFromTarget", params: { sessionId, targetId: String(tabId), reason: PROTECTED_REFUSAL } });
      } catch {
      }
    }
  }
  return detached;
}
var tabShields = /* @__PURE__ */ new Map();
var shieldFanouts = /* @__PURE__ */ new Map();
function subscribeShieldedEvents(deps, sink) {
  const source = deps.subscribeDebuggerEvents;
  let fanout = shieldFanouts.get(source);
  if (!fanout) {
    const sinks = /* @__PURE__ */ new Set();
    const unsubscribe = source((tabId, method, params) => {
      const shield = tabShields.get(tabId);
      if (!shield) return;
      const deliver = (events2) => {
        for (const event of events2) {
          for (const each of [...sinks]) each(tabId, event.method, event.params);
        }
      };
      const events = shield.onEvent(method, params);
      if (Array.isArray(events)) deliver(events);
      else void events.then(deliver).catch(() => void 0);
    });
    fanout = { sinks, unsubscribe };
    shieldFanouts.set(source, fanout);
  }
  fanout.sinks.add(sink);
  const current = fanout;
  return () => {
    current.sinks.delete(sink);
    if (current.sinks.size === 0 && shieldFanouts.get(source) === current) {
      shieldFanouts.delete(source);
      current.unsubscribe();
    }
  };
}
async function ensureTabShield(tabId, deps) {
  const existing = tabShields.get(tabId);
  if (existing) {
    try {
      await existing.install();
      return;
    } catch {
      throw new Error(`${PROTECTED_REFUSAL} (the tab could not be guarded)`);
    }
  }
  const shield = new TabShield((method, params) => deps.sendDebuggerCommand(tabId, method, params), () => {
    cutProtectedTab(tabId);
    deps.detachDebugger(tabId).catch(() => {
    });
  }, failuresOf(tabId), () => deps.getTab(tabId), (id) => deps.getTab(id), () => chrome.webNavigation.getAllFrames({ tabId }));
  tabShields.set(tabId, shield);
  try {
    await shield.install();
  } catch {
    if (tabShields.get(tabId) === shield) tabShields.delete(tabId);
    throw new Error(`${PROTECTED_REFUSAL} (the tab could not be guarded)`);
  }
}
function tabInUse(tabId) {
  for (const state2 of liveBridgePortStates.values()) {
    for (const tid of state2.sessionToTab.values()) if (tid === tabId) return true;
  }
  return false;
}
async function releaseTabShield(tabId, deps) {
  if (!tabShields.has(tabId) || tabInUse(tabId)) return;
  tabShields.delete(tabId);
  await deps.sendDebuggerCommand(tabId, "Fetch.disable").catch(() => {
  });
}
function postLickToWelcomedLeaderPorts(lick) {
  let delivered = 0;
  for (const [port, channelId] of welcomedLeaderPorts) {
    try {
      port.postMessage({ ...lick, bridge: EXTENSION_BRIDGE_PROTOCOL_VERSION, channelId });
      delivered += 1;
    } catch {
    }
  }
  return delivered;
}
function postOpenSettingsToWelcomedLeaderPorts() {
  let delivered = 0;
  for (const [port, channelId] of welcomedLeaderPorts) {
    try {
      port.postMessage({ kind: "extension.open-settings", bridge: EXTENSION_BRIDGE_PROTOCOL_VERSION, channelId });
      delivered += 1;
    } catch {
    }
  }
  return delivered;
}
function postDiscoveryToWelcomedLeaderPorts(discovery) {
  let delivered = 0;
  for (const [port, channelId] of welcomedLeaderPorts) {
    try {
      port.postMessage({ ...discovery, bridge: EXTENSION_BRIDGE_PROTOCOL_VERSION, channelId });
      delivered += 1;
    } catch {
    }
  }
  return delivered;
}
async function readStoredLeaderTabIdFromSession() {
  try {
    const result = await chrome.storage.session.get(LEADER_TAB_ID_KEY);
    const raw = result[LEADER_TAB_ID_KEY];
    return typeof raw === "number" ? raw : void 0;
  } catch {
    return void 0;
  }
}
async function writeStoredLeaderTabIdToSession(tabId) {
  try {
    await chrome.storage.session.set({ [LEADER_TAB_ID_KEY]: tabId });
  } catch {
  }
}
function pickDefinedWindowFields(fields) {
  const out = {};
  for (const key of Object.keys(fields)) {
    const value = fields[key];
    if (value !== void 0) {
      out[key] = value;
    }
  }
  return out;
}
function chromeWindowInfoFromChrome(win, label, tabIdFallback) {
  if (typeof win.id !== "number") {
    throw new Error(`${label} did not return a window id`);
  }
  const tabId = win.tabs?.[0]?.id;
  if (tabIdFallback === void 0 && typeof tabId !== "number") {
    throw new Error(`${label} did not return windowId/tabId`);
  }
  return { windowId: win.id, tabId: typeof tabId === "number" ? tabId : tabIdFallback, left: win.left ?? 0, top: win.top ?? 0, width: win.width ?? 0, height: win.height ?? 0, state: win.state ?? "normal" };
}
function buildDefaultBridgeSwDeps(overrides) {
  const base2 = { readStoredLeaderTabId: readStoredLeaderTabIdFromSession, writeStoredLeaderTabId: writeStoredLeaderTabIdToSession, tabHasProtectedFrame, maybeUnmaskCdpFrame: async (_tabId, _method, params) => params, attachDebugger: async (tabId) => {
    await chrome.debugger.attach({ tabId }, "1.3");
    return true;
  }, detachDebugger: async (tabId) => {
    await chrome.debugger.detach({ tabId }).catch(() => {
    });
  }, sendDebuggerCommand: async (tabId, method, params) => {
    const result = await chrome.debugger.sendCommand({ tabId }, method, params);
    return result ?? {};
  }, subscribeDebuggerEvents: (handler) => {
    const wrapped = (source, method, params) => handler(source.tabId, method, params);
    chrome.debugger.onEvent.addListener(wrapped);
    return () => chrome.debugger.onEvent.removeListener(wrapped);
  }, queryTabs: () => chrome.tabs.query({}), queryActiveTabId: async () => {
    try {
      const [t] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      return typeof t?.id === "number" ? t.id : void 0;
    } catch {
      return void 0;
    }
  }, getTab: async (tabId) => {
    try {
      return await chrome.tabs.get(tabId);
    } catch {
      return void 0;
    }
  }, createTab: async (url) => {
    const tab = await chrome.tabs.create({ url, active: false });
    return tab.id;
  }, createWindow: async (opts) => {
    const created = await chrome.windows.create({ url: opts.url, type: opts.type, focused: opts.focused, ...pickDefinedWindowFields({ width: opts.width, height: opts.height, left: opts.left, top: opts.top, state: opts.state }) });
    return chromeWindowInfoFromChrome(created, "chrome.windows.create");
  }, getWindow: async (windowId) => {
    const win = await chrome.windows.get(windowId, { populate: true });
    return chromeWindowInfoFromChrome(win, `chrome.windows.get(${windowId})`, -1);
  }, updateWindow: async (windowId, props) => {
    const updated = await chrome.windows.update(windowId, pickDefinedWindowFields({ left: props.left, top: props.top, width: props.width, height: props.height, state: props.state, focused: props.focused }));
    return chromeWindowInfoFromChrome(updated, `chrome.windows.update(${windowId})`, -1);
  }, removeTab: (tabId) => chrome.tabs.remove(tabId), showTab: async (tabId) => {
    await chrome.tabs.update(tabId, { active: true });
  }, activateTab: async (tabId) => {
    try {
      const tab = await chrome.tabs.update(tabId, { active: true });
      if (typeof tab?.windowId === "number") {
        await chrome.windows.update(tab.windowId, { focused: true });
      }
    } catch {
    }
  } };
  return { ...base2, ...overrides ?? {} };
}
async function handleBridgePortConnect(port, deps) {
  if (port.name !== EXTENSION_BRIDGE_PORT_NAME) return;
  const state2 = { channelId: null, sessionToTab: /* @__PURE__ */ new Map(), attachRefCounts: /* @__PURE__ */ new Map(), ownedTabs: /* @__PURE__ */ new Set(), runtimeTabs: /* @__PURE__ */ new Set(), pageSessions: /* @__PURE__ */ new Set(), lifecycleSessions: /* @__PURE__ */ new Set(), unsubscribeEvents: null, emit: () => {
  }, announce: () => {
  }, cut: /* @__PURE__ */ new Set(), leaderTabId: port.sender?.tab?.id };
  let pinned = false;
  let rejected = false;
  const earlyQueue = [];
  const runMessage = (raw) => {
    handleBridgeMessage(port, state2, raw, deps).catch((err) => {
      console.error("[slicc-bridge-sw] handleBridgeMessage threw", err);
    });
  };
  port.onMessage.addListener((raw) => {
    if (rejected) return;
    if (!pinned) {
      earlyQueue.push(raw);
      return;
    }
    runMessage(raw);
  });
  port.onDisconnect.addListener(() => {
    welcomedLeaderPorts.delete(port);
    liveBridgePortStates.delete(port);
    if (state2.unsubscribeEvents) {
      state2.unsubscribeEvents();
      state2.unsubscribeEvents = null;
    }
    const usedTabs = new Set(state2.sessionToTab.values());
    for (const tabId of state2.ownedTabs) {
      tabShields.delete(tabId);
      deps.detachDebugger(tabId).catch(() => {
      });
    }
    state2.ownedTabs.clear();
    state2.sessionToTab.clear();
    state2.runtimeTabs.clear();
    state2.pageSessions.clear();
    state2.lifecycleSessions.clear();
    state2.attachRefCounts.clear();
    for (const tabId of usedTabs) releaseTabShield(tabId, deps).catch(() => {
    });
  });
  const pin = await validateBridgePin(port.sender, deps);
  if (!pin.ok) {
    rejected = true;
    try {
      port.postMessage({ bridge: EXTENSION_BRIDGE_PROTOCOL_VERSION, channelId: "rejected", kind: "handshake.rejected", reason: pin.reason ?? "pin-failed" });
    } catch {
    }
    try {
      port.disconnect();
    } catch {
    }
    return;
  }
  pinned = true;
  await seedFronts(deps).catch(() => {
  });
  for (const raw of earlyQueue) runMessage(raw);
  earlyQueue.length = 0;
}
async function handleBridgeMessage(port, state2, raw, deps) {
  if (isBridgeVersionMismatch(raw)) {
    console.warn("[slicc-bridge-sw] bridge protocol version mismatch \u2014 update the older side", { peerVersion: raw.bridge, ourVersion: EXTENSION_BRIDGE_PROTOCOL_VERSION });
    try {
      port.postMessage({ bridge: EXTENSION_BRIDGE_PROTOCOL_VERSION, channelId: raw.channelId, kind: "handshake.rejected", reason: "version-mismatch" });
      port.disconnect();
    } catch {
    }
    return;
  }
  if (!isExtensionBridgeEnvelope(raw)) return;
  const env = raw;
  if (state2.channelId === null) {
    if (env.kind !== "handshake.hello") {
      port.postMessage({ bridge: EXTENSION_BRIDGE_PROTOCOL_VERSION, channelId: env.channelId, kind: "handshake.rejected", reason: "expected-hello-first" });
      try {
        port.disconnect();
      } catch {
      }
      return;
    }
    state2.channelId = env.channelId;
    liveBridgePortStates.set(port, state2);
    state2.emit = (tabId, method, params) => {
      let sessionId;
      for (const [sid, tid] of state2.sessionToTab) {
        if (tid === tabId && (!method.startsWith("Page.") || state2.pageSessions.has(sid)) && (method !== "Page.lifecycleEvent" || state2.lifecycleSessions.has(sid))) {
          sessionId = sid;
          break;
        }
      }
      if (sessionId === void 0) return;
      const channelId = state2.channelId;
      if (channelId === null) return;
      try {
        port.postMessage({ bridge: EXTENSION_BRIDGE_PROTOCOL_VERSION, channelId, kind: "cdp.event", method, params: redactProtected(params, method), sessionId });
      } catch {
      }
    };
    state2.announce = (method, params) => {
      const channelId = state2.channelId;
      if (channelId === null) return;
      try {
        port.postMessage({ bridge: EXTENSION_BRIDGE_PROTOCOL_VERSION, channelId, kind: "cdp.event", method, params: redactProtected(params, method) });
      } catch {
      }
    };
    state2.unsubscribeEvents = subscribeShieldedEvents(deps, (tabId, method, params) => {
      if (method.startsWith("Runtime.") && !state2.runtimeTabs.has(tabId)) return;
      state2.emit(tabId, method, params);
    });
    port.postMessage({ bridge: EXTENSION_BRIDGE_PROTOCOL_VERSION, channelId: state2.channelId, kind: "handshake.welcome" });
    welcomedLeaderPorts.set(port, state2.channelId);
    return;
  }
  if (env.kind === "leader.join-url") {
    if (env.channelId !== state2.channelId) return;
    deps.onLeaderJoinUrl?.(env.joinUrl);
    return;
  }
  if (env.kind !== "cdp.request") return;
  if (env.channelId !== state2.channelId) return;
  const id = env.id;
  try {
    const result = await dispatchCdpCommand(env, state2, deps);
    port.postMessage({ bridge: EXTENSION_BRIDGE_PROTOCOL_VERSION, channelId: state2.channelId, kind: "cdp.response", id, result: redactProtected(result, env.method) });
  } catch (err) {
    port.postMessage({ bridge: EXTENSION_BRIDGE_PROTOCOL_VERSION, channelId: state2.channelId, kind: "cdp.response", id, error: redactText(err instanceof Error ? err.message : String(err)) });
  }
}
function attachedTab(method, sessionId, state2) {
  if (sessionId === void 0 && method === "Target.setDiscoverTargets") {
    throw new Error(DISCOVERY_REFUSAL);
  }
  const tabId = sessionId !== void 0 ? state2.sessionToTab.get(sessionId) : void 0;
  if (tabId !== void 0) return tabId;
  if (sessionId !== void 0 && state2.cut.has(sessionId)) throw new Error(PROTECTED_REFUSAL);
  throw new Error(`No tab attached for sessionId: ${sessionId ?? "(none)"}. Attach to a target first.`);
}
async function dispatchCdpCommand(req, state2, deps) {
  const { method, params, sessionId } = req;
  if (method === "Target.getTargets") return cdpGetTargets(state2, deps);
  if (method === "Target.attachToTarget") return cdpAttachToTarget(params ?? {}, state2, deps);
  if (method === "Target.detachFromTarget") return cdpDetachFromTarget(params ?? {}, state2, deps);
  if (method === "Target.createTarget") return cdpCreateTarget(params ?? {}, deps);
  if (method === "Target.closeTarget") return cdpCloseTarget(params ?? {}, state2, deps);
  if (method === "Target.getTargetInfo" && sessionId === void 0 && params?.["targetId"] !== void 0) {
    return cdpGetTargetInfo(params ?? {}, deps);
  }
  if (method === "Browser.getWindowForTarget") {
    return cdpGetWindowForTarget(params ?? {}, deps);
  }
  if (method === "Browser.getWindowBounds") return cdpGetWindowBounds(params ?? {}, deps);
  if (method === "Browser.setWindowBounds") {
    return cdpSetWindowBounds(params ?? {}, state2, deps);
  }
  const tabId = attachedTab(method, sessionId, state2);
  if (method === "Page.bringToFront") {
    await deps.activateTab(tabId);
  }
  const shield = tabShields.get(tabId);
  if (!shield) throw new Error(`${PROTECTED_REFUSAL} (the tab is not guarded)`);
  const result = await shield.command(method, params, async (m, p) => deps.sendDebuggerCommand(tabId, m, await deps.maybeUnmaskCdpFrame(tabId, m, p)));
  switchRuntime(method, tabId, state2, shield);
  switchPage(method, params, sessionId, state2);
  return result;
}
function switchPage(method, params, sessionId, state2) {
  if (sessionId === void 0) return;
  if (method === "Page.enable") state2.pageSessions.add(sessionId);
  if (method === "Page.disable") state2.pageSessions.delete(sessionId);
  if (method === "Page.setLifecycleEventsEnabled") {
    if (params?.["enabled"] === true) state2.lifecycleSessions.add(sessionId);
    else state2.lifecycleSessions.delete(sessionId);
  }
}
function switchRuntime(method, tabId, state2, shield) {
  if (method === "Runtime.disable") state2.runtimeTabs.delete(tabId);
  if (method !== "Runtime.enable" || state2.runtimeTabs.has(tabId)) return;
  state2.runtimeTabs.add(tabId);
  for (const context of shield.visibleContexts()) {
    state2.emit(tabId, "Runtime.executionContextCreated", { context });
  }
}
async function cdpGetTargets(_state, deps) {
  const [tabs, activeId] = await Promise.all([deps.queryTabs(), deps.queryActiveTabId()]);
  const targetInfos = tabs.filter((t) => typeof t.id === "number").map((t) => {
    const info = { targetId: String(t.id), type: "page", title: t.title ?? "", url: t.url ?? "", attached: false, active: t.id === activeId };
    return isProtectedTarget(info.url, false, "unknown") ? { ...info, ...redacted(info) } : info;
  });
  return { targetInfos };
}
async function cdpAttachToTarget(params, state2, deps) {
  const targetId = readTargetIdParam(params);
  const tabId = await guardedTab(params, deps);
  if (!state2.ownedTabs.has(tabId)) {
    const attachedByThisPort = await deps.attachDebugger(tabId).catch((err) => {
      if (foreignFrameError(err)) throw new Error(EXTENSION_FRAME);
      throw err;
    });
    if (attachedByThisPort) state2.ownedTabs.add(tabId);
  }
  await confirmFailure(tabId, deps);
  if (await protectedNow(tabId, deps)) {
    if (state2.ownedTabs.has(tabId)) {
      state2.ownedTabs.delete(tabId);
      await deps.detachDebugger(tabId);
    }
    throw new Error(PROTECTED_REFUSAL);
  }
  try {
    await ensureTabShield(tabId, deps);
    if (await deps.tabHasProtectedFrame?.(tabId)) throw new Error(PROTECTED_REFUSAL);
  } catch (err) {
    if (state2.ownedTabs.has(tabId)) {
      state2.ownedTabs.delete(tabId);
      tabShields.delete(tabId);
      await deps.detachDebugger(tabId);
    } else {
      await releaseTabShield(tabId, deps);
    }
    throw err;
  }
  const sessionId = targetId;
  state2.cut.delete(sessionId);
  state2.sessionToTab.set(sessionId, tabId);
  state2.attachRefCounts.set(tabId, (state2.attachRefCounts.get(tabId) ?? 0) + 1);
  const tab = await deps.getTab(tabId);
  const url = tab?.url || tab?.pendingUrl || "";
  const info = { targetId, type: "page", title: tab?.title ?? "", url, attached: true, canAccessOpener: false };
  state2.announce("Target.attachedToTarget", { sessionId, targetInfo: url && isProtectedUrl(url) ? redacted(info) : info, waitingForDebugger: false });
  return { sessionId };
}
async function cdpDetachFromTarget(params, state2, deps) {
  const sessionId = params["sessionId"];
  if (typeof sessionId !== "string") return {};
  const tabId = state2.sessionToTab.get(sessionId);
  if (tabId === void 0) return {};
  const nextRefCount = (state2.attachRefCounts.get(tabId) ?? 1) - 1;
  if (nextRefCount > 0) {
    state2.attachRefCounts.set(tabId, nextRefCount);
    return {};
  }
  state2.attachRefCounts.delete(tabId);
  for (const [sid, attachedTabId] of state2.sessionToTab) {
    if (attachedTabId === tabId) {
      state2.sessionToTab.delete(sid);
      state2.pageSessions.delete(sid);
      state2.lifecycleSessions.delete(sid);
    }
  }
  state2.runtimeTabs.delete(tabId);
  if (state2.ownedTabs.has(tabId)) {
    state2.ownedTabs.delete(tabId);
    tabShields.delete(tabId);
    await deps.detachDebugger(tabId);
  }
  await releaseTabShield(tabId, deps);
  return {};
}
async function cdpCreateTarget(params, deps) {
  const url = readCreateTargetUrl(params);
  refuseUnparseableDestination(url);
  if (!URL.canParse(url)) throw new Error(RELATIVE_REFUSAL);
  if (wrapsAbout(url, PROTECTED_RULES.innerSchemes)) throw new Error(ABOUT_WRAPPED);
  if (isProtectedTarget(url)) {
    throw new Error(PROTECTED_REFUSAL);
  }
  if (params["newWindow"] !== true) {
    return openedTarget(await deps.createTab(url), deps);
  }
  const state2 = readOptionalWindowState(params["windowState"]);
  const opts = { url, type: params["decorated"] === false ? "popup" : "normal", focused: typeof params["focus"] === "boolean" ? params["focus"] : params["background"] === false };
  if (state2 && state2 !== "normal") {
    opts.state = state2;
  } else {
    copyNumericFields(params, opts, GEOMETRY_KEYS);
    if (state2) opts.state = state2;
  }
  const created = await deps.createWindow(opts);
  return openedTarget(created.tabId, deps);
}
async function openedTarget(tabId, deps) {
  const tab = await deps.getTab(tabId);
  if (isProtectedUrl(tab?.pendingUrl) || isProtectedUrl(tab?.url)) {
    await deps.removeTab(tabId).catch(() => {
    });
    throw new Error(PROTECTED_REFUSAL);
  }
  return { targetId: String(tabId) };
}
async function cdpGetTargetInfo(params, deps) {
  const targetId = readTargetIdParam(params);
  const tabId = exactTabId(targetId);
  const tab = await deps.getTab(tabId);
  if (!tab) throw new Error(`No target with given id found: ${targetId}`);
  const info = { targetId, type: "page", title: tab.title ?? "", url: tab.url || tab.pendingUrl || "", attached: false, canAccessOpener: false };
  const hidden = await isProtectedTab(tab, deps.getTab);
  return { targetInfo: hidden ? redacted(info) : info };
}
async function cdpGetWindowForTarget(params, deps) {
  const targetId = readTargetIdParam(params);
  const tabId = await guardedTab(params, deps);
  const tab = await deps.getTab(tabId);
  if (!tab || typeof tab.windowId !== "number") {
    throw new Error(`No window for targetId: ${targetId}`);
  }
  const win = await deps.getWindow(tab.windowId);
  return { windowId: win.windowId, bounds: chromeWindowToCdpBounds(win) };
}
async function cdpGetWindowBounds(params, deps) {
  const windowId = params["windowId"];
  if (typeof windowId !== "number") {
    throw new Error(`Invalid windowId: ${String(windowId)}`);
  }
  const win = await deps.getWindow(windowId);
  return { bounds: chromeWindowToCdpBounds(win) };
}
var MINIMIZE_REFUSAL = "slicc: refused: minimizing the window that holds SLICC's tab would hide it";
async function cdpSetWindowBounds(params, portState, deps) {
  const windowId = params["windowId"];
  if (typeof windowId !== "number") {
    throw new Error(`Invalid windowId: ${String(windowId)}`);
  }
  const rawBounds = readCdpBoundsFields(params["bounds"]);
  const state2 = readOptionalWindowState(rawBounds["windowState"] ?? rawBounds["state"]);
  const props = {};
  if (state2 === "minimized" && portState.leaderTabId !== void 0) {
    const leader = await deps.getTab(portState.leaderTabId);
    if (leader?.windowId === windowId) throw new Error(MINIMIZE_REFUSAL);
  }
  if (state2 && state2 !== "normal") {
    props.state = state2;
  } else {
    copyNumericFields(rawBounds, props, GEOMETRY_KEYS);
    if (state2) props.state = state2;
  }
  await deps.updateWindow(windowId, props);
  return {};
}
var GEOMETRY_KEYS = ["left", "top", "width", "height"];
var WINDOW_STATES = /* @__PURE__ */ new Set(["normal", "minimized", "maximized", "fullscreen"]);
function copyNumericFields(source, target, keys) {
  for (const key of keys) {
    const value = source[key];
    if (typeof value === "number") target[key] = value;
  }
}
function readCdpBoundsFields(value) {
  return value !== null && typeof value === "object" ? value : {};
}
function chromeWindowToCdpBounds(win) {
  return { left: win.left, top: win.top, width: win.width, height: win.height, windowState: win.state || "normal" };
}
function readOptionalWindowState(value) {
  if (typeof value === "string" && WINDOW_STATES.has(value)) {
    return value;
  }
  return void 0;
}
async function cdpCloseTarget(params, state2, deps) {
  const tabId = await guardedTab(params, deps);
  for (const [sid, tid] of state2.sessionToTab) {
    if (tid === tabId) {
      state2.sessionToTab.delete(sid);
      state2.pageSessions.delete(sid);
      state2.lifecycleSessions.delete(sid);
    }
  }
  state2.runtimeTabs.delete(tabId);
  state2.attachRefCounts.delete(tabId);
  if (state2.ownedTabs.has(tabId)) {
    state2.ownedTabs.delete(tabId);
    tabShields.delete(tabId);
    await deps.detachDebugger(tabId);
  }
  await releaseTabShield(tabId, deps);
  await deps.removeTab(tabId);
  return { success: true };
}
var CLAIM_PREFIX = "capture-claim:";
var CLAIM_TTL_MS = 6e4;
function isCaptureOpenWindowMsg(msg) {
  return typeof msg === "object" && msg !== null && "type" in msg && msg.type === "capture-open-window" && typeof msg.url === "string";
}
function isCaptureClaimMsg(msg) {
  return typeof msg === "object" && msg !== null && msg.type === "capture-claim" && typeof msg.claim === "string";
}
function popupUrl() {
  return chrome.runtime.getURL("capture-popup.html");
}
function requestOf(url) {
  try {
    const parsed2 = new URL(url, popupUrl());
    if (`${parsed2.origin}${parsed2.pathname}` !== popupUrl()) return void 0;
    return parsed2.searchParams.get("req") ?? void 0;
  } catch {
    return void 0;
  }
}
async function prune() {
  const all = await chrome.storage.session.get(null);
  const stale = Object.entries(all).filter(([key, value]) => {
    if (!key.startsWith(CLAIM_PREFIX)) return false;
    const at = value?.at;
    return typeof at !== "number" || Date.now() - at > CLAIM_TTL_MS;
  }).map(([key]) => key);
  if (stale.length > 0) await chrome.storage.session.remove(stale);
}
async function register(req) {
  await prune().catch(() => {
  });
  const claim = crypto.randomUUID();
  const entry = { req, at: Date.now() };
  await chrome.storage.session.set({ [CLAIM_PREFIX + claim]: entry });
  return `${popupUrl()}?claim=${claim}`;
}
async function claimRequest(claim) {
  const key = CLAIM_PREFIX + claim;
  const found = await chrome.storage.session.get(key);
  await chrome.storage.session.remove(key);
  const entry = found[key];
  if (!entry || typeof entry.req !== "string" || typeof entry.at !== "number") return {};
  if (Date.now() - entry.at > CLAIM_TTL_MS) return {};
  return { req: entry.req };
}
function reportFailure(requestId, error) {
  if (!requestId) return;
  chrome.runtime.sendMessage({ source: "capture-popup", requestId, ok: false, error }).catch(() => {
  });
}
async function openCaptureWindow(message) {
  const req = requestOf(message.url);
  if (!req) {
    reportFailure(message.requestId, "invalid capture request");
    return;
  }
  try {
    const url = await register(req);
    await chrome.windows.create({ url, type: "popup", width: 360, height: 220, focused: true });
  } catch (err) {
    console.error("[slicc-sw] Failed to open capture popup window:", err);
    const reason = err instanceof Error ? err.message : String(err);
    reportFailure(message.requestId, `failed to open capture window: ${reason}`);
  }
}
function handleCapturePopupMessage(message, _sender, sendResponse) {
  if (isCaptureClaimMsg(message)) {
    claimRequest(message.claim).then((answer) => sendResponse?.(answer), () => sendResponse?.({}));
    return "handled-async";
  }
  if (!isCaptureOpenWindowMsg(message)) return "not-handled";
  void openCaptureWindow(message);
  return "handled";
}
async function listSecrets(storage) {
  const all = await storage.get(null);
  const entries = pairStorageEntries(all).map(({ name, domains }) => ({ name, domains }));
  entries.sort((a, b) => a.name.localeCompare(b.name));
  return entries;
}
async function setSecret(storage, name, value, domains) {
  await storage.set({ [name]: value, [name + DOMAINS_SUFFIX]: domains.join(",") });
}
async function deleteSecret(storage, name) {
  await storage.remove([name, name + DOMAINS_SUFFIX]);
}
async function listSecretsWithValues(storage) {
  const all = await storage.get(null);
  return pairStorageEntries(all);
}
function pairStorageEntries(all) {
  return pairEnvEntriesToSecrets(Object.entries(all).flatMap(([key, value]) => typeof value === "string" ? [{ key, value }] : []));
}
function getMsgType(msg) {
  if (typeof msg !== "object" || msg === null || !("type" in msg)) return void 0;
  const t = msg.type;
  return typeof t === "string" ? t : void 0;
}
function isTrustedInternalSender(sender) {
  if (typeof sender.id !== "string" || sender.id !== chrome.runtime.id) return false;
  const extensionOrigin2 = `chrome-extension://${chrome.runtime.id}`;
  const senderOrigin2 = sender.origin ?? (sender.url ? new URL(sender.url).origin : void 0);
  return senderOrigin2 === extensionOrigin2;
}
function routeSwMessage(handlers, message, sender, sendResponse) {
  if (!isTrustedInternalSender(sender)) {
    return false;
  }
  for (const handler of handlers) {
    const outcome = handler(message, sender, sendResponse);
    if (outcome === "not-handled") continue;
    return outcome === "handled-async";
  }
  return false;
}
function beginPortPin(port, deps, label) {
  const verdict = validateBridgePin(port.sender, { readStoredLeaderTabId: deps.readStoredLeaderTabId, writeStoredLeaderTabId: deps.writeStoredLeaderTabId, allowedOrigins: deps.allowedOrigins }).then((pin) => pin.ok ? { ok: true } : { ok: false, error: `${label} pin failed: ${pin.reason ?? "pin-failed"}` }, (err) => ({ ok: false, error: `${label} pin failed: ${err instanceof Error ? err.message : String(err)}` }));
  void verdict.then((result) => {
    if (!result.ok) console.error(`[sw] external ${label} pin check failed`, result.error);
  });
  return verdict;
}
var UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
var KEY = "_session.id";
async function readOrCreateSwSessionId() {
  const got = await chrome.storage.local.get(KEY);
  const existing = got[KEY];
  if (existing && UUID_RE.test(existing)) return existing;
  const fresh = crypto.randomUUID();
  await chrome.storage.local.set({ [KEY]: fresh });
  return fresh;
}
var DB_NAME = "slicc-secrets";
var DB_VERSION = 2;
var RECORD_STORE = "records";
var STORE_NAME = "keys";
var KEY_ID = "aes-gcm-secrets";
var UNREADABLE_SECRET = /* @__PURE__ */ Symbol.for("slicc:unreadable-secret");
function openDb() {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("IndexedDB not available"));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
      if (!db.objectStoreNames.contains(RECORD_STORE)) db.createObjectStore(RECORD_STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("IndexedDB open failed"));
  });
}
async function getOrCreateKey() {
  const db = await openDb();
  try {
    const existing = await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readonly");
      const req = tx.objectStore(STORE_NAME).get(KEY_ID);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    if (existing) return existing;
    const candidate = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      const store = tx.objectStore(STORE_NAME);
      const getReq = store.get(KEY_ID);
      getReq.onsuccess = () => {
        if (getReq.result) {
          resolve(getReq.result);
          return;
        }
        const putReq = store.put(candidate, KEY_ID);
        putReq.onsuccess = () => resolve(candidate);
        putReq.onerror = () => reject(putReq.error);
      };
      getReq.onerror = () => reject(getReq.error);
      tx.onerror = () => reject(tx.error);
    });
  } finally {
    db.close();
  }
}
var keyPromise = null;
function cachedKey() {
  if (!keyPromise) keyPromise = getOrCreateKey();
  return keyPromise;
}
function isEncryptedValue(v) {
  return typeof v === "object" && v !== null && typeof v.ct === "string" && typeof v.iv === "string";
}
function toBase64(buf) {
  return btoa(String.fromCharCode(...new Uint8Array(buf)));
}
function fromBase64(b64) {
  const bin = atob(b64);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return arr.buffer;
}
async function encryptValue(plaintext) {
  const key = await cachedKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(plaintext));
  return { ct: toBase64(ct), iv: toBase64(iv.buffer) };
}
async function decryptValue(encrypted) {
  try {
    const key = await cachedKey();
    const plainBuf = await crypto.subtle.decrypt({ name: "AES-GCM", iv: fromBase64(encrypted.iv) }, key, fromBase64(encrypted.ct));
    return new TextDecoder().decode(plainBuf);
  } catch {
    return UNREADABLE_SECRET;
  }
}
async function recordTx(mode, fn) {
  const db = await openDb();
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(RECORD_STORE, mode);
      const store = tx.objectStore(RECORD_STORE);
      let out;
      try {
        fn(store, (v) => {
          out = v;
        });
      } catch (e) {
        reject(e);
      }
      tx.oncomplete = () => resolve(out);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error ?? new Error("IndexedDB transaction aborted"));
    });
  } finally {
    db.close();
  }
}
function allRecords() {
  return recordTx("readonly", (s, done) => {
    const r = s.getAll();
    r.onsuccess = () => done(r.result ?? []);
  });
}
function getRecord(name) {
  return recordTx("readonly", (s, done) => {
    const r = s.get(name);
    r.onsuccess = () => done(r.result);
  });
}
function putRecords(records) {
  return recordTx("readwrite", (s) => {
    for (const rec of records) s.put(rec, rec.name);
  });
}
function deleteRecords(names) {
  return recordTx("readwrite", (s) => {
    for (const n of names) s.delete(n);
  });
}
function putRecordIfAbsent(rec) {
  return recordTx("readwrite", (s, done) => {
    const g = s.get(rec.name);
    g.onsuccess = () => {
      if (g.result) {
        done(false);
        return;
      }
      s.put(rec, rec.name);
      done(true);
    };
  });
}
function sameValue(a, b) {
  if (typeof a === "string" || typeof b === "string") return a === b;
  return isEncryptedValue(a) && isEncryptedValue(b) && a.ct === b.ct && a.iv === b.iv;
}
async function decryptRecord(value) {
  const dec = await decryptValue(value);
  return dec === UNREADABLE_SECRET ? void 0 : dec;
}
async function migrateSecretsToEncrypted() {
  const all = await chrome.storage.local.get(null);
  const names = Object.keys(all).filter((k) => !k.endsWith(DOMAINS_SUFFIX) && k + DOMAINS_SUFFIX in all && (typeof all[k] === "string" || isEncryptedValue(all[k])));
  for (const name of names) {
    const dk = name + DOMAINS_SUFFIX;
    const fresh = await chrome.storage.local.get([name, dk]);
    const value = fresh[name];
    if (typeof value !== "string" && !isEncryptedValue(value)) continue;
    const enc = typeof value === "string" ? await encryptValue(value) : value;
    const again = await chrome.storage.local.get([name, dk]);
    if (!sameValue(again[name], value) || again[dk] !== fresh[dk]) continue;
    await putRecordIfAbsent({ name, value: enc, domains: typeof fresh[dk] === "string" ? fresh[dk] : "" });
    const last = await chrome.storage.local.get([name, dk]);
    if (sameValue(last[name], value) && last[dk] === fresh[dk]) await chrome.storage.local.remove([name, dk]);
  }
}
var migrationPromise = null;
function ensureMigrated() {
  if (!migrationPromise) {
    migrationPromise = migrateSecretsToEncrypted().catch((err) => {
      migrationPromise = null;
      console.error("[slicc] secrets migration failed", err);
      throw err;
    });
  }
  return migrationPromise;
}
var encryptedStorage = { async get(keys) {
  await ensureMigrated();
  const out = {};
  for (const rec of await allRecords()) {
    const dec = await decryptRecord(rec.value);
    if (dec !== void 0) out[rec.name] = dec;
    out[rec.name + DOMAINS_SUFFIX] = rec.domains ?? "";
  }
  if (keys === null || keys === void 0) return out;
  const wanted = typeof keys === "string" ? [keys] : Array.isArray(keys) ? keys : Object.keys(keys);
  const picked = {};
  for (const k of wanted) if (k in out) picked[k] = out[k];
  return picked;
}, async set(items) {
  await ensureMigrated();
  const changes = /* @__PURE__ */ new Map();
  for (const [k, v] of Object.entries(items)) {
    const isDomains = k.endsWith(DOMAINS_SUFFIX);
    const base2 = isDomains ? k.slice(0, -DOMAINS_SUFFIX.length) : k;
    const c = changes.get(base2) ?? {};
    if (isDomains) c.domains = typeof v === "string" ? v : "";
    else c.value = v;
    changes.set(base2, c);
  }
  const records = [];
  for (const [name, c] of changes) {
    const rec = await getRecord(name) ?? { name, value: void 0, domains: "" };
    if ("value" in c) rec.value = typeof c.value === "string" ? await encryptValue(c.value) : c.value;
    if ("domains" in c) rec.domains = c.domains;
    if (rec.value !== void 0) records.push(rec);
  }
  await putRecords(records);
}, async remove(keys) {
  await ensureMigrated();
  const list2 = typeof keys === "string" ? [keys] : keys;
  const names = [];
  const cleared = [];
  for (const k of list2) {
    if (k.endsWith(DOMAINS_SUFFIX)) cleared.push(k.slice(0, -DOMAINS_SUFFIX.length));
    else names.push(k);
  }
  const records = [];
  for (const n of cleared) {
    if (names.includes(n)) continue;
    const rec = await getRecord(n);
    if (rec) {
      rec.domains = "";
      records.push(rec);
    }
  }
  if (records.length) await putRecords(records);
  if (names.length) await deleteRecords(names);
} };
var sessionSecretStore = new SessionSecretStore();
var storageLocal = encryptedStorage;
async function buildSecretsPipeline() {
  const sessionId = await readOrCreateSwSessionId();
  const source = { get: async (name) => {
    const fromSession = sessionSecretStore.get(name);
    if (fromSession !== void 0) return fromSession;
    const got = await storageLocal.get(name);
    return typeof got[name] === "string" ? got[name] : void 0;
  }, listAll: () => listSecretsWithValues(storageLocal) };
  return new SecretsPipeline({ sessionId, source, sessionStore: sessionSecretStore });
}
async function reloadedPipeline() {
  const pipeline = await buildSecretsPipeline();
  await pipeline.reload();
  return pipeline;
}
function buildReloadedPipelinePromise() {
  return reloadedPipeline();
}
function getStringField(msg, field) {
  if (typeof msg !== "object" || msg === null || !(field in msg)) return void 0;
  const v = Reflect.get(msg, field);
  return typeof v === "string" ? v : void 0;
}
function getStringArrayField(msg, field) {
  if (typeof msg !== "object" || msg === null || !(field in msg)) return void 0;
  const v = Reflect.get(msg, field);
  if (!Array.isArray(v)) return void 0;
  return v.filter((d) => typeof d === "string");
}
function errMsg(err) {
  return err instanceof Error ? err.message : String(err);
}
function runSecretsListMaskedEntries(_msg, sendResponse) {
  void (async () => {
    try {
      const pipeline = await reloadedPipeline();
      sendResponse({ entries: pipeline.getMaskedEntries() });
    } catch (err) {
      console.error("[sw] secrets.list-masked-entries failed", err);
      sendResponse({ entries: [], error: errMsg(err) });
    }
  })();
  return true;
}
function runSecretsScrubToolResult(msg, sendResponse) {
  const text = getStringField(msg, "text");
  if (text === void 0) return false;
  void (async () => {
    try {
      const pipeline = await reloadedPipeline();
      sendResponse({ text: pipeline.scrubResponse(text) });
    } catch {
      console.error("[sw] secrets.scrub-tool-result failed");
      sendResponse({ error: "secret scrub failed" });
    }
  })();
  return true;
}
function runSecretsListWithValuesForPipeline(_msg, sendResponse) {
  void (async () => {
    try {
      const sessionId = await readOrCreateSwSessionId();
      const persisted = await listSecretsWithValues(storageLocal);
      const persistedNames = new Set(persisted.map((e) => e.name));
      const session = sessionSecretStore.listAll().filter((s) => !persistedNames.has(s.name));
      const entries = [...persisted, ...session];
      sendResponse({ sessionId, entries });
    } catch (err) {
      console.error("[sw] secrets.list-with-values-for-pipeline failed", err);
      sendResponse({ sessionId: void 0, entries: [], error: errMsg(err) });
    }
  })();
  return true;
}
function runSecretsList(_msg, sendResponse) {
  void (async () => {
    try {
      const entries = await listSecrets(storageLocal);
      sendResponse({ entries });
    } catch (err) {
      console.error("[sw] secrets.list failed", err);
      sendResponse({ entries: [], error: errMsg(err) });
    }
  })();
  return true;
}
function runSecretsSet(msg, sendResponse) {
  const name = getStringField(msg, "name");
  const value = getStringField(msg, "value");
  const domains = getStringArrayField(msg, "domains");
  if (name === void 0 || value === void 0 || domains === void 0) return false;
  void (async () => {
    try {
      await setSecret(storageLocal, name, value, domains);
      sendResponse({ ok: true });
    } catch (err) {
      console.error("[sw] secrets.set failed", err);
      sendResponse({ ok: false, error: errMsg(err) });
    }
  })();
  return true;
}
function runSecretsDelete(msg, sendResponse) {
  const name = getStringField(msg, "name");
  if (name === void 0) return false;
  void (async () => {
    try {
      if (sessionSecretStore.has(name)) {
        sessionSecretStore.delete(name);
        sendResponse({ ok: true, removed: true, fromSession: true });
        return;
      }
      await ensureMigrated();
      if (!await getRecord(name)) {
        sendResponse({ ok: true, removed: false });
        return;
      }
      await deleteSecret(storageLocal, name);
      sendResponse({ ok: true, removed: true, fromSession: false });
    } catch (err) {
      console.error("[sw] secrets.delete failed", err);
      sendResponse({ ok: false, error: errMsg(err) });
    }
  })();
  return true;
}
function runSecretsSessionSet(msg, sendResponse) {
  const name = getStringField(msg, "name");
  const value = getStringField(msg, "value");
  const domains = getStringArrayField(msg, "domains");
  if (name === void 0 || value === void 0 || domains === void 0) return false;
  sessionSecretStore.set(name, value, domains);
  sendResponse({ ok: true });
  return true;
}
function runSecretsSessionList(_msg, sendResponse) {
  sendResponse({ entries: sessionSecretStore.list() });
  return true;
}
function runSecretsPeek(msg, sendResponse) {
  const name = getStringField(msg, "name");
  if (name === void 0) return false;
  void (async () => {
    try {
      const sessionRec = sessionSecretStore.getRecord(name);
      if (sessionRec) {
        sendResponse({ record: { name, preview: previewSecret(sessionRec.value), domains: sessionRec.domains } });
        return;
      }
      const all = await listSecretsWithValues(storageLocal);
      const found = all.find((e) => e.name === name);
      sendResponse({ record: found ? { name, preview: previewSecret(found.value), domains: found.domains } : void 0 });
    } catch (err) {
      console.error("[sw] secrets.peek failed", err);
      sendResponse({ record: void 0, error: errMsg(err) });
    }
  })();
  return true;
}
function runSecretsSetDomains(msg, sendResponse) {
  const name = getStringField(msg, "name");
  const domains = getStringArrayField(msg, "domains");
  if (name === void 0 || domains === void 0) return false;
  void (async () => {
    try {
      if (sessionSecretStore.has(name)) {
        sessionSecretStore.setDomains(name, domains);
        sendResponse({ ok: true });
        return;
      }
      const all = await listSecretsWithValues(storageLocal);
      const found = all.find((e) => e.name === name);
      if (!found) {
        sendResponse({ ok: false, error: "secret not found" });
        return;
      }
      await setSecret(storageLocal, name, found.value, domains);
      sendResponse({ ok: true });
    } catch {
      console.error("[sw] secrets.set-domains failed");
      sendResponse({ ok: false, error: "secret scope update failed" });
    }
  })();
  return true;
}
async function runMaskOauthTokenWrite(providerId, accessToken, domains) {
  if (accessToken && domains) {
    await storageLocal.set({ [`oauth.${providerId}.token`]: accessToken, [`oauth.${providerId}.token_DOMAINS`]: domains });
  }
  const pipeline = await reloadedPipeline();
  const name = `oauth.${providerId}.token`;
  return pipeline.getMaskedEntries().find((e) => e.name === name)?.maskedValue;
}
function runSecretsMaskOauthToken(msg, sendResponse) {
  const providerId = getStringField(msg, "providerId");
  if (providerId === void 0) return false;
  const accessToken = getStringField(msg, "accessToken");
  const domains = getStringField(msg, "domains");
  void (async () => {
    try {
      const maskedValue = await runMaskOauthTokenWrite(providerId, accessToken, domains);
      if (accessToken && domains && maskedValue === void 0) {
        console.warn("[sw] secrets.mask-oauth-token: entry missing after write");
        sendResponse({ maskedValue: void 0, error: "entry missing after write" });
        return;
      }
      sendResponse({ maskedValue });
    } catch {
      console.error("[sw] secrets.mask-oauth-token failed");
      sendResponse({ maskedValue: void 0, error: "OAuth token masking failed" });
    }
  })();
  return true;
}
function runSecretsRedactExport(msg, sendResponse) {
  const texts = getStringArrayField(msg, "texts");
  if (texts === void 0) return false;
  void (async () => {
    try {
      const pipeline = await reloadedPipeline();
      sendResponse(pipeline.redactForExport(texts));
    } catch (err) {
      console.error("[sw] secrets.redact-export failed", err);
      sendResponse({ error: errMsg(err) });
    }
  })();
  return true;
}
var SECRETS_HANDLERS = { "secrets.list-masked-entries": runSecretsListMaskedEntries, "secrets.scrub-tool-result": runSecretsScrubToolResult, "secrets.list-with-values-for-pipeline": runSecretsListWithValuesForPipeline, "secrets.list": runSecretsList, "secrets.set": runSecretsSet, "secrets.delete": runSecretsDelete, "secrets.session.set": runSecretsSessionSet, "secrets.session.list": runSecretsSessionList, "secrets.peek": runSecretsPeek, "secrets.set-domains": runSecretsSetDomains, "secrets.mask-oauth-token": runSecretsMaskOauthToken, "secrets.redact-export": runSecretsRedactExport };
function isSecretsMessageType(type) {
  return Object.hasOwn(SECRETS_HANDLERS, type);
}
function resolveSecretsHandler(msg) {
  const type = getMsgType(msg);
  return type !== void 0 && isSecretsMessageType(type) ? SECRETS_HANDLERS[type] : void 0;
}
function handleSecretsMessage(message, _sender, sendResponse) {
  const handler = resolveSecretsHandler(message);
  if (!handler) return "not-handled";
  return handler(message, sendResponse) ? "handled-async" : "not-handled";
}
function handleSecretsCrudPort(port, deps) {
  const pinPromise = beginPortPin(port, deps, "secrets.crud");
  port.onMessage.addListener(async (raw) => {
    const id = raw?.id;
    let replied = false;
    const reply = (response) => {
      if (replied) return;
      replied = true;
      port.postMessage({ id, response });
    };
    const pin = await pinPromise;
    if (!pin.ok) {
      reply({ error: pin.error });
      return;
    }
    const handler = resolveSecretsHandler(raw);
    if (!handler) {
      reply({ error: `unknown secrets type: ${getMsgType(raw) ?? "undefined"}` });
      return;
    }
    if (!handler(raw, reply)) {
      reply({ error: `malformed secrets request: ${getMsgType(raw)}` });
    }
  });
}
var debuggerAttachmentOwners = /* @__PURE__ */ new Map();
async function acquireDebuggerAttachment(tabId, owner) {
  if (debuggerAttachmentOwners.has(tabId)) return false;
  await chrome.debugger.attach({ tabId }, "1.3");
  debuggerAttachmentOwners.set(tabId, owner);
  return true;
}
async function releaseDebuggerAttachment(tabId, owner) {
  if (debuggerAttachmentOwners.get(tabId) !== owner) return;
  debuggerAttachmentOwners.delete(tabId);
  await chrome.debugger.detach({ tabId }).catch(() => {
  });
}
var CDP_UNMASK_METHODS = /* @__PURE__ */ new Set(["Runtime.evaluate", "Runtime.callFunctionOn", "Input.insertText"]);
async function tabHostname(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    const url = tab?.url;
    if (typeof url !== "string" || url.length === 0) return null;
    return new URL(url).hostname || null;
  } catch {
    return null;
  }
}
async function maybeUnmaskCdpFrame(tabId, method, params) {
  if (!CDP_UNMASK_METHODS.has(method)) return params;
  if (!params || typeof params !== "object") return params;
  const hostname = await tabHostname(tabId);
  if (!hostname) return params;
  const pipeline = await buildSecretsPipeline();
  await pipeline.reload();
  if (!pipeline.hasSecrets()) return params;
  const { frame, changed } = unmaskCdpFrame({ method, params }, hostname, pipeline);
  if (!changed) return params;
  const nextParams = frame.params;
  return nextParams ?? params;
}
function handleDebuggerDetach(source) {
  debuggerAttachmentOwners.delete(source.tabId);
  notifyBridgeDebuggerDetached(source.tabId);
}
function installCdpProxyListeners() {
  chrome.debugger.onDetach.addListener(handleDebuggerDetach);
}
var CHERRY_PANEL_PORT_NAME = "cherry-panel";
var panelPorts = /* @__PURE__ */ new Set();
var state = { kind: "join-url", state: "booting" };
var hasSeenReady = false;
var lastLeaderReloadAt = 0;
var LEADER_RELOAD_COOLDOWN_MS = 15e3;
var STORAGE_KEY2 = "cherryPanelState";
var loaded = false;
var loadPromise = null;
var recoveryDeps = null;
function setCherryPanelRecoveryDeps(deps) {
  recoveryDeps = deps;
}
function ensureLoaded() {
  loadPromise ??= (async () => {
    try {
      const saved = (await chrome.storage?.session?.get(STORAGE_KEY2))?.[STORAGE_KEY2];
      if (saved?.state) {
        state = saved.state;
        hasSeenReady = Boolean(saved.hasSeenReady);
        lastLeaderReloadAt = typeof saved.lastLeaderReloadAt === "number" ? saved.lastLeaderReloadAt : 0;
      }
    } catch {
    }
    loaded = true;
  })();
  return loadPromise;
}
function persist() {
  try {
    void chrome.storage?.session?.set({ [STORAGE_KEY2]: { state, hasSeenReady, lastLeaderReloadAt } });
  } catch {
  }
}
function broadcast() {
  for (const port of [...panelPorts]) {
    try {
      port.postMessage(state);
    } catch {
      panelPorts.delete(port);
    }
  }
}
function maybeRecoverLeader(now, reload) {
  if (!reload) return;
  if (now - lastLeaderReloadAt < LEADER_RELOAD_COOLDOWN_MS) return;
  lastLeaderReloadAt = now;
  persist();
  void reload();
}
async function handleCherryPanelConnect(port, deps) {
  port.onDisconnect.addListener(() => {
    panelPorts.delete(port);
  });
  port.onMessage.addListener((raw) => {
    const msg = raw;
    if (msg?.kind === "focus-leader") {
      void deps.focusLeaderTab?.().catch(() => {
      });
      if (msg.openSettings !== false) deps.openSettingsOnLeader?.();
      return;
    }
    if (msg?.kind !== "hello") return;
    if (loaded) {
      panelPorts.add(port);
      port.postMessage(state);
    } else {
      void ensureLoaded().then(() => {
        panelPorts.add(port);
        port.postMessage(state);
      });
    }
  });
  await ensureLoaded();
  const wasDisconnected = state.state === "disconnected";
  const wasTrayGaveUp = wasDisconnected && hasSeenReady;
  if (wasDisconnected) {
    state = { kind: "join-url", state: "booting" };
    persist();
    broadcast();
  }
  await deps.ensureLeaderTab();
  if (wasTrayGaveUp) {
    maybeRecoverLeader(Date.now(), deps.reloadLeaderTabIfExists ?? recoveryDeps?.reloadLeaderTabIfExists);
  }
}
function setCherryPanelJoinUrl(joinUrl) {
  if (joinUrl) {
    state = { kind: "join-url", state: "ready", joinUrl };
    hasSeenReady = true;
  } else if (!hasSeenReady) {
    state = { kind: "join-url", state: "booting" };
  } else {
    state = { kind: "join-url", state: "disconnected" };
    maybeRecoverLeader(Date.now(), recoveryDeps?.reloadLeaderTabIfExists);
  }
  persist();
  broadcast();
}
function broadcastLeaderGone() {
  state = { kind: "join-url", state: "disconnected" };
  hasSeenReady = false;
  persist();
  broadcast();
}
function createDiscoveryObserver(deps) {
  const seenFingerprints = /* @__PURE__ */ new Set();
  const probedOrigins = /* @__PURE__ */ new Set();
  const forward = (origin, kind, artifactUrl, pageUrl) => {
    const fingerprint = discoveryFingerprint({ origin, kind, url: artifactUrl });
    if (seenFingerprints.has(fingerprint)) return;
    const delivered = deps.emit({ discoveryOrigin: origin, discoveryKind: kind, discoveryUrl: artifactUrl, url: pageUrl });
    if (delivered >= 1) seenFingerprints.add(fingerprint);
  };
  const probeOrigin = async (origin, pageUrl) => {
    if (probedOrigins.has(origin)) return;
    probedOrigins.add(origin);
    try {
      const matches = await probeWellKnown(origin, deps.fetchImpl, { timeoutMs: deps.probeTimeoutMs });
      for (const match of matches) forward(origin, match.kind, match.url, pageUrl);
    } catch {
    }
  };
  const isEnabled = deps.isEnabled ?? (() => true);
  const isProtected = deps.isProtected ?? (() => false);
  const onHeaders = (detail) => {
    if (!isEnabled()) return;
    let url;
    try {
      url = new URL(detail.url);
    } catch {
      return;
    }
    if (url.protocol !== "http:" && url.protocol !== "https:") return;
    if (isProtected(detail.url)) return;
    const origin = url.origin;
    const { match } = extractCatalogFromWebRequest(detail.responseHeaders, detail.url);
    if (match) forward(origin, match.kind, match.url, detail.url);
    void probeOrigin(origin, detail.url);
  };
  return { onHeaders };
}
var DISCOVERY_ENABLED_KEY = "slicc_discovery_enabled";
var DISCOVERY_ALLOWED_ORIGINS = false ? [...BRIDGE_ALLOWED_ORIGINS, ...BRIDGE_DEV_ORIGINS] : BRIDGE_ALLOWED_ORIGINS;
var discoveryLoaded = false;
var discoveryEnabled = false;
function loadDiscoveryPreference() {
  void chrome.storage.local.get(DISCOVERY_ENABLED_KEY).then((result) => {
    const r = result;
    discoveryEnabled = r[DISCOVERY_ENABLED_KEY] !== false;
    discoveryLoaded = true;
  }).catch(() => {
    discoveryEnabled = true;
    discoveryLoaded = true;
  });
}
function senderOrigin(sender) {
  if (sender.origin !== void 0) return sender.origin;
  try {
    return new URL(sender.url ?? "").origin;
  } catch {
    return void 0;
  }
}
function handleDiscoverySetEnabled(message, sender) {
  if (getMsgType(message) !== "discovery.set-enabled") return "not-handled";
  const origin = senderOrigin(sender);
  if (!origin || !DISCOVERY_ALLOWED_ORIGINS.includes(origin)) return "not-handled";
  const enabled = message.enabled !== false;
  void chrome.storage.local.set({ [DISCOVERY_ENABLED_KEY]: enabled }).catch(() => {
  });
  return "handled";
}
function installDiscoveryObserver() {
  loadDiscoveryPreference();
  chrome.storage.onChanged?.addListener?.((changes, area) => {
    if (area !== "local") return;
    const change = changes[DISCOVERY_ENABLED_KEY];
    if (change) {
      discoveryEnabled = change.newValue !== false;
      discoveryLoaded = true;
    }
  });
  chrome.runtime.onMessageExternal?.addListener?.((message, sender) => {
    handleDiscoverySetEnabled(message, sender);
    return false;
  });
  const discoveryObserver = createDiscoveryObserver({ fetchImpl: (url, init) => fetch(url, init), emit: (discovery) => postDiscoveryToWelcomedLeaderPorts({ kind: "extension.discovery", ...discovery }), isEnabled: () => discoveryLoaded && discoveryEnabled, isProtected: isProtectedUrl });
  chrome.webRequest.onHeadersReceived.addListener((details) => {
    discoveryObserver.onHeaders({ url: details.url, responseHeaders: details.responseHeaders });
  }, { urls: ["<all_urls>"], types: ["main_frame"] }, ["responseHeaders"]);
}
var REQUEST_BODY_CAP = 32 * 1024 * 1024;
function extractSetCookies(headers) {
  const get = headers.getSetCookie;
  if (typeof get === "function") {
    return get.call(headers);
  }
  const joined = headers.get("set-cookie");
  return joined ? [joined] : [];
}
function buildResponseHeaders(scrubbed, upstream, pipeline) {
  const out = {};
  for (const [k, v] of Object.entries(scrubbed)) {
    const lower = k.toLowerCase();
    if (lower === "set-cookie" || lower === "www-authenticate" || lower.startsWith("x-proxy-")) {
      continue;
    }
    out[k] = v;
  }
  const setCookies = extractSetCookies(upstream);
  if (setCookies.length > 0) {
    out["X-Proxy-Set-Cookie"] = pipeline.scrubResponse(JSON.stringify(setCookies));
  }
  const wwwAuthenticate = upstream.get("www-authenticate");
  if (wwwAuthenticate) {
    out[PROXY_WWW_AUTHENTICATE_HEADER] = pipeline.scrubResponse(wwwAuthenticate);
  }
  return out;
}
function send(port, msg) {
  port.postMessage(msg);
}
var decodeBase64Bytes = base64ToUint8;
var encodeBase64Bytes = uint8ToBase64;
function isForbiddenRequestHeader(name) {
  const lower = name.toLowerCase();
  return lower === "cookie" || lower === "origin" || lower === "referer" || lower.startsWith("proxy-");
}
function getDnr() {
  const c = globalThis.chrome;
  const dnr = c?.declarativeNetRequest;
  if (!dnr || typeof dnr.updateSessionRules !== "function") return null;
  return dnr;
}
var nextDnrRuleId = 1e6;
function randomFragmentToken() {
  const c = globalThis.crypto;
  if (c && typeof c.randomUUID === "function") return c.randomUUID();
  return `${Date.now()}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
}
async function installForbiddenHeaderRule(url, headers, options = {}) {
  const dnr = getDnr();
  const requestHeaders = [];
  for (const [k, v] of Object.entries(headers)) {
    if (isForbiddenRequestHeader(k) || options.alsoRestore?.has(k.toLowerCase())) {
      requestHeaders.push({ header: k.toLowerCase(), operation: "set", value: v });
    }
  }
  const tagged = options.fragment ? `${url.split("#")[0]}#${options.fragment}` : url;
  if (!dnr || requestHeaders.length === 0) {
    return { fetchUrl: tagged, cleanup: async () => {
    } };
  }
  const id = nextDnrRuleId++;
  const fragment = options.fragment ?? `slicc-req-${randomFragmentToken()}`;
  const fetchUrl = `${url.split("#")[0]}#${fragment}`;
  const rule = { id, priority: 100, condition: { urlFilter: fetchUrl, resourceTypes: ["xmlhttprequest"] }, action: { type: "modifyHeaders", requestHeaders } };
  await dnr.updateSessionRules({ addRules: [rule] });
  let removed = false;
  const cleanup = async () => {
    if (removed) return;
    removed = true;
    try {
      await dnr.updateSessionRules({ removeRuleIds: [id] });
    } catch {
    }
  };
  return { fetchUrl, cleanup };
}
async function prepareUpstreamRequest(pipeline, msg) {
  const credsResult = pipeline.extractAndUnmaskUrlCredentials(msg.url);
  if (credsResult.forbidden) {
    return { error: `forbidden: ${credsResult.forbidden.secretName} on ${credsResult.forbidden.hostname}` };
  }
  const cleanedUrl = credsResult.url;
  const host = secretScopeHostname(cleanedUrl);
  const headers = decodeForbiddenRequestHeaders(msg.headers);
  let hmacSpec;
  for (const key of Object.keys(headers)) {
    if (key.toLowerCase() === HMAC_SIGN_HEADER) {
      hmacSpec = headers[key];
      delete headers[key];
      break;
    }
  }
  const headersResult = pipeline.unmaskHeaders(headers, host);
  if (headersResult.forbidden) {
    return { error: `forbidden: ${headersResult.forbidden.secretName} on ${headersResult.forbidden.hostname}` };
  }
  if (credsResult.syntheticAuthorization && !("authorization" in headers)) {
    headers.authorization = credsResult.syntheticAuthorization;
  }
  if (!headers.origin) {
    try {
      headers.origin = new URL(cleanedUrl).origin;
    } catch {
    }
  }
  let body;
  if (msg.bodyBase64) {
    body = pipeline.unmaskBodyBytes(decodeBase64Bytes(msg.bodyBase64), host).bytes;
  }
  if (hmacSpec) {
    const signResult = await pipeline.signHmac(hmacSpec, body ?? new Uint8Array(0), host);
    if (signResult.forbidden) {
      return { error: `forbidden: ${signResult.forbidden.secretName} on ${signResult.forbidden.hostname}` };
    }
    if (signResult.headerName && signResult.signatureHex) {
      headers[signResult.headerName] = signResult.signatureHex;
    }
    if (signResult.timestampHeaderName && signResult.timestampValue) {
      headers[signResult.timestampHeaderName] = signResult.timestampValue;
    }
  }
  return { cleanedUrl, headers, body };
}
async function streamUpstreamResponse(port, pipeline, upstream) {
  const scrubbed = pipeline.scrubHeaders(upstream.headers);
  const respHeaders = buildResponseHeaders(scrubbed, upstream.headers, pipeline);
  send(port, { type: "response-head", status: upstream.status, statusText: upstream.statusText, headers: respHeaders });
  if (upstream.body) {
    const reader = upstream.body.getReader();
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      const bodyScrubbed = pipeline.scrubResponseBytes(value);
      send(port, { type: "response-chunk", dataBase64: encodeBase64Bytes(bodyScrubbed) });
    }
  }
  send(port, { type: "response-end" });
}
async function processProxyRequest(port, pipeline, msg, signal) {
  try {
    const prepared = await prepareUpstreamRequest(pipeline, msg);
    if ("error" in prepared) {
      send(port, { type: "response-error", error: prepared.error });
      return;
    }
    const { cleanedUrl, headers, body } = prepared;
    const dnrRule = await installForbiddenHeaderRule(cleanedUrl, headers);
    try {
      const upstream = await fetch(dnrRule.fetchUrl, { method: msg.method, headers, body, signal });
      await streamUpstreamResponse(port, pipeline, upstream);
    } finally {
      await dnrRule.cleanup();
    }
  } catch (err) {
    send(port, { type: "response-error", error: err instanceof Error ? err.message : String(err) });
  }
}
async function handleProxyMessage(port, pipelinePromise, raw, signal) {
  const msg = raw;
  if (msg.type !== "request") return;
  if (msg.requestBodyTooLarge) {
    send(port, { type: "response-head", status: 413, statusText: "Payload Too Large", headers: {} });
    send(port, { type: "response-end" });
    return;
  }
  let pipeline;
  try {
    pipeline = await pipelinePromise;
  } catch (err) {
    send(port, { type: "response-error", error: `fetch-proxy init failed: ${err instanceof Error ? err.message : String(err)}` });
    return;
  }
  await processProxyRequest(port, pipeline, msg, signal);
}
function refuseRaw(port) {
  port.postMessage({ type: "raw-response-error", code: "unsupported", status: 501, error: "raw fetch: this service worker has no raw mode" });
  return () => {
  };
}
function handleFetchProxyConnectionAsync(port, pipelinePromise, startRaw) {
  const ac = new AbortController();
  let started = false;
  let rawSink = null;
  port.onDisconnect.addListener(() => ac.abort());
  port.onMessage.addListener((raw) => {
    if (rawSink) {
      rawSink(raw);
      return;
    }
    if (started) return;
    started = true;
    const type = raw?.type;
    if (type === "raw-request" || type === "raw-probe") {
      rawSink = startRaw?.(raw, ac.signal) ?? refuseRaw(port);
      return;
    }
    handleProxyMessage(port, pipelinePromise, raw, ac.signal).catch((err) => {
      send(port, { type: "response-error", error: err instanceof Error ? err.message : String(err) });
    });
  });
}
var CAPTURE_WAIT_MS = 1e3;
var REDIRECT_CAPTURE_WAIT_MS = 5e3;
var RESTORE_ALSO = /* @__PURE__ */ new Set(["user-agent"]);
var RawError = class extends Error {
  constructor(code, status, message) {
    super(message);
    this.code = code;
    this.status = status;
  }
  code;
  status;
};
var Credits = class {
  n;
  waiters = [];
  constructor(initial) {
    this.n = initial;
  }
  grant(k) {
    this.n += k;
    for (const w of this.waiters.splice(0)) w();
  }
  async take(signal) {
    while (this.n <= 0) {
      if (signal.aborted) return false;
      await new Promise((resolve) => {
        const done = () => {
          signal.removeEventListener("abort", done);
          resolve();
        };
        this.waiters.push(done);
        signal.addEventListener("abort", done, { once: true });
      });
    }
    this.n -= 1;
    return !signal.aborted;
  }
};
var UploadQueue = class {
  constructor(onConsumed) {
    this.onConsumed = onConsumed;
  }
  onConsumed;
  chunks = [];
  ended = false;
  waiter = null;
  push(bytes) {
    this.chunks.push(bytes);
    this.wake();
  }
  end() {
    this.ended = true;
    this.wake();
  }
  async next() {
    while (this.chunks.length === 0 && !this.ended) {
      await new Promise((resolve) => {
        this.waiter = resolve;
      });
    }
    const chunk = this.chunks.shift();
    if (!chunk) return null;
    this.onConsumed();
    return chunk;
  }
  wake() {
    const w = this.waiter;
    this.waiter = null;
    w?.();
  }
};
function forbidden(f) {
  return new RawError("forbidden-secret", 403, `Secret "${f.secretName}" is not allowed for domain "${f.hostname}"`);
}
function prepareHead(pipeline, head) {
  const creds = pipeline.extractAndUnmaskUrlCredentials(head.url);
  if (creds.forbidden) throw forbidden(creds.forbidden);
  const host = secretScopeHostname(creds.url);
  const headers = foldRawRequestHeaders(stripRawRequestHeaders(head.headers));
  const hmacSpec = headers[HMAC_SIGN_HEADER];
  delete headers[HMAC_SIGN_HEADER];
  const unmasked = pipeline.unmaskHeaders(headers, host);
  if (unmasked.forbidden) throw forbidden(unmasked.forbidden);
  if (creds.syntheticAuthorization && !("authorization" in headers)) {
    headers.authorization = creds.syntheticAuthorization;
  }
  return { url: creds.url, host, headers, hmacSpec };
}
function shouldStream(msg, deps) {
  return msg.hasBody && rawUploadStreams({ headers: msg.head.headers, bodyLength: msg.bodyLength, canStream: (deps.supportsRequestStreams ?? supportsRequestStreams)() });
}
async function bufferUpload(queue) {
  const parts = [];
  let size = 0;
  for (let chunk = await queue.next(); chunk; chunk = await queue.next()) {
    size += chunk.byteLength;
    if (size > RAW_FETCH_BUFFERED_REQUEST_BODY_CAP) {
      throw new RawError("request-body-too-large", 413, `raw fetch: request body exceeds the ${RAW_FETCH_BUFFERED_REQUEST_BODY_CAP} byte limit of this float`);
    }
    parts.push(chunk);
  }
  const out = new Uint8Array(size);
  let offset = 0;
  for (const part of parts) {
    out.set(part, offset);
    offset += part.byteLength;
  }
  return out;
}
async function relayBody(port, body, scrub, credits, signal) {
  const reader = body.getReader();
  try {
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done) break;
      const bytes = scrub ? scrub(value) : value;
      for (let off = 0; off < bytes.byteLength; off += RAW_FETCH_PORT_CHUNK_BYTES) {
        if (!await credits.take(signal)) return;
        const slice = bytes.subarray(off, off + RAW_FETCH_PORT_CHUNK_BYTES);
        send2(port, { type: "raw-response-chunk", dataBase64: uint8ToBase64(slice) });
      }
    }
  } finally {
    if (signal.aborted) await reader.cancel().catch(() => void 0);
  }
}
function send2(port, msg) {
  port.postMessage(msg);
}
function contentTypeOf(headers) {
  return headers.find(([name]) => name.toLowerCase() === "content-type")?.[1] ?? "";
}
var RawSession = class {
  constructor(port, msg, deps, signal) {
    this.port = port;
    this.msg = msg;
    this.deps = deps;
    this.signal = signal;
    this.credits = new Credits(msg.credits);
    this.queue = new UploadQueue(() => send2(port, { type: "raw-body-credit", chunks: 1 }));
    if (!msg.hasBody) this.queue.end();
  }
  port;
  msg;
  deps;
  signal;
  credits;
  queue;
  tag = `${RAW_FETCH_TAG_PREFIX}${randomFragmentToken()}`;
  onMessage(raw) {
    const msg = raw;
    if (msg.type === "raw-body-chunk") this.queue.push(base64ToUint8(msg.dataBase64));
    else if (msg.type === "raw-body-end") this.queue.end();
    else if (msg.type === "raw-credit") this.credits.grant(msg.chunks);
  }
  async run(pipelinePromise) {
    if (this.msg.hasBody) send2(this.port, { type: "raw-body-credit", chunks: RAW_FETCH_PORT_WINDOW });
    this.deps.capture.expect(this.tag);
    try {
      const pipeline = await pipelinePromise;
      const prepared = prepareHead(pipeline, this.msg.head);
      const upstream = await this.fetchUpstream(pipeline, prepared);
      await this.relay(pipeline, upstream);
    } catch (err) {
      if (this.signal.aborted) return;
      const e = err instanceof RawError ? err : new RawError("upstream", 502, err instanceof Error ? err.message : String(err));
      send2(this.port, { type: "raw-response-error", code: e.code, status: e.status, error: e.message });
    } finally {
      this.deps.capture.forget(this.tag);
    }
  }
  async fetchUpstream(pipeline, prepared) {
    const fetchImpl = this.deps.fetchImpl ?? fetch;
    const streamed = shouldStream(this.msg, this.deps);
    const rule = await installForbiddenHeaderRule(prepared.url, prepared.headers, { fragment: this.tag, alsoRestore: RESTORE_ALSO });
    try {
      const init = { method: this.msg.head.method, headers: prepared.headers, redirect: "manual", credentials: "omit", signal: this.signal };
      if (!streamed) {
        if (this.msg.hasBody) {
          const bytes = pipeline.unmaskBodyBytes(await bufferUpload(this.queue), prepared.host).bytes;
          await this.sign(pipeline, prepared, bytes);
          init.body = new Blob([bytes]);
        } else {
          await this.sign(pipeline, prepared, new Uint8Array(0));
        }
        return await fetchImpl(rule.fetchUrl, init);
      }
      init.duplex = "half";
      return await withUnsentUploadRetry(() => this.queue.next(), (body) => fetchImpl(rule.fetchUrl, { ...init, body }), this.signal);
    } finally {
      await rule.cleanup();
    }
  }
  async sign(pipeline, prepared, body) {
    if (!prepared.hmacSpec) return;
    const signed = await pipeline.signHmac(prepared.hmacSpec, body, prepared.host);
    if (signed.forbidden) throw forbidden(signed.forbidden);
    if (signed.headerName && signed.signatureHex) {
      prepared.headers[signed.headerName] = signed.signatureHex;
    }
    if (signed.timestampHeaderName && signed.timestampValue) {
      prepared.headers[signed.timestampHeaderName] = signed.timestampValue;
    }
  }
  async relay(pipeline, upstream) {
    const method = this.msg.head.method;
    const opaque = upstream.type === "opaqueredirect";
    const captured = await this.deps.capture.wait(this.tag, opaque ? REDIRECT_CAPTURE_WAIT_MS : CAPTURE_WAIT_MS);
    if (opaque && !captured) {
      throw new RawError("upstream", 502, "raw fetch: the redirect response was not observed");
    }
    const status = captured?.status ?? upstream.status;
    const upstreamHeaders = captured?.headers ?? [...upstream.headers];
    if (isDecodedPartialResponse({ status, headers: upstreamHeaders, decodedCodings: BROWSER_DECODED_CODINGS })) {
      await upstream.body?.cancel().catch(() => void 0);
      throw new RawError("upstream", 502, "raw fetch: the upstream answered a range request with an encoded partial body");
    }
    const isText = isTextContentType(contentTypeOf(upstreamHeaders));
    const headers = rawResponseHeaders({ method, status, headers: upstreamHeaders, bodyRewritten: isText, decodedCodings: BROWSER_DECODED_CODINGS }).map(([name, value]) => [name, pipeline.scrubResponse(value)]);
    const hasBody = !opaque && upstream.body !== null && rawResponseHasBody(method, status);
    send2(this.port, { type: "raw-response-head", head: { status, statusText: captured?.statusText || upstream.statusText, headers, url: this.msg.head.url }, hasBody });
    if (hasBody && upstream.body) {
      const scrub = isText ? (bytes) => pipeline.scrubResponseBytes(bytes) : null;
      await relayBody(this.port, upstream.body, scrub, this.credits, this.signal);
      if (this.signal.aborted) return;
    } else {
      await upstream.body?.cancel().catch(() => void 0);
    }
    send2(this.port, { type: "raw-response-end" });
  }
};
function rawSessionStarter(port, pipelinePromise, deps) {
  return (first, signal) => {
    if (first.type === "raw-probe") {
      send2(port, { type: "raw-probe-reply", reply: { rawFetch: RAW_FETCH_PROTOCOL_VERSION, requestBodyStreaming: (deps.supportsRequestStreams ?? supportsRequestStreams)(), maxRequestBodyBytes: RAW_FETCH_BUFFERED_REQUEST_BODY_CAP } });
      return () => {
      };
    }
    const session = new RawSession(port, first, deps, signal);
    void session.run(pipelinePromise);
    return (raw) => session.onMessage(raw);
  };
}
var LEADER_TAB_ID_KEY2 = "slicc_leader_tab_id";
var PROD_LEADER_TAB_URL = `${SLICC_HOSTED_ORIGIN}/?slicc=leader`;
var PROD_LEADER_TAB_URL_GLOB = `${SLICC_HOSTED_ORIGIN}/*`;
var PROD_LEADER_TAB_ORIGIN = SLICC_HOSTED_ORIGIN;
var DEV_LEADER_TAB_URL = "http://localhost:8787/?slicc=leader";
var DEV_LEADER_TAB_URL_GLOB = "http://localhost:8787/*";
var DEV_LEADER_TAB_ORIGIN = "http://localhost:8787";
function getLeaderTabUrl(isExtDev) {
  return isExtDev ? DEV_LEADER_TAB_URL : PROD_LEADER_TAB_URL;
}
function getLeaderTabUrlGlob(isExtDev) {
  return isExtDev ? DEV_LEADER_TAB_URL_GLOB : PROD_LEADER_TAB_URL_GLOB;
}
function getLeaderTabOrigin(isExtDev) {
  return isExtDev ? DEV_LEADER_TAB_ORIGIN : PROD_LEADER_TAB_ORIGIN;
}
function appendLeaderExtIdParam(leaderUrl, extensionId) {
  if (!extensionId) return leaderUrl;
  try {
    const u = new URL(leaderUrl);
    u.searchParams.set(LEADER_EXT_ID_QUERY_NAME, extensionId);
    return u.toString();
  } catch {
    return leaderUrl;
  }
}
function leaderUrlHasExtId(rawUrl, extensionId) {
  if (!rawUrl || !extensionId) return false;
  try {
    return new URL(rawUrl).searchParams.get(LEADER_EXT_ID_QUERY_NAME) === extensionId;
  } catch {
    return false;
  }
}
var LEADER_TAB_URL = getLeaderTabUrl(false);
var LEADER_TAB_URL_GLOB = getLeaderTabUrlGlob(false);
var LEADER_TAB_ORIGIN = getLeaderTabOrigin(false);
async function readStoredLeaderTabId() {
  try {
    const result = await chrome.storage.session.get(LEADER_TAB_ID_KEY2);
    const raw = result[LEADER_TAB_ID_KEY2];
    return typeof raw === "number" ? raw : void 0;
  } catch (err) {
    console.error("[slicc-sw] storage.session.get leader tab id failed", err);
    return void 0;
  }
}
async function writeStoredLeaderTabId(tabId) {
  await chrome.storage.session.set({ [LEADER_TAB_ID_KEY2]: tabId });
  await markLeaderTabNotDiscardable(tabId);
}
async function markLeaderTabNotDiscardable(tabId) {
  try {
    await chrome.tabs.update(tabId, { autoDiscardable: false });
  } catch (err) {
    console.warn("[slicc-sw] failed to exempt leader tab from discard/freeze", err);
  }
}
async function clearStoredLeaderTabId() {
  await chrome.storage.session.remove(LEADER_TAB_ID_KEY2);
}
function isLeaderTabUrl(rawUrl) {
  if (!rawUrl) return false;
  let u;
  try {
    u = new URL(rawUrl);
  } catch {
    return false;
  }
  if (u.origin !== LEADER_TAB_ORIGIN) return false;
  return u.searchParams.get("slicc") === "leader";
}
async function reconcileLeaderTabOnBoot() {
  const storedId = await readStoredLeaderTabId();
  if (storedId === void 0) return;
  let tab;
  try {
    tab = await chrome.tabs.get(storedId);
  } catch {
  }
  if (tab !== void 0 && isLeaderTabUrl(tab.url)) return;
  await clearStoredLeaderTabId();
}
var leaderTabLock = null;
async function queryLeaderTabs() {
  try {
    const matches = await chrome.tabs.query({ url: LEADER_TAB_URL_GLOB });
    return matches.filter((t) => isLeaderTabUrl(t.url) && t.id !== void 0);
  } catch (err) {
    console.error("[slicc-sw] tabs.query for leader tab failed", err);
    return [];
  }
}
async function createLeaderTab() {
  const created = await chrome.tabs.create({ url: appendLeaderExtIdParam(LEADER_TAB_URL, chrome.runtime.id), active: false, pinned: true });
  if (created.id !== void 0) await writeStoredLeaderTabId(created.id);
}
function isUnloadedTab(tab) {
  return tab.discarded === true || tab.status === "unloaded";
}
async function adoptSingleLeaderTab(matches) {
  const keep = matches.find((t) => !isUnloadedTab(t)) ?? matches[0];
  const extras = matches.filter((t) => t !== keep);
  if (keep.id === void 0) return;
  for (const extra of extras) {
    if (extra.id === void 0 || extra.id === keep.id) continue;
    try {
      await chrome.tabs.remove(extra.id);
    } catch (err) {
      console.error("[slicc-sw] failed to close duplicate leader tab", err);
    }
  }
  const extIdUrl = keep.url !== void 0 && chrome.runtime.id !== void 0 && !leaderUrlHasExtId(keep.url, chrome.runtime.id) ? appendLeaderExtIdParam(keep.url, chrome.runtime.id) : void 0;
  if (extIdUrl !== void 0 || keep.pinned !== true) {
    const props = { pinned: true };
    if (extIdUrl !== void 0) props.url = extIdUrl;
    await chrome.tabs.update(keep.id, props);
  }
  if (extIdUrl === void 0 && isUnloadedTab(keep)) {
    try {
      await chrome.tabs.reload(keep.id);
    } catch (err) {
      console.error("[slicc-sw] failed to reload unloaded leader tab", err);
    }
  }
  await writeStoredLeaderTabId(keep.id);
}
async function ensureLeaderTab() {
  if (leaderTabLock !== null) return leaderTabLock;
  leaderTabLock = (async () => {
    try {
      const matches = await queryLeaderTabs();
      if (matches.length === 0) await createLeaderTab();
      else await adoptSingleLeaderTab(matches);
    } finally {
      leaderTabLock = null;
    }
  })();
  return leaderTabLock;
}
async function reloadLeaderTabIfExists() {
  const id = await readStoredLeaderTabId();
  if (typeof id !== "number") return false;
  try {
    await chrome.tabs.reload(id);
    return true;
  } catch {
    return false;
  }
}
async function focusLeaderTab() {
  const storedId = await readStoredLeaderTabId();
  if (storedId !== void 0) {
    let leaderTab;
    try {
      leaderTab = await chrome.tabs.get(storedId);
    } catch {
      leaderTab = void 0;
    }
    if (leaderTab !== void 0 && isLeaderTabUrl(leaderTab.url)) {
      await chrome.tabs.update(storedId, { active: true });
      if (leaderTab.windowId !== void 0) {
        await chrome.windows.update(leaderTab.windowId, { focused: true });
      }
      return;
    }
    await clearStoredLeaderTabId();
  }
  await ensureLeaderTab();
  const newId = await readStoredLeaderTabId();
  if (newId === void 0) return;
  const tab = await chrome.tabs.get(newId).catch(() => void 0);
  if (tab === void 0) return;
  await chrome.tabs.update(newId, { active: true });
  if (tab.windowId !== void 0) {
    await chrome.windows.update(tab.windowId, { focused: true });
  }
}
var UPDATE_RELOAD_GUARD_KEY = "slicc_update_reload_at";
var UPDATE_RELOAD_GUARD_MS = 6e4;
async function isWithinUpdateReloadGuard() {
  const result = await chrome.storage.session.get(UPDATE_RELOAD_GUARD_KEY);
  const stamp = result[UPDATE_RELOAD_GUARD_KEY];
  if (typeof stamp !== "number") return false;
  return Date.now() - stamp < UPDATE_RELOAD_GUARD_MS;
}
async function stampUpdateReloadGuard() {
  await chrome.storage.session.set({ [UPDATE_RELOAD_GUARD_KEY]: Date.now() });
}
async function reloadLeaderTabForUpdate() {
  if (await isWithinUpdateReloadGuard()) return;
  if (await reloadLeaderTabIfExists()) await stampUpdateReloadGuard();
}
async function handleLeaderTabRemoved(tabId) {
  const storedId = await readStoredLeaderTabId();
  if (storedId !== tabId) return;
  await clearStoredLeaderTabId();
  broadcastLeaderGone();
}
function installLeaderTabListeners() {
  reconcileLeaderTabOnBoot().catch((err) => {
    console.error("[slicc-sw] reconcile leader tab failed", err);
  });
  chrome.runtime.onUpdateAvailable.addListener((details) => {
    console.log("[slicc-sw] Extension update available", details.version);
    reloadLeaderTabForUpdate().catch((err) => {
      console.error("[slicc-sw] onUpdateAvailable handler failed", err);
    }).finally(() => {
      chrome.runtime.reload();
    });
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    handleLeaderTabRemoved(tabId).catch((err) => {
      console.error("[slicc-sw] handleLeaderTabRemoved failed", err);
    });
  });
}
var HANDOFF_NOTIFICATION_ID_PREFIX = "slicc-handoff-";
var HANDOFF_INSTRUCTION_SNIPPET_MAX = 150;
var handoffNotificationSeq = 0;
function truncateInstruction(text) {
  if (text.length <= HANDOFF_INSTRUCTION_SNIPPET_MAX) return text;
  return `${text.slice(0, HANDOFF_INSTRUCTION_SNIPPET_MAX - 1)}\u2026`;
}
var CONTROL_CHARS_RE = new RegExp(`[${String.fromCharCode(0)}-${String.fromCharCode(31)}${String.fromCharCode(127)}]+`, "g");
function sanitizeInstruction(text) {
  return text.replace(CONTROL_CHARS_RE, " ");
}
function handoffSourceLabel(sourceUrl) {
  try {
    const origin = new URL(sourceUrl).origin;
    return origin === "null" ? "A page" : origin;
  } catch {
    return "A page";
  }
}
function handoffNotificationContent(match, sourceUrl) {
  const source = handoffSourceLabel(sourceUrl);
  if (match.verb === "upskill") {
    const repo = match.target.replace(/^https?:\/\//, "");
    const skill = match.path ? `${repo} (${match.path})` : repo;
    return { title: "Slicc skill available", message: `${source} offers a skill: ${skill}. Click to open the Slicc leader tab.` };
  }
  return { title: "Slicc handoff received", message: match.instruction ? `${source} asks: ${truncateInstruction(sanitizeInstruction(match.instruction))} \u2014 click to open the Slicc leader tab.` : `${source} sent a handoff. Click to open the Slicc leader tab.` };
}
function showHandoffNotification(match, sourceUrl) {
  const notificationId = `${HANDOFF_NOTIFICATION_ID_PREFIX}${Date.now()}-${handoffNotificationSeq++}`;
  chrome.action.setBadgeText({ text: "!" });
  chrome.action.setBadgeBackgroundColor({ color: "#ff5f72" });
  chrome.notifications.create(notificationId, { type: "basic", iconUrl: "logos/sliccy-color-1scoops-128x128.png", ...handoffNotificationContent(match, sourceUrl) });
}
var notifiedHandoffFingerprints = /* @__PURE__ */ new Set();
var HANDOFF_NOTIFIED_FINGERPRINTS_KEY = "slicc_handoff_notified_fingerprints";
var HANDOFF_NOTIFIED_FINGERPRINTS_MAX = 100;
var handoffNotifyChain = Promise.resolve();
function queueHandoffNotification(fingerprint, match, url) {
  handoffNotifyChain = handoffNotifyChain.then(() => notifyHandoffOncePerSession(fingerprint, match, url)).catch((err) => {
    console.warn("[slicc-sw] handoff notification dedup failed", err);
  });
}
async function notifyHandoffOncePerSession(fingerprint, match, url) {
  let stored = [];
  let readOk = true;
  try {
    const result = await chrome.storage.session.get(HANDOFF_NOTIFIED_FINGERPRINTS_KEY);
    const value = result[HANDOFF_NOTIFIED_FINGERPRINTS_KEY];
    if (Array.isArray(value)) stored = value.filter((v) => typeof v === "string");
  } catch (err) {
    console.warn("[slicc-sw] handoff fingerprint read failed", err);
    readOk = false;
  }
  for (const seen of stored) notifiedHandoffFingerprints.add(seen);
  if (stored.includes(fingerprint)) return;
  showHandoffNotification(match, url);
  if (!readOk) return;
  stored.push(fingerprint);
  await chrome.storage.session.set({ [HANDOFF_NOTIFIED_FINGERPRINTS_KEY]: stored.slice(-HANDOFF_NOTIFIED_FINGERPRINTS_MAX) });
}
function buildNavigateLick(match, url, tabId) {
  const payload = { type: "navigate-lick", url, verb: match.verb, target: match.target, tabId: tabId >= 0 ? tabId : void 0 };
  if (match.instruction) payload.instruction = match.instruction;
  if (match.branch) payload.branch = match.branch;
  if (match.path) payload.path = match.path;
  return payload;
}
function dispatchHandoffLick(payload) {
  postLickToWelcomedLeaderPorts({ kind: "extension.lick", verb: payload.verb, target: payload.target, url: payload.url, ...payload.instruction ? { instruction: payload.instruction } : {}, ...payload.branch ? { branch: payload.branch } : {}, ...payload.path ? { path: payload.path } : {}, ...payload.title ? { title: payload.title } : {} });
  chrome.runtime.sendMessage({ source: "service-worker", payload }).catch(() => {
  });
}
function handoffUrlAllowed(rawUrl) {
  if (!isProtectedUrl(rawUrl)) return true;
  try {
    const url = new URL(rawUrl);
    return url.origin === SLICC_HOSTED_ORIGIN && url.pathname === "/handoff";
  } catch {
    return false;
  }
}
function onHandoffHeaders(details) {
  if (!handoffUrlAllowed(details.url)) return;
  const { match } = extractHandoffFromWebRequest(details.responseHeaders, details.url);
  if (!match) return;
  const fingerprint = handoffFingerprint(match);
  const alreadyNotified = notifiedHandoffFingerprints.has(fingerprint);
  notifiedHandoffFingerprints.add(fingerprint);
  const payload = buildNavigateLick(match, details.url, details.tabId);
  const dispatch = (title) => {
    if (title) payload.title = title;
    dispatchHandoffLick(payload);
  };
  if (!alreadyNotified) queueHandoffNotification(fingerprint, match, details.url);
  if (details.tabId >= 0) {
    chrome.tabs.get(details.tabId).then((tab) => dispatch(tab.title)).catch(() => dispatch());
  } else {
    dispatch();
  }
}
function installHandoffNotifications() {
  chrome.notifications.onClicked.addListener((notificationId) => {
    if (!notificationId.startsWith(HANDOFF_NOTIFICATION_ID_PREFIX)) return;
    chrome.action.setBadgeText({ text: "" });
    focusLeaderTab().catch(() => {
    });
  });
  chrome.webRequest.onHeadersReceived.addListener(onHandoffHeaders, { urls: ["<all_urls>"], types: ["main_frame"] }, ["responseHeaders"]);
}
function isMountSignAndForwardRequest(msg) {
  return typeof msg === "object" && msg !== null && "type" in msg && "envelope" in msg && (msg.type === "mount.s3-sign-and-forward" || msg.type === "mount.da-sign-and-forward");
}
var chromeStorageSecretGetter = { async get(key) {
  const result = await encryptedStorage.get(key);
  const value = result[key];
  return typeof value === "string" ? value : void 0;
} };
async function handleMountSignAndForward(msg) {
  if (msg.type === "mount.s3-sign-and-forward") {
    return executeS3SignAndForward(msg.envelope, chromeStorageSecretGetter);
  }
  return executeDaSignAndForward(msg.envelope);
}
function internalErrorReply(err) {
  return { ok: false, error: err instanceof Error ? err.message : String(err), errorCode: "internal" };
}
function handleMountMessage(message, _sender, sendResponse) {
  if (!isMountSignAndForwardRequest(message)) return "not-handled";
  try {
    handleMountSignAndForward(message).then((reply) => sendResponse(reply)).catch((err) => sendResponse(internalErrorReply(err)));
  } catch (err) {
    sendResponse(internalErrorReply(err));
  }
  return "handled-async";
}
function handleMountSignAndForwardPort(port, deps) {
  const pinPromise = beginPortPin(port, deps, "mount.sign-and-forward");
  port.onMessage.addListener(async (raw) => {
    const id = raw?.id;
    const reply = (response) => port.postMessage({ id, response });
    const replyError = (message) => reply({ ok: false, error: message, errorCode: "internal" });
    const pin = await pinPromise;
    if (!pin.ok) {
      replyError(pin.error);
      return;
    }
    if (!isMountSignAndForwardRequest(raw)) {
      replyError("invalid mount.sign-and-forward request");
      return;
    }
    try {
      reply(await handleMountSignAndForward(raw));
    } catch (err) {
      replyError(err instanceof Error ? err.message : String(err));
    }
  });
}
var ENTRY_TTL_MS = 10 * 60 * 1e3;
function tagOf(url) {
  const hash = url.indexOf("#");
  if (hash < 0) return null;
  const fragment = url.slice(hash + 1);
  return fragment.startsWith(RAW_FETCH_TAG_PREFIX) ? fragment : null;
}
function createRawFetchCapture(now = Date.now) {
  const entries = /* @__PURE__ */ new Map();
  const sweep = () => {
    const t = now();
    for (const [tag, entry] of entries) if (entry.expires < t) entries.delete(tag);
  };
  return { expect(tag) {
    sweep();
    entries.set(tag, { head: null, waiters: [], expires: now() + ENTRY_TTL_MS });
  }, wait(tag, timeoutMs) {
    const entry = entries.get(tag);
    if (!entry) return Promise.resolve(null);
    if (entry.head) return Promise.resolve(entry.head);
    return new Promise((resolve) => {
      const timer = setTimeout(() => resolve(entry.head), timeoutMs);
      entry.waiters.push((head) => {
        clearTimeout(timer);
        resolve(head);
      });
    });
  }, forget(tag) {
    entries.delete(tag);
  }, onHeadersReceived(details) {
    const tag = tagOf(details.url);
    const entry = tag ? entries.get(tag) : void 0;
    if (!entry) return;
    entry.head = { status: details.statusCode, statusText: reasonFromStatusLine(details.statusLine), headers: (details.responseHeaders ?? []).map((h) => [h.name, h.value ?? ""]) };
    for (const waiter of entry.waiters.splice(0)) waiter(entry.head);
  } };
}
function installRawFetchCapture(capture) {
  chrome.webRequest.onHeadersReceived.addListener((details) => capture.onHeadersReceived(details), { urls: ["<all_urls>"], types: ["xmlhttprequest", "other"], tabId: -1 }, ["responseHeaders", "extraHeaders"]);
}
var SILENT_RENEW_TIMEOUT_MS = 1e4;
function buildWebAuthFlowOptions(url, interactive) {
  if (interactive) {
    return { url, interactive: true };
  }
  return { url, interactive: false, abortOnLoadForNonInteractive: false, timeoutMsForNonInteractive: SILENT_RENEW_TIMEOUT_MS };
}
async function handleOAuthRequest(msg) {
  const redirectUrl = await chrome.identity.launchWebAuthFlow(buildWebAuthFlowOptions(msg.authorizeUrl, msg.interactive ?? true));
  if (!redirectUrl) {
    return { type: "oauth-result", providerId: msg.providerId, error: "OAuth flow was cancelled or returned no URL" };
  }
  const parsed2 = new URL(redirectUrl);
  const params = parsed2.searchParams;
  const hashParams = new URLSearchParams(parsed2.hash.slice(1));
  const error = params.get("error") || hashParams.get("error");
  if (error) {
    return { type: "oauth-result", providerId: msg.providerId, error: params.get("error_description") || hashParams.get("error_description") || error };
  }
  return { type: "oauth-result", providerId: msg.providerId, code: params.get("code") ?? void 0, state: params.get("state") ?? void 0, redirectUrl };
}
async function sendServiceWorkerMessage(payload) {
  await chrome.runtime.sendMessage({ source: "service-worker", payload });
}
function isExtMsg(msg) {
  return typeof msg === "object" && msg !== null && "source" in msg && "payload" in msg;
}
function relayOAuthRequest(oauthMsg) {
  handleOAuthRequest(oauthMsg).then((result) => {
    sendServiceWorkerMessage(result).catch((e) => {
      console.error("[slicc-sw] Failed to send OAuth result:", e);
    });
  }).catch((err) => {
    sendServiceWorkerMessage({ type: "oauth-result", providerId: oauthMsg.providerId, error: err instanceof Error ? err.message : String(err) }).catch((e) => {
      console.error("[slicc-sw] Failed to send OAuth error:", e);
    });
  });
}
function handleRelayMessage(message) {
  if (!isExtMsg(message)) return "not-handled";
  if (message.source === "panel") {
    chrome.action.setBadgeText({ text: "" });
    if (message.payload.type === "oauth-request") {
      relayOAuthRequest(message.payload);
    }
    return "handled";
  }
  if (message.source === "offscreen") {
    console.warn("[slicc-sw] dropping offscreen message \u2014 offscreen document no longer exists");
    return "handled";
  }
  return "not-handled";
}
var BRIDGE_ORIGINS = false ? [...BRIDGE_ALLOWED_ORIGINS, ...BRIDGE_DEV_ORIGINS2] : BRIDGE_ALLOWED_ORIGINS;
var selfAdoptLeaderTabId = async (tabId) => {
  try {
    await writeStoredLeaderTabId(tabId);
  } catch {
  }
};
var bridgeSwDeps = buildDefaultBridgeSwDeps({ writeStoredLeaderTabId: selfAdoptLeaderTabId, attachDebugger: (tabId) => acquireDebuggerAttachment(tabId, "bridge"), detachDebugger: (tabId) => releaseDebuggerAttachment(tabId, "bridge"), sendDebuggerCommand: async (tabId, method, params) => {
  const result = await chrome.debugger.sendCommand({ tabId }, method, params);
  return result ?? {};
}, maybeUnmaskCdpFrame, allowedOrigins: BRIDGE_ORIGINS, onLeaderJoinUrl: (joinUrl) => {
  setCherryPanelJoinUrl(joinUrl);
} });
var portPinDeps = { readStoredLeaderTabId, writeStoredLeaderTabId: selfAdoptLeaderTabId, allowedOrigins: BRIDGE_ORIGINS };
installLeaderTabListeners();
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((err) => console.error("[slicc-sw] setPanelBehavior failed", err));
setCherryPanelRecoveryDeps({ reloadLeaderTabIfExists });
installHandoffNotifications();
installDiscoveryObserver();
installProtectedFrameTracker();
installCdpProxyListeners();
installBridgeFrontListeners(bridgeSwDeps);
for (const event of [chrome.webRequest.onHeadersReceived, chrome.webRequest.onResponseStarted]) {
  event.addListener(noteBridgeMainFrameResponse, { urls: ["<all_urls>"], types: ["main_frame"] });
}
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  noteBridgeTabChanged(tabId);
  const url = changeInfo.url ?? tab.pendingUrl;
  if (!url) return;
  const bridgeDetached = checkBridgeTabProtection(tabId, url);
  for (const detachedTabId of bridgeDetached) {
    releaseDebuggerAttachment(detachedTabId, "bridge").catch(() => {
    });
  }
});
var rawFetchDeps = { capture: createRawFetchCapture() };
installRawFetchCapture(rawFetchDeps.capture);
var SW_MESSAGE_HANDLERS = [handleCapturePopupMessage, handleRelayMessage, handleMountMessage, handleSecretsMessage];
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => routeSwMessage(SW_MESSAGE_HANDLERS, message, sender, sendResponse));
var EXTERNAL_PINNED_PORTS = { "fetch-proxy.fetch": (port) => connectExternalFetchProxy(port), "secrets.crud": (port) => handleSecretsCrudPort(port, portPinDeps), "mount.sign-and-forward": (port) => handleMountSignAndForwardPort(port, portPinDeps) };
chrome.runtime.onConnectExternal.addListener((port) => {
  if (port.name === EXTENSION_BRIDGE_PORT_NAME) {
    handleBridgePortConnect(port, bridgeSwDeps).catch((err) => {
      console.error("[slicc-sw] CDP bridge connect failed", err);
    });
    return;
  }
  const connect = Object.hasOwn(EXTERNAL_PINNED_PORTS, port.name) ? EXTERNAL_PINNED_PORTS[port.name] : void 0;
  if (!connect || !BRIDGE_ORIGINS.includes(port.sender?.origin ?? "")) {
    port.disconnect();
    return;
  }
  connect(port);
});
function connectExternalFetchProxy(port) {
  const pipelinePromise = beginPortPin(port, portPinDeps, "fetch-proxy").then((pin) => {
    if (!pin.ok) throw new Error(pin.error);
    return buildReloadedPipelinePromise();
  });
  pipelinePromise.catch((err) => {
    console.error("[sw] external fetch-proxy init failed", err);
  });
  handleFetchProxyConnectionAsync(port, pipelinePromise, rawSessionStarter(port, pipelinePromise, rawFetchDeps));
}
chrome.runtime.onConnect.addListener((port) => {
  const extOrigin = `chrome-extension://${chrome.runtime.id}`;
  const portOrigin = port.sender?.origin ?? (port.sender?.url ? new URL(port.sender.url).origin : void 0);
  if (port.sender?.id !== chrome.runtime.id || portOrigin !== extOrigin) return;
  if (port.name === CHERRY_PANEL_PORT_NAME) {
    chrome.action.setBadgeText({ text: "" }).catch(() => {
    });
    handleCherryPanelConnect(port, { ensureLeaderTab, reloadLeaderTabIfExists, focusLeaderTab, openSettingsOnLeader: () => {
      postOpenSettingsToWelcomedLeaderPorts();
    } }).catch((err) => console.error("[slicc-sw] handleCherryPanelConnect failed", err));
    return;
  }
  if (port.name !== "fetch-proxy.fetch") return;
  const pipelinePromise = buildReloadedPipelinePromise();
  pipelinePromise.catch((err) => {
    console.error("[sw] fetch-proxy init failed", err);
  });
  handleFetchProxyConnectionAsync(port, pipelinePromise, rawSessionStarter(port, pipelinePromise, rawFetchDeps));
});
